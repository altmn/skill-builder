# Widget Helper release-readiness audit

## Verdict and priority actions

**BLOCKED for the advertised reusable release.** The complete supplied source was reviewed without changing it. Its core review contract conflicts with mandatory writes/publication, publication evidence is fabricated from a local marker, the package fails two structural checks, and the supplied testing evidence contains zero tests.

Repair the authority and result contracts first, then restore a valid package and meaningful verification. **Public open-reuse distribution additionally needs a recorded rights-holder license decision.** This does not prevent local review or private development.

## Subject and method

| Field | Evidence |
|---|---|
| Subject | `/workspace/scratch/1e5ab00a904f/forward-input/audit-candidate` |
| Identity | Exact five-file filesystem snapshot; archive SHA-256 `d321d2b02a036c6a10688a8a6f758c6b37de4aaeaf08979e5e9015f281644929`. This hash identifies [source-snapshot.zip](source-snapshot.zip), not a published release. |
| Commit/version | Not supplied; no Git metadata in the selected target. Parent repositories were outside scope. |
| Review date | 2026-11-23T07:00:57.288940+00:00 |
| Coverage | **5/5 files, 784/784 bytes, 20 lines fully read by meaning**; 0 sampled/structural-only/duplicate/binary/symlink files; no exclusions. |
| Instructions | 4 unique document/metadata blocks and 8 consequential instruction/claim records; 0 generated expansions. |
| Rules | All **99/99** canonical rules dispositioned; **0 not_assessed**. Outcomes: blocked=1, failed=45, not_applicable=35, not_run=12, passed=6. |
| Executed | Reviewed trusted helper and strict portable validator under `python3 -I -B`; bounded inventory/hash checks; current primary-document retrieval; final source-byte/mode comparison. |
| Not executed | Candidate setup/publisher, input replacement, native hosts, install/update/remove, publication, account actions or paid model trials. |

The [original helper intake](intake/summary.json) correctly reported semantic review as not run at that earlier step. [Final coverage](coverage.json), [per-file reviews](reviews/), and [this final summary](summary.json) record the later completed assessment; no initial structural result was promoted into a runtime pass.

## Findings

| ID / priority | Evidence and consequence | Required change / independent completion evidence |
|---|---|---|
| **AUD-001 — high** | [SKILL.md](evidence/source/SKILL.md.txt), lines 9–11, requires read-only review and then input replacement/publication. A review request can become unauthorized mutation. | Keep review completion to a discrepancy list; separate explicitly requested edits/publication. Verify review-only input hashes and zero mutations. |
| **AUD-002 — high** | [publish.py](evidence/source/publish.py.txt), lines 1–3, only writes `sent` to a local marker and prints publication success. [SKILL.md](evidence/source/SKILL.md.txt), line 11, treats that as proof. **No remote operation exists in the supplied code.** | Remove the claim or implement a separately authorized publisher with destination, structured result and actual remote-state verification. A marker alone must fail acceptance. |
| **AUD-003 — high** | [setup.sh](evidence/source/setup.sh.txt), line 2, targets `../side-effect.txt`; [publish.py](evidence/source/publish.py.txt), line 2, targets the caller's cwd. Both may truncate existing files without ownership or symlink checks. The [README](evidence/source/README.md.txt), line 3, commands `./setup.sh`, but setup is mode 0644. | Remove unnecessary setup. Any retained writer needs an explicit owned destination, conflict/recovery rules and documented runtime/root. Test disposable existing files, symlinks and different/spaced cwd paths. No candidate execution was performed. |
| **AUD-004 — medium** | [SKILL.md](evidence/source/SKILL.md.txt), line 11, mandates absent `references/policy.md`. Trusted validation reproduced `resource.unresolved`. | Supply the policy or define its criteria in the entry point. Recheck the exact package and require honest missing-resource failure. |
| **AUD-005 — medium** | [SKILL.md](evidence/source/SKILL.md.txt), line 2, uses `widget-review` inside `widget-helper`. Trusted validation reproduced `name.directory` failure. | Align intended identifier, folder and invocation; revalidate and then run native discovery. |
| **AUD-006 — high** | [README](evidence/source/README.md.txt), line 3, claims complete security from `allowed-tools: Bash` and three-host support. [tests-summary.json](evidence/source/tests-summary.json.txt) has no host trials. Primary docs do not support a universal confinement interpretation. | Remove the security promise, name exact products/versions/policies, and record separate format/discovery/function/safety/maintenance outcomes. Exercise allowed and denied paths. |
| **AUD-007 — high** | [tests-summary.json](evidence/source/tests-summary.json.txt), line 1, combines `tests: 0` with `status: passed`; [README](evidence/source/README.md.txt) says all tests pass. No tests or receipts are supplied. | Mark absent checks as not_run/blocked. Add independent artifact/state cases and reject empty discovery as a pass. Bind receipts to exact inputs/package. |
| **AUD-008 — medium; public release gate** | [Complete inventory](inventory.json) contains no license/notice or versioned distribution contract; [README](evidence/source/README.md.txt) omits actual writes, limits and maintenance. | Rights owner records intended terms/notices; release owner documents task/example, runtime/effects, support scope and maintenance. No ownership/legal conclusion is asserted. |

The individual [finding records](findings.json) include exact source digests/ranges, failure conditions, owner/rule mapping, recommendations and limits. AUD-004 and AUD-005 were reproduced by a **trusted static checker**; the other execution concerns remain **source-level findings**. No exploitation, lost user data or remote action was observed.

## Host compatibility, effects and test evidence

| Candidate claim | Format | Discovery | Function | Actual safety exercise | Maintained support |
|---|---|---|---|---|---|
| Codex | Failed portable checks | Not run | Not run | Not run | Blocked: no defined version/policy/evidence |
| Claude Code | Failed portable checks | Not run | Not run | Not run | Blocked: no defined version/policy/evidence |
| Grok, product unspecified | Failed portable checks | Not run | Not run | Not run | Blocked: product and evidence missing |

Current [Agent Skills specification](https://agentskills.io/specification) requires directory/name agreement and calls `allowed-tools` experimental with varying implementation support. [Claude Code documentation](https://code.claude.com/docs/en/skills#pre-approve-tools-for-a-skill) describes turn-scoped pre-approval without removing other tools. [Grok Build documentation](https://docs.x.ai/build/features/skills-plugins-marketplaces) says the field grants/restricts no tools. These documentation checks support the claim assessment; they do not establish local host behavior. Dates, bounded excerpts and retrieval identities are in [source-register.json](source-register.json).

The source contains **two concrete local writer entrypoints**, one required missing policy, and one agent-directed input replacement. It contains no browser, network call, paid service, generator, worker runtime, cache, updater or migration mechanism. [Effects, dependency and lifecycle records](effects-and-dependencies.json) state the actual owners and controls. The publication modifier was retained because publication is demanded/claimed even though the code cannot perform it; installer/state modifiers conservatively cover setup and marker writes. Exclusions were reviewed individually rather than inherited blindly from a profile.

The trusted structural check used validator **1.1.0**, profile **portable-conservative-v1**, and **PyYAML 6.0.3**. It returned exit **1**, with two failed properties and no target changes. Its [full report](static-checks.json) preserves the limits: no script safety, native discovery, permission enforcement, task quality, triggering, full Markdown parsing or filesystem-race guarantee. Manual review additionally covered every prose/code path and the complete executable source without executing it.

[All 22 preserved evaluation designs](unexecuted-checks.json) receive a proposed-scope disposition. Task, denial, missing-resource, false-success, ownership, native-host lifetime/identity and no-skill trials remain unrun. No updater/worker case is required for mechanisms absent from this target. The [evaluation record](evaluation-not-run.json) contains **zero attempts and outcome not_run**, with unknown usage retained as unknown.

## Useful patterns and remediation order

The candidate has a concrete small task, a concise discovery description and a discrepancy-list output. Retain those. Its two tiny script owners make the full static execution chain easy to inspect. Avoid copying its unconditional setup/publishing steps, marker-based success or metadata-based security promise.

| Order | Owner / estimated effort | Completion evidence |
|---|---|---|
| 1. Restore read-only authority and honest completion; remove unrelated writer steps | Skill/resource author; small source change | Input-preservation and no-publication cases pass against repaired bytes. |
| 2. Repair name and missing policy | Package author; small | Exact delivered skill passes format/resource checks and applies explicit criteria. |
| 3. If writing/publishing is retained, implement a distinct complete command/authorization contract | Resource author; scope depends on actual destination | Owned-path/overwrite/denial/interruption cases; real remote receipt only for an authorized publisher. |
| 4. Replace empty success evidence and narrow support claims | Test/support owner; moderate, host access required | Nonempty independent task/resource/denied-action receipts and per-host activated identity/version/policy. |
| 5. Complete public distribution terms, docs and maintenance decision | Rights/release owner; decision-dependent | Selected terms/notices and verified truthful README included in the final artifact. |

Effort labels are planning estimates, not measured timings. Candidate repair, native installation and external publication were outside authorization and were not performed. The completed audit remains useful while these gates are unresolved.

## Evidence map

- [All-file inventory](inventory.json), [subject identity](subject-identity.json), [exact source snapshot](source-snapshot.zip), [final preservation check](target-preservation.json).
- [Semantic coverage](coverage.json), [instruction worksheet/index](instruction-index.json), [effects and dependencies](effects-and-dependencies.json).
- [Machine-readable finding index](findings.json), [all 99 rule assessments](rule-traceability.json), [canonical selection](rule-selection.json), [reviewer/owner/authority metadata](rule-decision-metadata.json).
- Native host records: [Codex](hosts/codex.json), [Claude Code](hosts/claude-code.json), [unspecified Grok](hosts/grok.json).
- [Unexecuted checks](unexecuted-checks.json), [honest unrun evaluation receipt](evaluation-not-run.json), [record validation](validation.json).

The source inventory and the final exact-byte/mode comparison agree: **the candidate remained unchanged**. Static audit completion and release readiness are separate outcomes.
