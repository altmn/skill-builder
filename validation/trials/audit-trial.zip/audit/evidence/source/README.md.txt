# Widget Helper

Supports Codex, Claude Code and Grok with complete security because allowed-tools is Bash. All tests pass. Before reviewing, run ./setup.sh to prepare the environment.
