# Source review and evidence limits

Reviewer: source-creation agent. Date: 2026-11-23. This is author review of the exact runtime file and project contracts. It is not an independent model test, a calibrated grade, or a native-host safety test.

## Task contract assessment

| Requirement | Source assessment | Remaining outcome evidence |
|---|---|---|
| Four requested review functions | The procedure covers contradictions, certainty, compatibility assumptions, and concrete questions; the output retains category coverage. | An actual independent response has not been observed. |
| No invented product facts | The entry point limits evidence to supplied text and forbids filling gaps from memory. The authored example qualifies possible explanations. | Behavior on new inputs is unrun. |
| Scope-sensitive contradiction judgment | Same subject/scope/time is required for a direct contradiction. Installation/runtime examples distinguish ambiguous from explicitly different stages. | False-positive and missed-conflict rates are unknown. |
| Unsupported certainty | Universal guarantees are assessed against supplied support, with ordinary descriptive statements excluded from an automatic citation complaint. | Semantic grading needs independent trials. |
| Compatibility questions | Gaps must attach to a stated claim/change. Questions ask for scope, affected versions, token/config conditions, or transition details. | Real author's usefulness feedback is unavailable. |
| Read-only, offline output | The runtime names browsing, execution, unrelated reads, input edits, saving, and publication as excluded effects. No runtime code, links, or state store exists. | The host owns enforcement; no safety boundary was exercised. |
| Missing input, denial, partial coverage, interruption | Blocked/partial handling and current-revision recovery are explicit. The panel includes each condition. | Their runtime behavior is not tested. |
| No false success | The source separates text review from product verification and release readiness. Authored examples are labeled examples. | Native workflow completion remains unrun. |
| Opt-outs and near misses | Metadata and body exclude rewriting, external fact checking, publication, spelling-only tasks, and opt-outs. | Native trigger behavior remains unrun. |

## Instruction ownership and contradictions

The runtime is the sole task-policy owner. Project-level documentation explains its behavior and support limits; it does not add runtime tools or authority. The report template allows tables or category sections and does not require exact prose. No mandatory rule is hidden in an optional reference. The whole runtime is loaded as one document.

The Python example does not infer that Python 3.12 is build-only. The integration example states the consequence for integrations using old tokens without inventing which integrations use them. The scoped build/runtime counterexample is deliberately consistent. The release status distinguishes a completed local source artifact from unrun native behavior and blocked public licensing.

## Independent exercise unavailable

After freezing the panel, the creator attempted to dispatch a fresh agent with only the exact runtime path and the RN-13 webhook note. The tool rejected dispatch with `agent thread limit reached`. No child agent began that task, no response was generated, and no behavioral check passed. The parent directed completion using available local checks without reusing another agent. The evaluation receipt preserves this gap.

## Verification boundaries

Portable validator 1.1.0 completed 12 checks on the exact SKILL.md using Python 3.12.14 and PyYAML 6.0.3. It covers metadata, body presence, and its recognized direct-link syntax. This source has no runtime resource links. The validator does not assess task correctness, discovery, model behavior, permissions, host availability, or safety. Its full unchecked list is retained in `format-results.json`.

The original record validator checks record shapes and cross-field consistency, including the exact 99-ID set and original authority basis. It does not validate the truth of this review. The project inventory and hashes detect byte changes; they do not prove product facts or publisher identity.

No browsing, external provider call, live installation, publication, account change, or message send occurred. Token usage, end-to-end task latency, total cost, reliability, and improvement over a clean no-skill control were not measured. No known severe defect in a claimed executed capability is hidden by an average score; there is no average score.
