# License decision pending

No public license was selected for the new runtime instructions, examples, or project documentation. The reused knowledge-base rule statements and schema conventions independently record public license selection as pending. This document makes no new grant and does not decide ownership.

Before public open reuse, the relevant rights holder must select full terms, identify covered files and the effective revision, and retain any applicable notices. See `NOTICE.md` for source identity and coverage. Existing third-party terms are not expanded to this project by inference.

This is a named blocker for public open reuse, not a claim that the local source artifact was not created or that its local checks failed. No license choice is needed to complete the source-only task within its stated scope.
