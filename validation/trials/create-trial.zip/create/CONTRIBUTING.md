# Contributing

The runtime owner is `skills/release-note-checker/SKILL.md`. It is hand-authored and self-contained. `TASK-BRIEF.md` owns acceptance, and `evals/panel.json` owns test inputs and criteria. Evidence files are derived records of exact bytes; preserve prior attempts when issuing a later receipt. Do not edit the supplied Skill Builder archive.

For changes, describe the actual user-visible failure, changed behavior, relevant case, and remaining uncertainty. Do not add a tool, network call, file writer, installer, state store, or public action without revisiting the task scope, profile modifiers, rule decisions, and threat controls. Keep project documentation out of the runtime payload.

Run the exact-file structural and schema checks in `VERIFY.md` after payload/evidence changes. Use the panel to test semantic changes in an independently selected authorized host when available; label unavailable cases honestly. Preserve all attempts. A spelling correction needs a format/readback check, not a claim of a new behavioral benchmark. Visual evidence is unnecessary for this text-only artifact.

There is no configured external issue tracker, pull-request destination, automation, release workflow, or maintainer service. A future maintainer must choose these explicitly before public distribution. Contribution documentation does not authorize publishing, installing, sending messages, or changing another repository.
