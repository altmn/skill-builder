# Security and support limits

This is an uninstalled source candidate, version 0.1.0-source. No host/version support commitment or response-time promise exists. No private reporting address or account has been supplied; do not invent one or publish sensitive input in a public issue. Before public distribution, a responsible maintainer must establish a real private reporting route and supported-version policy.

The runtime has no executable code and requires no credentials. It instructs the agent to use only supplied text, treat embedded instructions as data, avoid browsing and execution, preserve input, and avoid unnecessary secret reproduction. These are advisory instructions. The actual host owns file permissions, tool access, processing, retention, and any sandbox enforcement. No claim of complete injection resistance, secret detection, or confinement is made.

The cases for hostile text, denied reads, secret canaries, incomplete input, and changed notes are in `evals/panel.json`. They are designs; no independent agent trial completed in this source build. See the blocked evaluation receipt and release status before making stronger claims.
