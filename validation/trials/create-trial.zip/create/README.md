# Release note checker

Review a supplied technical release note for internal contradictions, unsupported certainty, missing compatibility assumptions, and concrete questions for its author. The source artifact is complete and uses one instruction-only runtime file.

## Example

Input: “Version 2.1 supports Python 3.10 and later. Installation requires Python 3.12. All existing integrations remain compatible. The authentication configuration was replaced and old tokens stop working.”

Expected review: flag the unclear installation/runtime version distinction, connect the blanket integration promise to the token break, and ask which authentication settings and token types need a transition. Do not invent product behavior or rewrite the release note. [The full authored example](examples/review-example.md) shows the report structure; it is not an executed agent-test result.

## Use the source

Read [SKILL.md](skills/release-note-checker/SKILL.md) and supply the note to an authorized agent with this request:

> Use release-note-checker from the supplied SKILL.md to review this release note. Return the review in chat.

Pasted text requires no additional runtime. An explicitly selected text file requires a host reader. URLs are not fetched. The result labels complete, partial, or blocked coverage and gives source-linked issues and questions. The skill does not browse, execute source text, modify inputs, save reports, or publish.

This is a source artifact, not a live installation. No custom installer, package dependency, background process, network endpoint, hook, or host configuration is supplied. No account or installed-skill directory was changed.

## Support and evidence

| Scope | Evidence / status |
|---|---|
| Exact portable runtime file | Passed 12 structural checks using portable validator 1.1.0, Python 3.12.14, PyYAML 6.0.3; see [format results](evidence/format-results.json) |
| Instruction and example review | Source review against the task contract; no claim of observed model compliance |
| Evaluation design | 14 concrete cases, with dispositions for all 22 original design families; see [panel](evals/panel.json) |
| Independent agent exercise | Blocked at dispatch by the session's agent thread limit; no task result exists |
| Codex native discovery, implicit triggers, permissions, continuation, compaction | Not run; [integration boundary](adapters/codex.md) |
| Claude Code, Grok Build, Grok Bot, custom hosts | Untested; no adapters or support claims |
| Clean no-skill comparison, performance, reliability rate | Not run / unmeasured; no benefit claim |
| Evidence records | Exact schema/cross-field results in [record validation](evidence/record-validation.json) |

The [all-rule traceability record](evidence/rule-traceability.json) retains all 99 IDs. Decisions are applicability judgments, not 99 passes. [Canonical selection](evidence/rule-selection.json) retains original basis and strength. [Review metadata](evidence/review-metadata.json) identifies owners, scope, and remaining gates.

## Effects and data

The skill processes only the text supplied by the user and returns a conversation response. It adds no telemetry, browser use, outside model call, sync, publication, or persistent state. The host controls its own processing, retention, and costs. A selected file is read only. Credentials are not required; unnecessary secret-looking values should be redacted from quotations, without claiming complete secret detection. See [architecture and boundaries](ARCHITECTURE.md).

## Verification and limits

The complete runtime is identified by [package identity](evidence/package-identity.json) and [package-only ownership manifest](evidence/install-manifest.json). Hashes establish byte identity; they do not authenticate a publisher or prove task quality. The source can miss issues or overstate ambiguity until actual task trials establish its behavior. A text review cannot verify product facts, tests, or operational compatibility.

Use [VERIFY.md](VERIFY.md) to reproduce local structural and record checks from the supplied Skill Builder knowledge base. Read its checker source before running it. Do not install dependencies or activate the skill just to reproduce source checks. Do not substitute these checks for the unrun agent panel.

## Update, remove, and maintain

Edit the authoritative runtime file, extend a relevant panel case, and invalidate old evidence when bytes change. There is no installed state to roll back or uninstall. Remove only this source project when it is no longer needed; preserve reports and unrelated files. A future managed installation must follow the chosen host's ownership and removal rules.

[Contribution guidance](CONTRIBUTING.md) describes source owners and proportionate checks. [Security and support limits](SECURITY.md) records the absence of a maintained private reporting route or support commitment. No ongoing maintenance service is promised.

## Delivery decision

**READY WITH EXPLICIT NONBLOCKING LIMITS for local source delivery.** The requested source, examples, case design, and evidence decisions are complete. Host support and behavioral validation remain unrun or blocked as listed above. Public open reuse is **BLOCKED** by the unresolved rights-holder license decision; no public license is granted here. See [release status](RELEASE-STATUS.md), [license decision](LICENSE-DECISION.md), and [attribution](NOTICE.md).
