# Architecture, authority, and threat decisions

## Smallest useful runtime

The runtime is one self-contained `skills/release-note-checker/SKILL.md`. Its job is a reasoning workflow over supplied language; there is no deterministic product-compatibility calculation to delegate to a script. Decision examples fit inside the entry point. Development examples, evaluation cases, rule decisions, and support records stay outside the runtime payload.

The profile is `instruction`, with no runtime capability modifiers. Creation writes source files, but this development effect does not give the runtime permission to save or change inputs. Runtime rules involving commands, generated adapters, installers, state, caches, browsers, remote calls, or parallel workers are reviewed individually and excluded only where absent. Development source writing and checker execution are documented separately in the evidence ledger.

## Single owners

| Contract | Owner |
|---|---|
| Runtime task, boundaries, report, recovery | `skills/release-note-checker/SKILL.md` |
| Acceptance criteria and development scope | `TASK-BRIEF.md` |
| Concrete evaluation inputs and expected outcomes | `evals/panel.json` |
| Source/canonical-rule decisions and verification limits | `evidence/rule-selection.json`, `evidence/rule-traceability.json`, `evidence/review-metadata.json` |
| Host-specific integration limits | `adapters/codex.md`, `evidence/host-capabilities.json` |
| Delivered payload identity | `evidence/package-identity.json` |

No generator owns the runtime text. The source directory is the exact payload; no build, transformed copy, archive, or generated host permissions are needed. Hash inventories are derived evidence and must be regenerated after payload edits.

## Threat and control table

| Lower-trust input / risk | Protected resource | Control and owner | Expected denial | Evidence limit |
|---|---|---|---|---|
| Instructions embedded in a release note | User task and unrelated files/accounts | Entry-point instruction: treat note and links as data | No new reads, browsing, execution, saving, or publishing | Advisory model instruction; no sandbox claim |
| Ambiguous support claims | Accuracy of the review | Preserve subject/version/time/scope; distinguish possible from direct conflict | No invented minimum version or migration facts | Reasoning quality needs actual outcome trials |
| Universal guarantee based on narrow evidence | Author's decision | Match certainty to evidence stated in the note | No conversion of missing support into proof of falsehood | Does not verify underlying evidence |
| Empty, truncated, unreadable, or denied source | Honest completion status | Block or report exact partial scope | No clean result for unread text; no fallback access route | Host reader supplies actual access boundary |
| Secret-looking value in supplied note | Sensitive content in the response | Quote role labels and redact unnecessary values | No unnecessary secret reproduction | No complete classifier/redaction guarantee |
| Changed note after a prior result | Evidence freshness | Re-establish revision and coverage | No reuse of prior findings as current proof | Host compaction/reload behavior untested |

## Data flows and effects

The runtime consumes only the text the user supplies or explicitly selects and emits a chat response. The current model host processes that text and may store the conversation under its own policy; host retention and costs are not controlled by this skill. The skill adds no telemetry, crash reporting, cloud sync, external-model call, authenticated browser, or publication flow. No credentials are required.

The development workflow creates only this requested project and an inert, separately extracted copy of the supplied knowledge base for reading/checking. Trusted local Python validators are reviewed before execution, run in isolated mode, and use installed dependencies without downloading anything. No inspected product code is executed. The rejected patch attempt changed no content; a later explicit replacement completed the files. Independent-agent dispatch was blocked by the session's thread limit and produced no agent result.

## Source-only authorization decision

The explicit request is to produce a new source artifact, not install or publish it. Accordingly the generic personal-skill installation/synchronization steps are outside this task. No live skill directory, external repository, user setting, account, or message recipient is changed. This is a scope choice, not a permission workaround or an assertion that installation succeeded.
