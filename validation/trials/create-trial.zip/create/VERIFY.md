# Reproduce the local checks

These checks require the supplied Skill Builder at its recorded path and Python. The portable format validator uses installed PyYAML; schema validation additionally uses installed jsonschema and referencing. No dependency installation is included. The recorded environment used Python 3.12.14 and PyYAML 6.0.3; see receipts for actual versions and identities.

## Portable format

The source knowledge-base extraction used for this task is an inert directory at `/workspace/scratch/1e5ab00a904f/forward-output/create-kb-reference`. After reviewing `tools/validate_skill.py`, run:

```sh
python3 -I -B /workspace/scratch/1e5ab00a904f/forward-output/create-kb-reference/tools/validate_skill.py /workspace/scratch/1e5ab00a904f/forward-output/create/skills/release-note-checker
```

If that temporary reading copy has been removed, use the supplied builder's `kb extract --output` command with a fresh non-discovery directory. It verifies source hashes before extracting. Point the command above at that new extraction. Never extract the knowledge base into a live skills directory.

## Evidence schemas

Use the supplied builder to validate the original record contracts and canonical-rule cross-fields:

```sh
python3 -I -B /workspace/scratch/1e5ab00a904f/skill-builder-project/skills/skill-builder/scripts/skill_builder.py check --record /workspace/scratch/1e5ab00a904f/forward-output/create/evidence/rule-traceability.json --record /workspace/scratch/1e5ab00a904f/forward-output/create/evidence/host-capabilities.json --record /workspace/scratch/1e5ab00a904f/forward-output/create/evidence/evaluation-receipt.json --record /workspace/scratch/1e5ab00a904f/forward-output/create/evidence/install-manifest.json --record /workspace/scratch/1e5ab00a904f/forward-output/create/evidence/source-review.json
```

This command is local, does not execute the runtime skill, does not fetch schemas, and does not install dependencies. It verifies preservation plus structure and cross-field consistency; it cannot prove the evidence is true.

## Independent outcome checks

Run each selected `evals/panel.json` case in a fresh authorized agent context with the exact runtime bytes and raw input. Keep the panel and grader outside the supplied note. Preserve the response and all tool effects, then assess the contract's meaning. Record every attempt and exact identity. Do not call an authored expected example a passing execution. The current build has no completed independent agent trial, native host trial, or clean no-skill comparison.
