# Changes

## 0.1.0-source — 2026-11-23

Created a source-only instruction skill for release-note consistency review. Added scope-sensitive contradiction checks, support-limited certainty checks, compatibility questions, source-linked output, partial/blocked handling, and explicit nonexecution/nonpublication boundaries.

Added an authored example, a 14-case panel, all-99 rule decisions, exact-file structural evidence, schema records, and explicit support limits. No prior published release, installation, migration, or rollback state exists. Independent-agent dispatch was blocked by the session thread limit. No behavioral reliability, performance improvement, native-host support, or public-reuse claim is made.
