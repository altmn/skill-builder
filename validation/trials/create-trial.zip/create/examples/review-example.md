# Example review

This is an authored illustration of the output contract, not an observed agent-test result. Its source is `contradictory-note.txt`. Sentence labels S1–S4 refer to the four sentences in that file.

**Scope and coverage:** complete review of the supplied Version 2.1 note. This checks internal wording and stated support only; it does not verify actual product behavior.

| ID | Category | Supplied evidence | Issue | Concrete question |
|---|---|---|---|---|
| R1 | Possible internal conflict; missing compatibility assumption | S1: “Python 3.10 and later”; S2: “Installation requires Python 3.12” | The minimum supported version and installation requirement differ. They could describe different stages, but the note does not establish that distinction. | Does Python 3.12 apply only to installation, and can the installed package run on Python 3.10–3.11? Which installation paths support those versions? |
| R2 | Apparent internal conflict; unsupported certainty | S3: “All existing integrations remain compatible”; S4: “old tokens stop working” | Any existing integration using an old token would be affected. The blanket compatibility claim lacks an exception or evidence establishing its scope. The note does not identify which integrations use old tokens. | Are integrations using old tokens excluded from the compatibility promise, or must they migrate before upgrading? What supplied compatibility evidence supports the remaining scope? |
| R3 | Missing compatibility assumptions | S4: “authentication configuration was replaced” and “old tokens stop working” | The note does not identify affected configurations, replacement credentials, or the transition condition. These omissions prevent the reader from knowing what an existing deployment must change. | Which configuration fields and token types are affected, when do old tokens stop working, and what transition must an existing integration complete? |

## Questions to resolve

1. **R1:** distinguish installation and runtime requirements, including the usable path for Python 3.10–3.11.
2. **R2:** define the compatibility promise's exceptions and the evidence for its stated scope.
3. **R3:** specify affected authentication settings/tokens and the transition conditions.

The review supplies no replacement release note, migration implementation, or invented product behavior. Equivalent wording that meets the contract is acceptable.
