# Codex integration boundary

Primary intended integration target: Codex. This is a source-only candidate. No native Codex version, discovery root, loader, implicit selection, permission policy, or live installation has been exercised for this artifact.

The runtime uses only portable `name` and `description` frontmatter and Markdown. No `allowed-tools`, `user-invocable`, implicit-invocation policy, hooks, or native metadata fields are declared. The host must supply the selected SKILL.md text, the user's note, and a response channel. A host text reader is optional for a selected file; pasted text needs no file tool. If a reader is unavailable or denied, ask for pasted text and retain a blocked file-read outcome.

For a local source review, point an authorized agent at the exact SKILL.md path and provide the note. Reading a named file this way is not native discovery. If future installation is requested, use the selected surface's actual installation procedure and verify the artifact it activates. Do not guess a live directory or assume command syntax based on another product.

Documentation basis is the supplied Skill Builder Codex guide and knowledge-base `handbook/04-portability.md`, with a documented research date of 2026-11-22. No current web documentation was checked in this source-only task. Accordingly no current discovery-path or supported-version claim is made.

## Separate support axes

| Axis | Current evidence |
|---|---|
| Portable format | Exact-file local validator result in `../evidence/format-results.json` |
| Native discovery / implicit activation | Not run |
| Complete agent outcome | Not run; independent dispatch blocked by agent thread limit |
| Host safety enforcement | Not run; runtime boundaries are advisory instructions |
| Maintenance support | No supported-version commitment or service promise |

Claude Code, Grok Build, Grok Bot, and custom API hosts are untested. This project supplies no secondary-host configuration and claims no equivalence across their permission or invocation semantics.

Before claiming support, run the concrete panel in a clean authorized target host and record actual activated artifact identity, version, OS, policy, output, all tool effects, and every attempt. Add explicit/implicit selection, near misses, opt-out, missing/denied input, interruption, actual compaction where observable, changed-source reload, and duplicate-name cases. A clean no-skill comparison needs a separate context without this skill or inherited instructions. Do not install or mutate discovery roots just to satisfy this source-only request.
