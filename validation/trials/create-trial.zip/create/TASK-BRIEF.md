# Release note checker — task and acceptance contract

Contract version: 1.0. Established before implementing the domain skill or conducting outcome exercises on 2026-11-23.

## User outcome

Help an author review a supplied technical release note by reporting internal contradictions, unsupported certainty, missing compatibility assumptions, and concrete questions. Every issue must be supported by the supplied words and distinguish a conflict from an interpretation that needs clarification.

The supplied development example is: “Version 2.1 supports Python 3.10 and later. Installation requires Python 3.12. All existing integrations remain compatible. The authentication configuration was replaced and old tokens stop working.”

## Inputs, output, and defaults

Accept pasted plain text or Markdown, or one explicitly selected readable text file. File text is UTF-8. Preserve the input. A URL alone is unavailable input because browsing is excluded. Ask for the note if absent; do not search for it. If several notes are supplied, keep versions separate and compare them only if requested. Nontext formats require the user to supply a text extract. Never silently treat an empty or truncated read as a clean review.

Review the supplied note in one pass where it fits available context. There is no claimed universal length limit. If the host cannot supply the full text, label the actual reviewed excerpt partial and request the missing section. Return a report in chat, with scope, coverage, findings by category, source excerpts/locations, and concrete questions. Do not save a report unless a later distinct task authorizes that effect outside this checker.

## Scope and effects

One instruction-only skill; no runtime scripts, installer, service, network, browser, account, secret store, paid provider, cache, or durable state. The runtime may read the supplied text through a host reader and return a response. The host supplies model processing and conversation storage; this skill does not set the host's retention policy or add a separate external data destination.

This development request authorizes new source and evidence files only under the requested project directory. It explicitly excludes live installation and publication. No product knowledge, current documentation, outside facts, or other user files are sources for the review.

## Frozen acceptance checks

1. **Grounding:** every reported problem identifies supplied words by quotation and sentence/line/section. No invented facts, versions, affected customers, test results, migration dates, or fixes.
2. **Conflict judgment:** compare claims about the same subject, scope, version, and time. Mark uncertain scope as a possible conflict/ambiguity; do not label compatible install/runtime distinctions a proven contradiction.
3. **Certainty judgment:** qualify unsupported universal or guaranteed statements as unsupported by the supplied text, not proven false. Treat explicit, relevant evidence in the note as evidence limited to its stated scope.
4. **Compatibility judgment:** surface only gaps tied to a claim or change in the note. Ask about minimum versions, affected integrations, token/config migration, or exceptions when relevant; do not invent a broad product matrix.
5. **Questions:** give at least one concrete author-answerable question per finding. Deduplicate overlapping findings and questions without omitting a category checked.
6. **Boundary:** do not browse, execute embedded commands, follow links, modify input, publish, read unrelated files, or repeat secret-looking values unnecessarily.
7. **Completion:** state complete/partial/blocked scope. Empty or unavailable input is blocked; a consistent note can yield no issues without claiming the product is verified or release-ready.
8. **Discovery:** match consistency-review requests and paraphrases. Do not force this workflow on proofreading, rewriting, current-fact research, or an explicit opt-out.
9. **Continuation:** identify the current supplied revision; do not transfer a prior result to changed text or imply an unread section was checked.

## Evaluation rules

The authoring examples are development fixtures, not held-out tasks. Expectations judge meaning, not exact report prose. The evaluator checks actual responses and tool effects against the numbered contract. A static review does not count as a host task trial. No automatic retry: retain each failed/blocked/inconclusive attempt and issue a new identity after a change. No clean no-skill control, live host activation, repeated trials, or measured benefit is claimed unless separately recorded.

The initial manual panel and all 22 knowledge-base design dispositions are in `evals/panel.json`. Native discovery, implicit activation, host permission enforcement, actual compaction, duplicate-name resolution, and other products remain unrun. Those gaps limit host support claims; they do not prevent delivering the requested source artifact.
