# Source provenance and neutral identifiers

The handbook is intended for general skill-project use. The full historical research remains available: 5,375 file records, 25,693 instruction records, 136 skill-artifact records, 99 rules, detailed narrative audits, and all original finding IDs. Stable record IDs, commit identities, blob identities, original source hashes, numeric line positions, review judgments, and execution limits have been retained.

## Project identity and source locations

The consolidated Markdown introduction contains the one project inspiration link. Historical source locations elsewhere use a **neutral namespace**: `reference-project` in paths and display text, `REFERENCE_PROJECT` for uppercase identifiers, and corresponding underscore or camel-case aliases where source syntax needs them. These are explicit presentation aliases, not new upstream paths or executable commands.

A machine-readable locator such as `reference:blob/REVISION/bin/reference-project-team-init#L43-L59` consists of a source operation, immutable revision, normalized path, and line selection. The original repository root is obtained from the linked introduction. Replacing the neutral namespace with that repository’s short name recovers the original path. The same rule applies to the related artifacts repository suffix. Historical moving-branch links remain labeled as such; a `main` link does not become immutable by being included here.

Human-readable source links open [the offline source reference page](source-reference.html), which accepts the consolidated Markdown file or its public project URL. It resolves the exact upstream URL without background network requests. The helper below does the same from the extracted package root:

```sh
python3 methods/source_reference.py 'reference:blob/ccd80de8ebdd7ca3384cc54bc138b53cd311a732/bin/reference-project-team-init#L43-L59'
```

The helper prints a URL; it does not retrieve source or execute it. A source link is an invitation to inspect evidence, not permission to run an installer or command described by that evidence.

## What a retained hash means

The `sha256`, `git_blob`, byte count, line count and block hash in historical source catalogs describe the **original source bytes at the recorded revision**. They are deliberately unchanged by identifier normalization. An excerpt containing a neutral alias is an adapted display excerpt and must not be represented as a verbatim quote or hashed as if it were the original source. Package file hashes are separate and appear in `MANIFEST.json` and `SHA256SUMS`.

The renamed snapshot is [reference-snapshot.json](reference-snapshot.json). It separately records package version `1.102.2`, runtime `VERSION` content `1.102.2.0`, and full commit identity. New findings from the supplied review cite their evidence origin and do not silently raise the original ledger’s review-depth counts.

## Historical evidence and later checks

The original validator test receipt and artifact-validation record are retained under `validation/history/`. In particular, the original browser-rendering result remains **blocked**. Current local tests, package checks and any new browser attempt have their own receipts. No old receipt is reattached to new code or promoted into a live-host compatibility result.

Search descriptions that previously shared a `ranges` field with numeric intervals now appear separately as `search_descriptions`; original numeric intervals and source hashes are preserved. An explicit full-file read can be represented as `[1, lines]` only where the historical record actually says the entire file was read. A description alone is not converted into new credited coverage.

The [review follow-up register](../audits/review-followups.md) and documentation evidence register distinguish the supplied report’s observations, retained historical documentation claims, and newly performed local checks. Unknown document revisions, missing source snapshots, unexecuted host recipes and unreviewed source branches remain explicit.

## Preservation accounting

[The preservation receipt](../validation/preservation-audit.json) records original artifact identities, retained record counts and checked invariants. Files were renamed only where a neutral identifier was needed; derived readers and views were regenerated from complete canonical content. No evidence catalog or detailed audit was replaced by a shorter summary. The original source checkout was not part of the supplied archive and is not newly bundled here.
