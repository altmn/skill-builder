# Primary sources

Research baseline: November 22, 2026 (America/Los_Angeles). Changing documentation was checked online during the dated research; repository findings use exact commits. Facts, static inferences, executed results and recommendations are labeled separately in the reports. These retained records are documentation evidence, not live-host tests. Conversation retrieval references remain supplementary metadata. [Documentation evidence captures](host-documentation-register.json) and [provenance](PROVENANCE.md) record revision and capture limitations.

## Reference snapshot

- Project identity: the inspiration link in the [consolidated Markdown introduction](../skill-project-knowledge-base.md).
- Pinned source: `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`.
- Package version: `1.102.2`; runtime `VERSION`: `1.102.2.0`.
- Commit timestamp: November 22, 2026, 5:08:54 p.m. Pacific (November 23, 01:08:54 UTC).
- All-file hashes and pinned source locators: [file-review.json](../catalogs/file-review.json).
- OpenAI public creator commit: `49f948faa9258a0c61caceaf225e179651397431`.

## S01

[Agent Skills specification](https://agentskills.io/specification)

Portable folder/frontmatter contract, required fields, limits and optional extensions.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S02

[Adding skills support to an agent](https://agentskills.io/client-implementation/adding-skills-support)

Progressive disclosure, discovery conventions and trust considerations; paths not mandated by format.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S03

[OpenAI Build skills](https://learn.chatgpt.com/docs/build-skills)

Current Codex discovery roots, symlinks, invocation, openai.yaml and plugin distribution.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S04

[Claude Code Extend Claude with skills](https://code.claude.com/docs/en/skills)

Invocation semantics; allowed-tools is temporary pre-approval rather than tool exclusion; product-specific frontmatter.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S05

[Grok Build Skills Plugins and Marketplaces](https://docs.x.ai/build/features/skills-plugins-marketplaces)

Native SKILL.md support, paths, field semantics, Claude compatibility claim, user .agents discovery.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S06

[Grok Bot Skills and routines](https://docs.x.ai/grok-bot/skills-routines-and-automations)

Separate Grok Bot reusable skills and routines; no unchanged local-folder upload guarantee established.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S07

[xAI Function calling](https://docs.x.ai/developers/tools/function-calling)

Model requests function call; client executes and returns result.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S08

[OpenAI public skill-creator SKILL.md](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/SKILL.md)

Concision, resource separation, progressive disclosure, initialization and validation workflow. Local pinned checkout independently available.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S09

[OpenAI public skill-creator quick_validate.py](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/scripts/quick_validate.py)

Pinned source reviewed locally and executed: accepts empty required strings and directory mismatch; rejects standard compatibility field. Web retrieval of this pinned URL failed; git retrieval succeeded.

Evidence: pinned-code-and-executed-check. Accessed 2026-11-22.

## S10

[Agent Skills Best practices](https://agentskills.io/skill-creation/best-practices)

Real expertise, coherent scope, moderate detail, conditional resource loading, execution trace feedback.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S11

[Agent Skills Evaluating skill output quality](https://agentskills.io/skill-creation/evaluating-skills)

Realistic cases and fixtures, clean contexts, baseline comparison and output/timing evidence.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S12

[Agent Skills Optimizing descriptions](https://agentskills.io/skill-creation/optimizing-descriptions)

Separate trigger evaluation, positives and difficult near-miss negatives, initial query set.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S13

[Anthropic Demystifying evals for AI agents](https://www.anthropic.com/research/demystifying-evals-for-ai-agents)

Code/model/human graders, capability versus regression checks, repeated-trial reliability.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S14

[OpenAI Evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices)

Task-specific evaluations, calibration and logging; legacy Evals platform deprecation dates.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S15

[OpenAI Agent approvals and security](https://learn.chatgpt.com/docs/agent-approvals-security)

Sandbox versus approval policy; explicit untrusted approval setting retirement.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S16

[Grok Build Permissions](https://docs.x.ai/build/features/permissions)

Tool call gating and deny precedence are separate from sandbox controls.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S17

[Grok Build Sandbox](https://docs.x.ai/build/features/sandbox)

Sandbox off by default; profiles and platform-specific network/credential limitations.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S18

[OWASP Top 10 for LLM applications project](https://owasp.org/projects/top-10-for-large-language-model-applications)

Project expanded into broader GenAI security initiative and directs to risk taxonomy.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S19

[Agent Skills Using scripts](https://agentskills.io/skill-creation/using-scripts)

Dependency declarations, noninteractive interfaces, runtime prerequisites and predictable execution.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S20

[Anthropic Advanced tool use](https://www.anthropic.com/research/advanced-tool-use)

On-demand tool discovery and code orchestration reduce context burden in reported systems; no universal speedup inferred.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S21

[GitHub Secure use reference](https://docs.github.com/en/actions/reference/security/secure-use)

Immutable workflow dependency guidance and lockfiles preferred where available.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S22

[GitHub Workflow dependency lockfiles](https://docs.github.com/en/actions/concepts/security/workflow-dependency-lockfiles)

Direct and transitive actions locked with repository identity; reusable workflow calls remain separate.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S23

[GitHub Locking action dependencies](https://docs.github.com/en/actions/how-tos/secure-your-work/lock-workflow-dependencies)

Current feature eligibility listed as GitHub Enterprise Cloud; generation/review process.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S24

[SLSA v1.2 Build provenance](https://slsa.dev/spec/v1.2/build-provenance)

Approved provenance format describes build origin.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S25

[SLSA v1.2 Verifying artifacts](https://slsa.dev/spec/v1.2/verifying-artifacts)

Verification against trusted builder, signature, artifact and expected build parameters.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S26

[W3C: Understanding WCAG 2.2 contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html)

Large-text threshold is expressed in points; evidence for the reference-project unit correction.

Evidence: primary-source-documentation. Accessed 2026-11-22.

## S27

[Tailscale policy-file syntax](https://tailscale.com/docs/reference/syntax/policy-file)

Current access-control syntax; evidence for the invalid drop-action example.

Evidence: primary-source-documentation. Accessed 2026-11-22.
