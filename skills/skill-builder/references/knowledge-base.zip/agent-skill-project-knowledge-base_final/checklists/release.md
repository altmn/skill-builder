# Release checklist

Record version, source commit, package hash, date, target hosts and reviewer. Use the [release playbook](../handbook/09-installation-and-releases.md) and applicable rules in [the audit checklist](audit.md).

## Blocking decisions

- [ ] No unresolved unauthorized-effect, data-loss, credential-disclosure or confinement defect affects a claimed supported capability.
- [ ] Required checks completed against the exact candidate; zero checks, skipped providers and unknown outcomes are not green.
- [ ] The package includes required files and licenses and excludes local secrets, caches and private traces.
- [ ] Generated files match their sources and target-host semantics.
- [ ] Public support, performance and safety claims match evidence.

## Behavioral evidence

- [ ] Representative task and negative-trigger cases meet acceptance conditions.
- [ ] Missing capability, denied action and interruption paths produce honest outcomes.
- [ ] Changed resources and trust boundaries have meaningful contract tests.
- [ ] Evaluation attempts, exclusions, versions and limitations are recorded.
- [ ] Every advertised host/platform has its stated level of evidence.

## Lifecycle evidence, when applicable

- [ ] Fresh/repeat install preserves unrelated user files.
- [ ] Failed update and migration leave a documented recoverable state.
- [ ] Stable/development resolution and rollback behavior match documentation.
- [ ] Uninstall removes owned integrations and leaves chosen user data intact.
- [ ] Published artifact identity can be verified after the authorized release action.

## Publication

- [ ] Release notes explain changed behavior, compatibility, migration and limits.
- [ ] The destination and external action are covered by current authorization.
- [ ] Actual publication is verified; prepared-but-unpublished artifacts are labeled accurately.

Final verdict: READY / BLOCKED / READY WITH EXPLICIT NONBLOCKING LIMITS. List blockers by ID; do not replace the verdict with an average score.

## Consistency and preservation additions

- [ ] Rebuild derived readers and catalogs from declared canonical inputs; fail on drift, missing references or invalid source ranges.
- [ ] Validate all shipped evidence examples and templates against their declared schemas.
- [ ] Confirm per-stream response limits, capture-storage policy, deadline, descendant cleanup and retention wherever subprocess capture is used.
- [ ] For each lifecycle writer, check local edits, untracked files, foreign folders, malformed settings, missing settings and repeat-install preservation.
- [ ] Retain documentation captures and dated update events without transferring old passes to new content.
- [ ] State original-material licensing and third-party exceptions; unresolved rights-holder license selection blocks public reuse.
