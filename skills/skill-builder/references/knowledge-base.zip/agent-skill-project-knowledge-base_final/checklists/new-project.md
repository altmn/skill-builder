# New-project checklist

Use [the creation playbook](../handbook/11-create-a-skill.md). Keep evidence with each completed phase.

- [ ] Real examples define a task, inputs, expected outcome and boundary cases.
- [ ] Independent acceptance conditions exist before optimization.
- [ ] Instruction-only versus resource/runtime complexity is justified.
- [ ] Required capabilities, side effects and external data flows are listed.
- [ ] The portable core has a clear discovery description and output contract.
- [ ] Conditional references load at an explicit decision point.
- [ ] Deterministic resources have safe input/output and failure contracts.
- [ ] Codex integration is documented and checked against current primary sources.
- [ ] Structure, resource, outcome and denied-path checks are separate.
- [ ] A clean no-skill baseline and meaningful negative cases are included.
- [ ] Secondary hosts have explicit adapters and honest evidence tiers.
- [ ] Package contents, licenses, install effects and removal are inspectable.
- [ ] README examples and commands match the actual release.
- [ ] Release evidence identifies exact package bytes and outstanding limits.

Do not mark live-host, runtime or publication checks complete when only static inspection occurred.

## Reuse and evidence additions

- [ ] Select an application profile and capability modifiers; record justified overrides and unassessed rules.
- [ ] Follow the completed example's task-to-artifact path while retaining only machinery needed for this task.
- [ ] Validate filled evidence records against the versioned schemas; preserve mixed statuses and unknown usage.
- [ ] If claiming host behavior, identify the actual loaded artifact and run applicable continuation, source-change and collision cases.
- [ ] Name every state-changing lifecycle entrypoint and its preservation contract when installation is needed.
