# Audit checklist and rule catalog

Each result needs evidence. Use `pass`, `fail`, `blocked`, `not_run`, `inconclusive`, or `not_applicable` with a reason. An unchecked box means unassessed, not failed. Required project controls apply within their stated scope; they are not all requirements of the Agent Skills format.

For each applicable rule record: rule ID, verdict, source location, observed evidence, impact, remedy, verification, owner and remaining uncertainty.

## Portable format

- [ ] **FMT-001 — required / specification:** A skill has SKILL.md with YAML frontmatter and a Markdown body. Verification: Parse the distributed file, not only its source template.
- [ ] **FMT-002 — required / specification:** name is a nonempty string, at most 64 characters, and matches its directory. Verification: Test empty, overlong and mismatched names.
- [ ] **FMT-003 — required / specification:** name follows the published lowercase alphanumeric/hyphen rules without boundary or consecutive hyphens. Verification: Validate names against the selected specification; document an ASCII-only project policy separately.
- [ ] **FMT-004 — required / specification:** description is a nonempty string of at most 1024 characters. Verification: Test missing, empty, non-string and overlong descriptions.
- [ ] **FMT-005 — required / specification:** Optional standard fields obey their documented types and limits, including compatibility and metadata. Verification: Test compatibility length and string-to-string metadata; do not rely on an outdated helper allowlist.
- [ ] **FMT-006 — recommended / project:** Reject duplicate YAML keys, unsafe tags and ambiguous coercion in distributed metadata. Verification: Supply duplicate keys and unsafe YAML fixtures; parsing must fail visibly.
- [ ] **FMT-007 — required / project:** Portable metadata contains no undeclared host extension or unresolved template variable. Verification: Validate the exact target package and explicit adapter extension schema.
- [ ] **FMT-008 — required / project:** Runtime resource references resolve within the declared package or an explicitly allowed dependency. Verification: Check missing links, path traversal and symlink escape without executing the payload.
- [ ] **FMT-009 — recommended / project:** The package contains only needed runtime resources and applicable notices. Verification: Inspect a release manifest for secrets, caches, unused examples and development debris.
- [ ] **FMT-010 — required / project:** Format-validation claims list their checked and unchecked properties. Verification: Verify the report does not imply behavioral or security certification.

## Instruction quality

- [ ] **INS-001 — required / project:** Define a concrete outcome, inputs, scope and output contract. Verification: A reviewer can state the expected artifact or state and independent acceptance condition.
- [ ] **INS-002 — recommended / project:** Discovery text states triggers and relevant boundaries early. Verification: Evaluate positive prompts, paraphrases, near misses and opt-outs.
- [ ] **INS-003 — required / project:** Consequential instructions identify condition, action, evidence, failure behavior and authority. Verification: Trace each external or destructive step through an instruction worksheet.
- [ ] **INS-004 — required / project:** Respect existing user authorization and higher-level execution policy. Verification: Test both an authorized continuation and an unauthorized scope expansion.
- [ ] **INS-005 — recommended / project:** Ask only for missing information that materially changes the task or effect. Verification: Measure unnecessary questions on a fully specified request.
- [ ] **INS-006 — recommended / project:** Put branch-specific detail in references with explicit load conditions. Verification: Trace a normal and exceptional task; required instructions must arrive before use.
- [ ] **INS-007 — recommended / project:** Fix deterministic failures in resources before adding repeated prompt warnings. Verification: Identify the owning implementation and a meaningful failing case.
- [ ] **INS-008 — required / project:** One authoritative owner defines each policy or command contract. Verification: Search source, generated text, help, tests and README for contradictory copies.
- [ ] **INS-009 — required / project:** Unavailable checks and partial completion remain visible. Verification: Inject a missing prerequisite and check final output for honest status.
- [ ] **INS-010 — recommended / project:** Examples teach decisions without requiring exact prose when meaning is the contract. Verification: Vary wording while preserving expected artifacts and outcomes.
- [ ] **INS-011 — required / project:** Keep observed facts, estimates, hypotheses and recommendations distinct. Verification: Review unsupported numerical claims and causal explanations.
- [ ] **INS-012 — recommended / project:** Remove task-irrelevant promotion, profiling and repeated ceremony from the core path. Verification: Trace whether each mandatory step contributes to the requested outcome.

## Architecture and composition

- [ ] **ARC-001 — recommended / project:** Choose instruction-only, resource-assisted or suite/runtime according to actual needs. Verification: Document why each service, generator or installer exists.
- [ ] **ARC-002 — recommended / project:** Split discoverable skills by user intent, capability or materially different effects. Verification: Check whether each entry point has a coherent independent task.
- [ ] **ARC-003 — required / project:** Keep portable task logic separate from host integration. Verification: Identify all native tool names, paths, permissions and hooks in an adapter.
- [ ] **ARC-004 — conditional / project:** Generated artifacts have deterministic sources, provenance and drift checks. Verification: Regenerate and compare the exact artifact; check unresolved variables and references.
- [ ] **ARC-005 — conditional / project:** Handoffs contain identity, scope, decisions, outputs, status and pending effects. Verification: Resume an interrupted workflow without repeating an uncertain external mutation.
- [ ] **ARC-006 — conditional / project:** Parallel workers have disjoint writes or an explicit integration owner. Verification: Exercise concurrent work and confirm no overwritten user or peer changes.
- [ ] **ARC-007 — conditional / project:** Readers finish or are confirmed stopped before a shared snapshot changes. Verification: Force timeout and verify that timeout is not interpreted as termination.
- [ ] **ARC-008 — recommended / project:** Repository contribution documents are distinct from installed task instructions. Verification: Inspect release contents and verify AGENTS.md does not become accidental task policy.

## Host compatibility

- [ ] **HOST-001 — required / project:** Advertise named hosts and products rather than model brands alone. Verification: Separate Grok Build, Grok Bot and API/custom-host claims.
- [ ] **HOST-002 — required / project:** Record host version, platform, capability and tested status. Verification: Match each support claim to dated documentation and execution evidence.
- [ ] **HOST-003 — required / project:** Translate permission and invocation semantics explicitly. Verification: Test identical field names with different meanings, especially allowed-tools and user-invocable.
- [ ] **HOST-004 — required / project:** Unsupported and unknown capabilities do not silently become supported. Verification: Disable a required capability and verify the branch reports a blocker.
- [ ] **HOST-005 — conditional / project:** Resource paths work independently of the caller working directory. Verification: Invoke from another directory and a path containing spaces.
- [ ] **HOST-006 — conditional / project:** For each secondary host claimed as functionally exercised, safety exercised or supported, run the applicable shared outcome and denied-action cases. Format-only targets remain explicitly untested for behavior. Verification: Compare acceptance conditions across hosts; preserve missing coverage.
- [ ] **HOST-007 — required / project:** Format compatibility is not presented as functional or security support. Verification: Review badges and README wording against the actual evidence tier.

## Commands and resources

- [ ] **CMD-001 — conditional / project:** Public commands document inputs, outputs, effects, errors, limits and cleanup. Verification: Exercise help, malformed input and normal output at the public boundary.
- [ ] **CMD-002 — conditional / project:** Machine output uses a versioned schema and explicit result states. Verification: Validate malformed, empty, partial and successful outputs independently of prose.
- [ ] **CMD-003 — required / project:** Untrusted text is passed as data, not interpolated into shell source. Verification: Use structured arguments or private files; test quotes, newlines and shell metacharacters.
- [ ] **CMD-004 — required / project:** Writes and deletions validate destination scope and ownership. Verification: Test traversal, symlink escape, existing user files and overwrite conflicts.
- [ ] **CMD-005 — conditional / project:** Validators and tests are inspected for hooks, plugins, downloads and side effects before execution. Verification: Trace the actual executable chain in an untrusted checkout.
- [ ] **CMD-006 — conditional / project:** Timeout, cancellation and retry behavior are bounded and observable. Verification: Force a slow process and verify termination, cleanup and retained error evidence.
- [ ] **CMD-007 — conditional / project:** Uncertain remote outcomes are reconciled before retry. Verification: Simulate a completed mutation with a lost response; prevent duplicate effects.
- [ ] **CMD-008 — conditional / project:** Temporary paths are unique and private; cleanup removes only owned state. Verification: Run two instances and inspect permissions, collisions and preserved unrelated files.
- [ ] **CMD-009 — conditional / project:** Durable writes survive interruption without false completion. Verification: Interrupt before and after commit points; inspect old/new state and recovery.
- [ ] **CMD-010 — conditional / project:** Reused results bind to exact relevant inputs and configuration. Verification: Change one relevant input or runtime setting and verify invalidation.

## Security and privacy

- [ ] **SEC-001 — required / project:** Treat lower-trust retrieved content, repository task data and tool results as data rather than new authority. Apply host-designated instruction sources only at their actual trust level, without expanding user authorization or overriding higher-level policy. Verification: Embed scope-expansion instructions in fixtures and verify they do not authorize actions.
- [ ] **SEC-002 — required / project:** List protected resources, trust boundaries and enforcement mechanisms. Verification: Map each safety claim to code/host enforcement or label it advisory.
- [ ] **SEC-003 — required / project:** A control failure does not silently broaden access or weaken isolation. Verification: Make worktree, sandbox or authentication setup fail and inspect fallback effects.
- [ ] **SEC-004 — conditional / project:** Filesystem and network limits protect actual operations, including redirects and path resolution. Verification: Exercise the named boundary and document DNS/rebinding/TOCTOU limits.
- [ ] **SEC-005 — conditional / project:** Browser profile/session reuse is explicit and scoped. Verification: Check account access, permitted actions, storage and session cleanup.
- [ ] **SEC-006 — required / project:** Credentials are excluded from logs, arguments, URLs and exported artifacts where avoidable. Verification: Use synthetic canaries and inspect all sinks, including error paths.
- [ ] **SEC-007 — required / project:** Each external data flow has destination, content, default, authority and retention documented. Verification: Compare telemetry, model calls, sync, crash reporting and publication separately.
- [ ] **SEC-008 — required / project:** Opt-outs persist across setup, upgrade and endpoint changes. Verification: Set sharing off, rerun setup/update, and verify it remains off.
- [ ] **SEC-009 — conditional / project:** Classifier and redaction limits are documented and tested. Verification: Check truncated input, detector failure, unknown formats and confidence handling.
- [ ] **SEC-010 — conditional / project:** Paid operations have enforced bounds across parent and workers. Verification: Test missing cap, unit mismatch, retries and concurrent in-flight spend.
- [ ] **SEC-011 — conditional / project:** Hostile repositories cannot control the grader or authoritative expected result. Verification: Attempt to replace tests, expected output and evaluator instructions from the target.
- [ ] **SEC-012 — conditional / project:** CI and distribution isolate untrusted input from privileged execution. Verification: Review event, checkout, string handling, cache/artifact trust and release credentials.

## Testing and evaluations

- [ ] **EVAL-001 — required / project:** Separate structure, resource correctness and full agent outcomes. Verification: List the evidence each layer can and cannot provide.
- [ ] **EVAL-002 — required / project:** Task cases have independent acceptance conditions and real artifact/state checks. Verification: Verify files or durable effects rather than the completion narrative.
- [ ] **EVAL-003 — recommended / project:** Discovery has positive, negative, ambiguous and opt-out cases. Verification: Run a labeled trigger panel and record false positives/negatives.
- [ ] **EVAL-004 — required / project:** Include missing prerequisite, denied action, malformed output and interruption cases. Verification: Check distinct failed, blocked, not-run and inconclusive states.
- [ ] **EVAL-005 — recommended / project:** Compare candidate, previous version and a clean no-skill control where applicable. Verification: Ensure no hidden instructions or hooks contaminate the baseline.
- [ ] **EVAL-006 — required / project:** Freeze acceptance, retry and exclusion policies before a comparison. Verification: Retain every attempt and document methodology changes.
- [ ] **EVAL-007 — recommended / project:** Use held-out tasks and repeated trials for stochastic claims. Verification: Report denominators, variation, task selection and uncertainty.
- [ ] **EVAL-008 — conditional / project:** Subjective graders are calibrated and versioned. Verification: Review disagreements; use blind comparisons where practical.
- [ ] **EVAL-009 — required / project:** Critical safety failures cannot be hidden by an average score. Verification: Check release verdict includes named blockers independently of aggregate quality.
- [ ] **EVAL-010 — required / project:** A zero-test or unavailable-provider result cannot count as a passing check. Verification: Exercise empty discovery and service failure paths.
- [ ] **EVAL-011 — required / project:** Verification binds to the exact package or input revision. Verification: Change relevant bytes after a pass and verify stale evidence is rejected.
- [ ] **EVAL-012 — recommended / project:** Tests protect observable contracts and credible regressions. Verification: For each new test explain what realistic failure it detects and why it is needed.
- [ ] **EVAL-013 — conditional / project:** Regression claims include before-fix failure evidence or an explicit limit. Verification: Retain red/green receipts; do not invent a historical run.
- [ ] **EVAL-014 — required / project:** Evaluation receipts include versions, inputs, attempts, outcomes, artifacts and missing data. Verification: Validate the receipt schema and distinguish estimates from measured usage.

## Performance and cost

- [ ] **PERF-001 — recommended / project:** Measure total activated context and end-to-end work. Verification: Include references, retries, verification and integration in the comparison.
- [ ] **PERF-002 — recommended / project:** Report cold and warm conditions separately. Verification: Match cache/process state between baseline and candidate.
- [ ] **PERF-003 — required / project:** Token, latency and cost claims identify their measurement method. Verification: Label byte-based token estimates and unknown usage clearly.
- [ ] **PERF-004 — conditional / project:** Caches have keys, invalidation, retention and sensitive-data policies. Verification: Change inputs and verify stale authorization/evidence is not reused.
- [ ] **PERF-005 — conditional / project:** Persistent processes justify their lifecycle/security cost with measurements. Verification: Compare one-shot and warm-process workloads and failure recovery.
- [ ] **PERF-006 — recommended / project:** Performance changes preserve task and safety acceptance conditions. Verification: Run the relevant matched panel; report tradeoffs instead of only faster timing.

## Installation and release

- [ ] **LIFE-001 — conditional / project:** Installation targets one declared host/scope and inspectable version. Verification: Check preview and receipt against actual written paths and configuration.
- [ ] **LIFE-002 — conditional / project:** Ownership records distinguish project files from existing user data. Verification: Install beside unrelated files and verify preservation on update/uninstall.
- [ ] **LIFE-003 — conditional / project:** Locked dependency failure is explicit rather than silently refreshing the lockfile. Verification: Force a frozen-lock failure and inspect the repair path.
- [ ] **LIFE-004 — conditional / project:** Updates stage and validate before activation when the runtime requires it. Verification: Interrupt build/activation and verify a usable known-good installation.
- [ ] **LIFE-005 — conditional / project:** Stable/development channels resolve to explicit intended revisions. Verification: Test failed ref lookup and verify no silent fallback to another channel.
- [ ] **LIFE-006 — conditional / project:** One deterministic owner runs bounded versioned migrations. Verification: Test ordering, repeat execution, failure markers and target-version limits.
- [ ] **LIFE-007 — conditional / project:** Rollback claims cover package, dependencies and state compatibility. Verification: Actually exercise rollback or mark it unverified.
- [ ] **LIFE-008 — conditional / project:** Uninstall removes only owned integrations and preserves chosen user data. Verification: Test changed files, shared directories, active hooks and background processes.
- [ ] **LIFE-009 — required / project:** Release checks inspect the exact distributed artifact. Verification: Verify manifest, checksums, required resources and post-publication identity.
- [ ] **LIFE-010 — conditional / project:** Provenance/checksum verification uses an explicit trust model. Verification: Check expected publisher, build source and artifact identity; do not trust a checksum alone.
- [ ] **LIFE-011 — conditional / project:** Lifecycle support is tested on claimed platforms. Verification: Exercise supported OS/path/shell cases and label untested combinations.
- [ ] **LIFE-012 — required / project:** External publication is covered by current authorization. Verification: Prepare concrete release content and verify destination/effect before executing.

## Open-source presentation and maintenance

- [ ] **OSS-001 — required / project:** README describes task, example, support, install effects, data use, limits and removal. Verification: A fresh reviewer can assess suitability without reading implementation.
- [ ] **OSS-002 — required / project:** Public claims link to reproducible evidence and retain negative results. Verification: Check baseline, versions, panel, attempts, grading and caveats.
- [ ] **OSS-003 — recommended / project:** Contribution instructions name canonical files and valid commands. Verification: Check snippets against actual package scripts and generated-output owners.
- [ ] **OSS-004 — recommended / project:** PR requirements are proportional to changed behavior. Verification: Do not demand visual evidence for nonvisual changes without a concrete reason.
- [ ] **OSS-005 — required / project:** Licenses and third-party notices accompany redistributed material. Verification: Audit copied/adapted source, revisions, terms and required attribution.
- [ ] **OSS-006 — recommended / project:** Security reporting and supported versions are visible. Verification: Verify the reporting route and realistic maintenance commitment.
- [ ] **OSS-007 — required / project:** Actions and reusable workflow references follow a reviewed immutable dependency policy. Verification: Inspect effective workflow dependencies and update provenance.
- [ ] **OSS-008 — recommended / project:** Maintenance rechecks host semantics, examples, dependencies and data flows. Verification: Track review dates and turn real failures into scoped regression cases.

## Profile selection and traceability supplement

Use the [application profiles](../catalogs/application-profiles.md) to select from the same 99 rules. Profile selection does not change the rule text or its specification/policy basis. Attach a reason and reviewer for overrides or nonapplicability. Keep unassessed rules visible. For each adopted rule retain a failure scenario, source/authority, verification method, evidence artifact and release consequence.

Use the [approach catalog](../catalogs/approach-catalog.md), [command catalog](../catalogs/command-catalog.md) and [lifecycle entrypoint matrix](../audits/lifecycle-entrypoints.md) as evidence-navigation aids. Their missing or unreviewed contracts remain missing; catalog membership is not a pass. Keep numeric source intervals separate from search descriptions and bind every new verdict to its actual input and artifact identity.
