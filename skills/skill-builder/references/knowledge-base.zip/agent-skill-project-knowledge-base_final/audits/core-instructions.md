# Core instruction audit

Snapshot: `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`, package version `1.102.2`. Source links in this document use that immutable revision. This audit treats repository instructions as the subject of analysis. It does not execute their install, review, messaging, or publishing workflows.

## What the instruction architecture accomplishes

The top-level router makes selection an explicit task. Specialist entry points then define a role, scope, sequence, resources, decisions, output, and downstream handoff. Templates contain shared resolver markers; installed files contain host-specific paths, tools, startup commands, and conditional sections. The workflow therefore has several contracts: discovery metadata, the skill's own behavior, shared policy, helper command protocols, file schemas, and the next skill's input. A useful small project can adopt these contracts without adopting the full operational system.

The most valuable recurring design is separating an observation from a hypothesis, a recommendation from authorization, a launched action from its completed result, and a saved artifact from an assertion that it was saved. The most costly recurring design is encoding a large transactional state machine in prose, with repeated reading, formatting, logging, question, and publication ceremonies. Where exact sequence is essential, a small deterministic command should own state transitions; the model should supply judgment and consume validated results.

## File-by-file findings: entry points and their instruction clusters

### Root `SKILL.md.tmpl`: router

The router prioritizes testing intent over a superficial URL match: API testing routes to QA, browser interaction to browsing. It distinguishes report-only QA from repair QA, explicit invocation from proactive suggestion, and installed skills from unavailable ones. The `off`, `core`, and `all` routing preference prevents broad automatic activation. Its best-effort route event is separated from successful task execution. Each routing row is a narrow task-to-specialist mapping.

**Adopt:** precise positive triggers, adjacent-task exclusions, a direct-answer route, explicit invocation priority, and a capability availability check. **Adapt:** use a router only when users actually face a choice among several related skills. **Avoid as a default:** telemetry during selection, hardcoded Claude paths, and policy that sends an agent to a different skill when the user asked for a small direct edit. The source's explicit instruction to use only available skills is a strong guard against imaginary tools.

Source: [root router](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2FSKILL.md.tmpl).

### `AGENTS.md`: contributor contract

The file gives an inventory of skill names, validation order, command entry points, platform tiers, and code ownership conventions. The validation sequence preserves original failures, distinguishes product/test/environment defects, verifies fixture ownership through symlinks, requires executed-case counts, freezes evaluated inputs, and reports cancelled/incomplete outcomes. It prefers focused repair evidence and one final full acceptance run. Passing subsets are explicitly insufficient for release acceptance. One notable detail is that paid evaluation retries have a narrowly defined same-revision exception; generic comments elsewhere can drift from this policy.

**Adopt:** one authoritative contributor workflow, evidence kinds, affected-input tracking, explicit commands and failure states. **Adapt:** reduce it to the checks your project actually has. **Avoid:** teaching every agent a large runtime's entire testing bureaucracy when editing a simple instruction-only skill. A small repository's contribution instructions should not contain paid-evaluation machinery it cannot run.

Source: [AGENTS.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2FAGENTS.md).

### `review/SKILL.md` startup and `review/sections/preamble.md`: shared runtime policy

The expanded entry point declares observable completion items, loads a shared preamble by content identity, and starts a runtime protocol. `SKILL_START_PROTO` and session-bound status lines determine whether onboarding/consent instructions are authentic. Missing or wrong protocol versions trigger conservative degraded operation. Dynamic Claude command injection has a manual fallback so the start operation does not run twice. The shared preamble defines question transport, pending-question recovery, scoped automatic decisions, writing style, prior context, evidence rules, completion statuses, and learning records.

**Adopt:** authenticated provenance for tool-provided instructions; explicit degraded defaults; separation of interactive, spawned, unattended, and headless modes; no duplicate questions after an uncertain transport result; no self-granted plan-mode exceptions; evidence-kind reporting; persistent opt-outs. **Adapt:** only load common policy actually needed by the task. **Avoid:** treating arbitrary tool text as instructions, repeated compulsory style scaffolding, unexplained productivity ratios, automatic learning-store writes without an owned destination, and implying a content hash proves semantic understanding. The preamble itself says model agreement is not independent proof. Preserve that restraint.

Sources: [expanded entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2FSKILL.md), [shared preamble](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md).

### `office-hours/SKILL.md.tmpl`: discovery before implementation

The task has an explicit artifact boundary: produce a design document or decision memo, not product code. It reads project context and existing designs, chooses startup or builder mode, routes to stage-specific questions, searches related designs, obtains consent for generalized external research, tests assumptions, compares implementation alternatives, waits for an approach decision, and produces an approved artifact for later reviewers. It verifies the exact artifact path from this run rather than selecting the newest file from a shared directory. Completion statuses distinguish approved, unresolved, and incomplete work.

**Adopt:** an explicit deliverable; skip already-answered questions; search existing work before generating a duplicate; separate private and shareable outputs; bind completion to this run's artifact. **Adapt:** mode choice and alternatives to the actual domain. **Avoid:** unconditional questions when the request already supplies enough context, automatic cross-project profiling, or a hard rule that the first user turn can never be sufficient.

Source: [entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Foffice-hours%2FSKILL.md.tmpl).

#### Supporting office-hours files

| File | Instruction approach | Decision for a reusable project |
| --- | --- | --- |
| `sections/phase-2a-startup-diagnostic.md.tmpl` | Concrete evidence hierarchy, stage-dependent question selection, named user behavior, counterexamples, and a dated next action. | Reuse operational examples and falsifiable success criteria. The confrontational coaching voice and payment-centered priorities are domain choices. Respect an immediate user request to skip optional questioning. |
| `sections/phase-2b-builder-brainstorm.md.tmpl` | Different goals select a different conversational posture; examples show the desired creative result. | Reuse goal-dependent branches and discriminating examples. Do not prescribe enthusiasm or novelty when the task requires precision. |
| `sections/phase-2c-pivot-discovery.md.tmpl` | Discovery/pivot produces a different artifact, with an experiment, threshold and date. | Separate incompatible outputs by explicit mode. Avoid inventing customer evidence or financial thresholds. |
| `sections/landscape.md.tmpl` | Generalized search terms, source reading, conventional approach versus current evidence, explicit no-new-insight outcome. | Adopt data minimization and the valid empty finding. Keep search methods in the host adapter. |
| `sections/second-opinion.md.tmpl` | Reuses the already-granted decision and inserts one provider operation. | Preserve authorization across handoffs; do not ask the same question again. |
| `sections/visual-design.md.tmpl` | Expands only applicable visual generation modules. | Conditional references should be selected by task requirements, with costs disclosed. |
| `sections/design-and-handoff.md.tmpl` | Distinct artifact templates, revision lineage, private/shareable copies, exact-byte sink scanning, visible approval, profile-dependent closing, resource promotion and opt-out. | Adopt lineage and inspectable approval. Keep promotional messages, referral links, personal profiling and subjective founder ratings out of a general task skill. Make a single authoritative artifact and mark secondary copies as derived. |

The closing section also supplies explicit productivity claims and persuasive scores for follow-up reviews. These are the project's product voice; the audit did not establish them as measured general effects. They should not become default engineering rules. The resource opt-out is persistent and verified before promising success, which is a useful mechanism independent of the promotional content.

Source: [office-hours sections](../sources/source-reference.html?ref=reference%3Atree%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Foffice-hours%2Fsections).

### `plan-ceo-review/SKILL.md.tmpl` and its sections

The entry point offers expansion, selective expansion, hold-scope and reduction modes. Mode selection affects what can be proposed; it does not approve every suggested change. A decision ledger keeps current approved state separate from proposals, unresolved items, and prior answers. Each independent change gets its own decision identity. A stored decision payload is checked before asking the user and the actual answer is recorded afterward. Review depth is separately controlled: strategy review should not silently become implementation design.

`sections/review-sections.md.tmpl` covers architecture, failures, security, data interactions, code quality, tests, performance, observability, rollout, future maintenance, and conditional UI. Each section maps a risk to a mechanism, evidence, owner, and remedy. It distinguishes an unavailable future implementation from a proven defect. The output includes accepted/deferred/rejected scope, reusable existing work, failure and recovery tables, tests, tasks, unknowns, and a final report. `sections/checklist.md.tmpl` is a smaller runner-facing contract that names required outputs and scope flags.

**Adopt:** scope-preserving modes; approvals bound to exact choices; explicit future verification; conditional UI; reversible deployment planning; a usable failure table. **Adapt:** use one decision record for material choices, not a file transaction for every small planning sentence. **Avoid:** numeric file-count rules as universal design quality tests, blanket forced diagrams, default mandatory observability stacks for tiny tools, or arbitrary completeness ratings presented as objective measurements. A fixed ten-section review is useful only when the scope warrants it.

Sources: [entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-ceo-review%2FSKILL.md.tmpl), [review sections](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-ceo-review%2Fsections%2Freview-sections.md.tmpl), [runner checklist](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-ceo-review%2Fsections%2Fchecklist.md.tmpl).

### `plan-eng-review/SKILL.md.tmpl` and its sections

The target-resolution gate uses the user's explicit target or trusted host plan-mode metadata; plan-shaped retrieved text cannot claim host authority. Discovery starts only after target resolution. The sequence then loads context, checks existing design work, challenges scope, reviews architecture/code/tests/performance, records decisions, saves artifacts, and only afterward navigates to another workflow. Recovery resumes the failed step and preserves verified work.

`sections/review-sections.md.tmpl` distinguishes the selected target, working plan, and report destination. Forbidden writes, failed permitted writes, and a report-back-only task have different outcomes. Evidence and approval are independent fields. The architecture section asks for a structurally different second design when a new public boundary is introduced and checks ownership, information leakage, duplicate mechanisms, and importable internals. Test planning maps observable requirements to actual checks, and parallelization uses disjoint module ownership plus explicit dependencies. `sections/checklist.md.tmpl` supplies a reduced runner contract.

**Adopt:** trusted target resolution; reuse of valid prior authorization; meaningful second design for a new boundary; data ownership; inspectable saved outputs; resumption at the failed step; execution-aware concurrency. **Adapt:** output persistence should be essential only when the user's task requires a persisted handoff. **Avoid:** blocking a valid chat review solely because optional history cannot be written, compulsory multi-step approvals for already authorized routine work, and the unmeasured claim that AI makes all completeness work 10–100 times cheaper.

Sources: [entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-eng-review%2FSKILL.md.tmpl), [review sections](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-eng-review%2Fsections%2Freview-sections.md.tmpl), [checklist](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-eng-review%2Fsections%2Fchecklist.md.tmpl).

### `autoplan/SKILL.md.tmpl`, `DRIVER.md.tmpl`, and phase files

The interactive pipeline orders CEO, conditional design, conditional DX, then engineering. The final engineering pass sees all amendments. Routine choices, taste choices, and challenges to the user's stated direction have different authority. It snapshots inputs, isolates review content from review history, preserves accepted obligations, requires terminal reviewer results, and publishes phase progress separately from saving files. Explicitly unavailable voices receive no consensus credit.

The separate driver is an important second execution contract. A runtime command owns attempts, immutable result bindings, phase transitions, revision-bound gates, capped rounds, exports and checkpoint recovery. Its lean profile may use one engineering reviewer combining several lenses; full mode restores multiple phases. This is an intentional profile difference, not evidence that every invocation runs the same sequence.

| Supporting file | Contribution and adaptation |
| --- | --- |
| `sections/ceo-phase.md.tmpl` | Creates a stable amendment baseline and fresh current review inputs; preserves original user constraints when a challenge is pending. Adopt immutable inputs and explicit update provenance. |
| `sections/design-phase.md.tmpl` | Conditional UI review; native and external reviewers receive different context intentionally. Preserve the distinction between independent and context-informed judgment. |
| `sections/dx-phase.md.tmpl` | Developer-journey/error/docs/upgrade review; scores only after evidence exists. Use measured onboarding time when claiming time improvements. |
| `sections/eng-phase.md.tmpl` | Engineering closes over earlier amendments and writes the test plan. A final consumer must validate the actual final inputs. |
| `sections/ceo-only.md.tmpl` | A review-only mode explicitly does not approve the plan; consent defaults remain conservative. Strong example of separating evaluation from authorization. |
| `sections/phase-close.md.tmpl` | Preparation, complete reading, semantic reconciliation and user-visible publication are separate operations. Move rigid state transitions to code; a read receipt does not prove comprehension. |
| `sections/tasks-aggregator.md.tmpl` | Delegates shared task aggregation to one resolver. Avoid manually maintaining a second task schema. |
| `sections/unattended.md.tmpl` | Routes unattended operation to the command-owned state machine. An unattended host cannot invent missing consent. |
| `shadow-decider.md` | Versioned prediction of later owner answers, explicitly not an authorization mechanism. Useful only as an opt-in calibration experiment; predictions never become approvals. |

**Adopt:** explicit dependency ordering, terminal-result barriers, bounded retry/repair, resume records, approval bound to the displayed version, and conservative missing-capability behavior. **Adapt:** multiple reviewers only when held-out results show useful benefit. **Avoid:** treating cross-model agreement as truth, automatic scope expansion based only on file count/time guesses, or importing the project's entire coordinator for a single short skill.

Sources: [entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fautoplan%2FSKILL.md.tmpl), [driver](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fautoplan%2FDRIVER.md.tmpl), [phase files](../sources/source-reference.html?ref=reference%3Atree%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fautoplan%2Fsections).

### `review/SKILL.md.tmpl`, `checklist.md`, and `gate-integrity.md`

Review collects all findings before fixes so concurrent reviewers inspect the same candidate. Start receipts bind completion to source content; the logger computes trusted identities rather than accepting model-supplied hashes. Fresh and stale base-branch state are distinguished. Findings separate real defects from optional refactoring advice, confidence from severity, and fixed/skipped/open actions. Re-review is bounded and requires a final unchanged candidate before convergence. Unavailable reviewers and failed probes cannot yield a clean complete result.

The checklist selects applicable categories by diff type, traces newly accepted values through all consumers, checks security and state boundaries, and suppresses common low-value suggestions. The gate-integrity catalog distinguishes an inventory, a human-reviewed candidate change, and an actual finding. Its target is reward hacking: removing failing checks, weakening thresholds, swallowing errors, claiming fixtures as live proof, altering acceptance criteria, or reporting a zero-test execution as green.

**Adopt:** complete candidate capture; evidence-bound decisions; defect/advice separation; zero findings as a valid result; negative controls; validation-change review; never deleting valid failing tests to create success. **Adapt:** a user's request to review ordinarily warrants read-only analysis unless repair is authorized. reference-project's documented fix-first behavior should be explicit in any reused skill. **Avoid:** treating the default specialist score of 10 when a specialist did not run as quality evidence; automatic replies to external reviewers without messaging authority; blanket category-specific claims about model behavior without tests. The source itself notes that its default score is not completion evidence, and a simpler design should use `not_run` instead.

Sources: [entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2FSKILL.md.tmpl), [checklist](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fchecklist.md), [gate integrity](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fgate-integrity.md).

### `qa/SKILL.md.tmpl` and `qa-only/SKILL.md.tmpl`

The two entry points share methodology while keeping different mutation authority. QA selects browser/API/CLI/job/worker/webhook surfaces before loading methods. A URL does not automatically mean browser work. Report-only QA may create owned evidence but cannot edit product files, tests, dependencies, settings, or framework infrastructure. Both preserve prior evidence and use fresh run directories. Missing access blocks affected probes rather than unrelated checks.

Repair QA reproduces the defect, creates a meaningful native regression where appropriate, makes a minimal repair, replays the original failure and adjacent success case, and commits verified work by issue. The workflow distinguishes verified, best-effort, reverted, and deferred outcomes. It limits repeated unsuccessful repairs and keeps valid failing regressions. These semantics matter more than its specific numerical caps.

| Supporting file | Instruction approach and recommendation |
| --- | --- |
| `qa/sections/scope.md` | Establish surface, ownership, paths, downstream destinations and permitted writes. Adopt the warning that localhost can still forward to production. |
| `qa/sections/exploratory.md` | Charter before probes; bounded commands; prior observation and next hypothesis recorded before execution; failed/unstarted checks stay visible. Adopt evidence capture in code. Scale the checkpoint frequency to task risk. |
| `qa/sections/system-functional.md` | Tests return values and durable effects, identity/ownership, state, retries, duplicates, ordering and partial recovery. Adopt contract-specific coverage and distinguish accepted work from completed effects. |
| `qa/sections/qa-patterns.md` | Browser interaction, fresh screenshots, replays, provisional scores, same-coverage comparisons. Keep scores tied to coverage and never substitute them for functional outcomes. |
| `qa/sections/browser-setup.md.tmpl` | Browser-only setup and caller-specific authority; unknown caller gets report-only limits. Adopt conditional capability initialization. |
| `qa/sections/browser-verify.md.tmpl` | Exact failing interaction plus adjacent success, before/after visual evidence, fallback parity. Adopt visible verification appropriate to the defect. |
| `qa/sections/test-bootstrap.md.tmpl` | Detect existing frameworks, ask only when installation is needed, preserve user work, and keep real red tests. Adopt these boundaries; do not copy a blanket 100% coverage target as a promise of safety. |
| `qa-only/sections/reporting.md.tmpl` | Observation, expected contract, confirmation, and hypothesis remain separate everywhere, including summary wording. Timing is labeled by the interval actually measured. Adopt this evidence discipline. |

**Avoid:** committing all existing changes as a default repair preparation, counting unavailable checks as success, overwriting prior reports, changing tests to match broken behavior, or making every low-impact probe require a large ceremony. Prefer an isolated worktree or named-file ownership when a user's workspace is dirty.

Sources: [repair QA](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa%2FSKILL.md.tmpl), [report-only QA](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa-only%2FSKILL.md.tmpl), [QA methods](../sources/source-reference.html?ref=reference%3Atree%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa%2Fsections), [report finalization](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa-only%2Fsections%2Freporting.md.tmpl).

### `spec/SKILL.md.tmpl`

The spec skill turns intent into current/desired behavior, scope, acceptance criteria, technical interfaces, tests and rollback. It reads code before asking technical questions, identifies duplicates with an untrusted-data envelope, and distinguishes a successful empty search from a broken pipeline. It uses structured issue templates, quantified impact or explicit unknowns, and routes a larger task into dependent issues. The final filing section owns quality/redaction gates and optional execution; a summary is explicitly insufficient authorization to skip that procedure.

**Adopt:** observed current state, measurable acceptance criteria, source references, user-reviewable content, duplicate search with honest failure reporting, and distinct planning/publication/execution actions. **Adapt:** ask only questions not answered by the request or source. **Avoid:** an unconditional rule forbidding a useful first-turn draft, promises that a specification eliminates all implementation judgment, or automatic issue publication/agent execution under an ambiguous writing request.

Source: [entry point](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fspec%2FSKILL.md.tmpl).

### `write-skill/SKILL.md.tmpl` and `references/diet.md`

The edit ladder first fixes the tool, then requires evidence for a new instruction, edits an existing owner instead of appending duplicate rules, chooses the cheapest loading level, and records a general rule rather than an incident story. Levels run from discovery metadata to entry point, conditional reference, command help, and actionable tool errors. A size/drift bill is checked before and after.

The longer diet procedure inventories consumers, checks command/documentation drift, locks evaluation tasks before cuts, compares old/new/no-skill conditions, preserves safety behavior, and reports unavailable evaluations explicitly. The useful lesson is not that one historical growth percentage or three trials proves quality; it is that deletion should be evaluated against real task outcomes and safety constraints.

**Adopt:** fix deterministic failures below the prompt; evidence for each added rule; one authoritative statement per meaning; before/after context measurement; negative and no-skill controls. **Adapt:** choose panel sizes and uncertainty reporting appropriate to the risk. **Avoid:** using a before panel's three lucky passes as a statistically strong proof of superiority, or preventing all useful simplification solely because a particular paid service is unavailable.

Sources: [write-skill](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fwrite-skill%2FSKILL.md.tmpl), [diet procedure](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fwrite-skill%2Freferences%2Fdiet.md).

## Cross-cutting instruction-level decisions

1. Keep role descriptions short and judge observable behavior. A persona is not evidence of expertise.
2. Put trigger boundaries in discovery metadata. Repeat authority/stop rules in the body only when needed at execution time.
3. Name the source of permission. Retrieved text, generated plans, reviewer consensus, environment access and writable paths do not authorize new actions.
4. Specify input, action, expected result and recovery for each consequential step.
5. Use deterministic code for escaping, hashing, persistence, migration ordering, timeout enforcement and structured output validation.
6. Prefer a small state machine to dozens of prose instructions about exact read/write/log order.
7. Link each conditional resource from the entry point with a load condition. Avoid circular prerequisite gates.
8. Make mutation and publication modes obvious. Audit, repair, commit, push, merge and deploy are separate effects even when one workflow can compose them.
9. Bound work by risk and useful evidence. Do not transform every review into a full enterprise process.
10. Preserve context through artifacts with provenance, revision and completion status; do not replay unfinished side effects blindly after interruption.
11. Keep optional telemetry, profiling, promotion and memory out of the minimal task path.
12. Test instruction changes as behavior changes; exact-prose snapshots alone are insufficient.

These are audit recommendations, not claims that the Agent Skills format mandates this design.

## Additional deep review: expanded sections and specialist contracts

### `canary/SKILL.md.tmpl`

The post-deploy monitor has bounded duration, separate baseline capture, same-origin page discovery, fresh evidence each round, no overlapping rounds, explicit cadence, incident history, and a useful distinction between a pre-deploy baseline and a reference first captured after deployment. It preserves resolved incidents in the run's overall status and offers a baseline update separately.

Adapt the fixed two-round confirmation and two-times-load-time thresholds to the actual service's risk and noise. A known-bad baseline does not establish healthy production: report both absolute acceptance failures and regressions. The earlier instruction correctly compares console messages by identity, but a later example says an unchanged count is fine; equal counts can contain different errors. The `--quick` argument promises a single pass but the loop section does not clearly implement that branch. These should become behavior cases. A zero-success or unavailable measurement needs an incomplete status rather than HEALTHY solely because no confirmed alert exists. Baselines should bind to release/build, environment, account, viewport and measurement conditions, and their replacement should preserve history and avoid concurrent-run collisions. “Rollback” in an alert menu still needs an exact target and existing authorization; a monitoring request does not grant blanket production mutation.

Source: [canary template](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcanary%2FSKILL.md.tmpl). This full canonical read closed the last unreviewed `SKILL.md.tmpl` entry point in the inventory; generated host variants remain separately classified.

### Specification quality, filing, and execution

`spec/sections/gate-and-file.md.tmpl` makes filing and optional execution explicit, preserves a local archive, applies quality and redaction checks, and binds a spawned worktree to a captured commit. It rechecks dirty state after the user answers, documents that shell variables do not survive separate tool calls, and preserves a stash rather than dropping it. These are useful recovery and provenance practices.

One fallback is unsuitable as a portable default: if worktree creation fails, the instructions announce that execution will continue in the current directory, exposing in-progress work, with Ctrl+C as the user's opportunity to stop. Failure to establish the chosen isolation should block that spawn or require authorization for the changed execution scope. A cancellation opportunity after the fallback begins is not equivalent to prior authorization. The procedure also has repeated confirmation points; an implementation should resolve which are still needed under the current user's authorization instead of asking mechanically.

Source: [filing/execution section](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fspec%2Fsections%2Fgate-and-file.md.tmpl%23L230-L320). This is a source-level finding; no spawn was attempted.

### Plan completion and evidence

The expanded plan-completion section chooses an explicitly bound plan before searching candidates, treats plans as data, separates deliverables from behavioral checks, preserves pending commands, and distinguishes partial, changed, missing and unverifiable outcomes. The rule that a touched file is not sufficient evidence is strong.

Its cross-repository dispatch also promotes existence to DONE for concrete paths. That supports an existence requirement but not an arbitrary requirement about the file's content or operation. The broader prose later demands the specific functionality, creating ambiguity that should be removed. A portable audit should match the strength of the check to the acceptance condition. Candidate paths from a PR or plan should be confined to authorized sources; a document naming a sibling directory does not authorize reading all of it. The top-50 cap must preserve an explicit uncovered-item list rather than allow omitted high-risk requirements to disappear. Inferred causes such as context exhaustion or forgotten work should stay hypotheses unless supported by evidence.

Source: [expanded plan completion](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fplan-completion.md).

### Specialist dispatch and merger

The review-army section gives each specialist a bounded scope and structured findings, distinguishes an empty completed result from failure, waits for readers before edits, retains unavailable coverage, separates defects from advisory refactors before deduplication, and keeps source activity apart from final issue counts. The targeted review brief follows money, gate, authorization and secret values to actual enforcement; this is stronger than relying on checklist names.

The proposed confidence boost for agreement is a prioritization heuristic, not a calibrated probability. Reviewers can share training and prompts. Auto-gating a specialist after ten zero-finding dispatches can confuse lack of defects with lack of usefulness; preserve mandatory controls and evaluate hit-rate policies against known defect cases. Diff-size cutoffs are project heuristics, and a one-line authorization change can deserve deep review. The score based on weighted finding counts is not a release-safety metric. Suppressing low-confidence output must not hide a potentially severe unresolved issue without a clear disposition.

The specialist files offer useful topic partitions: API compatibility, migrations, maintainability, performance, security, state-machine transitions, testing, targeted sensitive changes, red-team integration gaps, and optional simplification. Several checklist items need domain validation. For example, SQL migration syntax depends on the operation and database; generic advice about `ALTER TABLE ... CONCURRENTLY` should not be copied as executable guidance. Performance recommendations such as adding memoization or indexes require workload evidence. Simplification examples must preserve validation semantics instead of assuming that a one-character email test is sufficient for every application.

The state-machine specialist's kind-by-action matrix is particularly useful: it requires the expected resulting durable row, not only a status flag, and keeps sibling variants separate. Its blanket severity for any untested cell should be adapted to the actual risk. The testing specialist's four-question value test, observable contract focus, caller evidence and preserved safety tests are good general patterns; a grep-only caller check cannot prove that dynamic or generated callers do not exist.

Sources: [dispatch/merge](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Freview-army.md), [specialist files](../sources/source-reference.html?ref=reference%3Atree%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fspecialists).

### Adversarial and outside review

The expanded adversarial section distinguishes installed/authenticated/usable/sandbox-ready provider states, records one evidence token per attempt before it reads inputs, preserves model identity as unknown when unavailable, binds results to source/phase, and requires valid completion markers. It explicitly says native review cannot complete outside-model coverage. It prevents a fixing run from certifying the edited tree without a new pass. Those are strong evidence contracts.

The prompt's statement that review is authorized is context framing, not a substitute for actual user authorization. Its fixture-summary-only strategy reduces exposure to attack strings but also reduces semantic coverage; that limit is disclosed and must remain visible. Calling an in-host subagent “free and fast” is not a universal cost claim. Show provider, latency and usage evidence instead. A timeout that produced no usable findings is missing coverage, not absence of defects. The optional pass's nonblocking status and the structured pass's gate should remain separately represented in code and output.

Source: [expanded adversarial section](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fadversarial.md).

### Reused advisory evidence and review-bot comments

Shared-code reuse requires complete supporting sources, exact current bytes, a matching review identity and a prior explicit decision. The helper owns the fingerprint and coverage calculation. It excludes risky Git states such as filters, sparse entries and symlinks. This is an unusually careful example of preventing stale advice suppression from hiding a changed defect. Adapt its complexity to the consequences of reuse.

The review-bot triage reference separates machine identifiers from untrusted comment bodies, distinguishes fetch failure from zero comments, and moves reply text through a file instead of shell interpolation. Those patterns deserve reuse. Scope suppression more narrowly than a broad historical file/category match when a new real defect could share the category. Authorize external replies separately from reading and classifying comments. The source's secret scanner is defense in depth; it does not make posting arbitrary text automatically safe.

Sources: [shared-code reuse](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fshared-code-reuse.md), [bot triage](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fgreptile-triage.md).

### QA report resources

The functional report template records authority, fixture ownership, exact probes, expected versus observed effects, outcome, replay evidence, regression status and cleanup. It separates setup blockers from product defects and distinguishes proposed tests from tests actually created. This is a strong portable reporting model.

The visual report's scores and the taxonomy's timing/request-count thresholds are project heuristics. They are not accessibility or performance standards. “Click every control” must be constrained by the actual action's effects and authorization. A destructive action on localhost can still affect real data. Keep accessibility claims tied to the exact standard and test method, and describe browser emulation separately from physical-device testing.

Sources: [functional report](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa%2Ftemplates%2Ffunctional-report-template.md), [visual report](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa%2Ftemplates%2Fqa-report-template.md), [taxonomy](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqa%2Freferences%2Fissue-taxonomy.md).
