# Current standards and portability research for open-source agent skills

Research date: **2026-11-22, America/Los_Angeles**. Repository observations were made on the corresponding UTC execution date, 2026-11-23. This memo is supporting research for the reference-project audit, not an assertion that any host integration was exercised in a live agent session.

## Evidence labels and source policy

- **Verified documentation:** directly observed in the linked primary source on the research date.
- **Verified code/test:** directly observed in a pinned public repository; an executed check is explicitly identified.
- **Recommendation:** an original proposed engineering practice for the user's knowledge base. It is not a requirement imposed by the Agent Skills format.
- **Not verified:** a runtime or interoperability claim that still needs a test on a named host version.

The public OpenAI skill-creator source was checked out at commit `49f948faa9258a0c61caceaf225e179651397431`. Its files are available under `research/openai-skills-source/skills/.system/skill-creator/` in this audit workspace. No skills were installed and no external account actions were performed.

## 1. Decisions the knowledge base should make explicit

**Recommendation:** define a skill project as three related products: portable task instructions, executable resources, and host integrations. A Markdown file may parse on several hosts while its execution and permission semantics remain different. Consequently, compatibility claims should name the host, its version, the operating system, and the specific behavior tested.

Use one portable source of truth, with narrow host adapters. Put source-independent workflow logic, evidence rules, and output contracts in the portable core. Put invocation syntax, tool names, permission configuration, native subagent settings, and installation destinations in the adapter. Keep the actual authorization check in the host or service that executes the action.

A useful maturity ladder is:

| Status | Required evidence |
| --- | --- |
| Format valid | The portable manifest and referenced files pass structural validation. |
| Installs | The named host discovers the skill from the documented destination. |
| Functionally exercised | Representative tasks complete on a named host and model with recorded artifacts. |
| Security exercised | Allowed actions succeed and prohibited actions fail at the actual enforcement boundary. |
| Supported | The maintainer runs regression checks and publishes version limits and repair guidance. |

These are proposed project labels, not standard-defined certification levels. Do not use a single “works with all agents” badge to collapse them.

## 2. Portable format: the actual contract

**Verified documentation:** the Agent Skills specification requires a directory with `SKILL.md`, YAML frontmatter, and a Markdown body. `name` and `description` are required. Names are limited to 64 characters, use lowercase letters/digits/hyphens, cannot have boundary or consecutive hyphens, and must match the parent directory. Descriptions are nonempty and limited to 1,024 characters. The optional fields are `license`, `compatibility` (up to 500 characters), `metadata` (string-to-string map), and experimental `allowed-tools`. Scripts, references, and assets are optional. The specification recommends a short primary document with material loaded as needed. [S01]

**Recommendation:** choose ASCII names matching `^[a-z0-9]+(?:-[a-z0-9]+)*$` for broad compatibility even where a parser accepts additional Unicode. Require explicit strings and `true`/`false` Boolean syntax in host extensions. Reject duplicate YAML keys. Treat unsupported metadata as a build error for the target artifact, instead of relying on a host silently ignoring it.

Installation roots are a host concern. The common `.agents/skills/` convention is useful, but the specification does not prescribe discovery locations. The implementation guide recommends layered discovery and delayed resource loading; it also discusses trusting project-local skills. Its general advice about collision precedence is not a guarantee of every product's behavior. [S02]

## 3. Current host facts that materially affect the design

### Codex

**Verified documentation:** OpenAI's current local-skills documentation describes repository `.agents/skills` discovery from the working directory toward the repository root, user skills in `~/.agents/skills`, admin skills in `/etc/codex/skills`, and bundled system skills. It supports symlinked skill folders. Identical names are not merged. CLI invocation uses `$` or `/skills`; ChatGPT uses `@`. `agents/openai.yaml` can supply interface metadata, invocation policy, and tool dependencies. Reusable distribution can use a plugin. The former `developers.openai.com/codex/skills` URL redirects to ChatGPT Learn. [S03]

**Recommendation:** use current documented paths as defaults for newly authored Codex projects, but keep the path configurable and test actual discovery. A benchmark installing into an older location does not prove that location is the best new-project default. Never overwrite `CODEX_HOME` or a user's preexisting configuration to make an installation appear successful.

### Claude Code

**Verified documentation:** Claude Code uses `.claude/skills`/`~/.claude/skills` and `/name` invocation. Its extra frontmatter can control invocation and subagents. `disable-model-invocation: true` prevents automatic model activation. `user-invocable: false` hides the user command while permitting model use. Most importantly, `allowed-tools` pre-approves listed tools during the invoking turn; it does **not** remove other tools. Current documentation provides `disallowed-tools` for restricting the available pool. Claude Code-specific frontmatter is not accepted by every other Claude distribution surface. [S04]

**Recommendation:** do not put unrestricted `Bash`, broad wildcards, hook definitions, dynamic shell interpolation, or tool grants into the portable core. A Claude adapter should identify its grants and tests separately from the skill's task instructions. A skill that creates a deployment plan and a skill that publishes it can have separate entry points when that makes authorization clearer.

### Grok Build, Grok Bot, and the Grok API

**Verified documentation:** Grok Build now has native `SKILL.md` support. It discovers project/user `.grok/skills`, plugin skills, configured extra paths, and user `~/.agents/skills`. It documents automatic reading of Claude Code resources. `allowed-tools` neither grants nor restricts tools. `user-invocable: false` hides a skill from both the user and model, differing from Claude Code. `disable-model-invocation` supports command-only use. Several accepted fields, including `model`, `effort`, `license`, and `compatibility`, are not applied. These are documented behaviors, not an independently tested interoperability guarantee. [S05]

Grok Bot separately documents reusable private/team skills and routines; the reviewed page does not establish that an arbitrary local skill directory can be uploaded unchanged into that product. [S06]

The xAI function-calling API has the model request a function call, with client code executing the function and returning the result. A developer using a Grok model through an API must supply the loader, tools, execution control, and approvals appropriate to that application. [S07]

**Recommendation:** list `Grok Build` as a concrete native adapter target. List `Grok API/custom host` as a different target with a defined loader contract. Do not claim native support is absent; it is documented as of this research date. Do not generalize Grok Build behavior to every product using the Grok name.

### Same field, different behavior

**Recommendation based on S04–S05:** maintain adapter-specific semantic tests for permission metadata and invocation visibility. A translation table is code with security consequences. A simple key rename or whole-file copy is insufficient where identical field names mean different things. Mark a mapped feature “unsupported” when equivalent behavior cannot be provided.

## 4. OpenAI's public skill-creator: useful guidance and exact limits

**Verified documentation:** the public creator favors concise instructions, specificity proportional to task fragility, and separate scripts/references/assets. It recommends conditional reference loading and a primary document under 500 lines. It discourages human-facing maintenance documents inside the installed skill payload. The creation process starts with concrete examples and proceeds through reusable resources, initialization, editing, validation, and iteration. [S08]

**Recommendation:** retain README, license, changelog, contribution guide, and security policy at the **repository** level. Keep the installed skill payload lean. The creator's advice against auxiliary files in a skill should not be stretched into a rule against good open-source repository documentation.

The public creator should also be distinguished from a platform-specific installed variant. Environment-specific instructions to persist personal skills or reconcile a managed checkout are deployment details for that environment; they should not become an open-source project's universal installation method.

### Public creator file review

| File at the pinned commit | Observed role | Reusable lesson or limitation |
| --- | --- | --- |
| `SKILL.md` | Authoring workflow and resource design. | Strong starting point for scope, concision, and delayed loading; it does not establish behavioral quality by itself. |
| `scripts/init_skill.py` | Creates a starting folder and selected resources. | Generate structure consistently, then remove examples that the finished skill does not need. |
| `scripts/generate_openai_yaml.py` | Generates OpenAI UI metadata. | Separate product metadata from task logic; check consistency when the task changes. |
| `scripts/quick_validate.py` | Minimal frontmatter/name/description checks. | Use as a smoke check, not as full specification or runtime validation. |
| `references/openai_yaml.md` | Describes OpenAI-side metadata and dependencies. | A host contract deserves its own reference; it is not a portable standard. |
| `agents/openai.yaml` | UI-facing identity for the creator itself. | Metadata is part of the maintained package. |
| `LICENSE.txt` | Terms for the creator package. | Review licensing before redistributing borrowed code or wording. |

The table is a file-role summary. The checks below were actually executed against `quick_validate.py`; this is not a claim to have run a full creator test suite.

### Reproduced validator gaps

| Input | Result observed | Implication |
| --- | --- | --- |
| Empty string `name` and empty string `description` | Accepted as valid. | The validator does not enforce the specification's nonempty requirements. |
| A valid name different from the parent directory name | Accepted as valid. | It does not check the directory/name relationship. |
| Standard `compatibility` field | Rejected as an unexpected key. | This pinned helper's allowlist differs from the current published format. |

Evidence: `skill-creator-validator-observations.json` and pinned [`quick_validate.py`](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/scripts/quick_validate.py). The check loaded the reviewed Python function and supplied temporary local test files; no install was performed. [S09]

**Recommendation:** implement a stricter project validator that is explicitly versioned against the selected specification, plus separate host checks. Treat a helper's success message as evidence only for the checks its code contains.

## 5. A proposed portable architecture

Keep these responsibilities separate even if a small project uses only a few files:

| Layer | Contents | Change trigger |
| --- | --- | --- |
| Task contract | Goal, inputs, outputs, preconditions, stop conditions, evidence requirements. | User task or domain changes. |
| Workflow | Ordered actions, decision branches, recovery, verification. | Real execution exposes a failure or waste. |
| Resource implementation | Deterministic scripts, schemas, templates, fixtures. | Tool/API/data contract changes. |
| Host integration | Discovery paths, invocation, tool mapping, native permissions/hooks. | Host behavior changes. |
| Release machinery | Validation, packaging, checksums, install manifests, upgrade/rollback. | Distribution requirements change. |
| Evaluation | Positive/negative tasks, outcome checks, host matrices, cost budgets. | New scope, regressions, or model/runtime changes. |

For a small skill, author a direct `skills/<name>/SKILL.md` plus only the resources it uses. For a suite, build generated target artifacts from the same canonical instructions and a declared adapter. Do not generate the entire repository solely to avoid writing ten lines of repeated prose. Introduce generation when duplication has become a verified maintenance risk.

If generation is used, define an explicit input list, deterministic ordering, a build identifier, and a drift check. The generated file should say where to edit its source. Run the structural checker against **generated outputs**, because users run those outputs. A passing source template says nothing about unresolved placeholders or broken links in the package.

Use fully resolved paths for execution without assuming the process is in the skill directory. Explain how to locate the skill root through the host adapter. Resource references may be written relative to the skill root, but executing `python scripts/tool.py` from a user's arbitrary project directory is an avoidable failure.

## 6. Instruction design that can be audited

The Agent Skills creator guidance emphasizes experience from real work, coherent scope, concise decision procedures, defaults, and refinement using execution traces. It recommends keeping core instructions short and loading specific references on a stated condition. [S10]

**Proposed review unit:** audit each meaningful instruction as a contract with five fields: condition, action, expected evidence, failure behavior, and authority boundary. This makes omissions visible without rewriting every sentence into legalistic language.

Example of the proposed method:

| Instruction concern | Weak form | Better contract |
| --- | --- | --- |
| Tool availability | “Use the browser.” | Check the adapter's browser capability. If unavailable, report which requested checks remain unperformed. |
| Verification | “Ensure quality.” | Open the generated artifact and verify the explicit acceptance conditions; report any unmet condition. |
| Missing context | “Ask questions first.” | Proceed using available inputs. Ask only for missing information that changes a consequential decision. |
| External action | “Ship when ready.” | Prepare the exact change and validation record. Execute publication only when the current authorization covers the target and effect. |
| Recovery | “Retry failures.” | Retry only an identified transient error, within a stated bound; preserve the original error and stop when the bound is reached. |
| Evidence | “All tests passed.” | Report the exact verification command and result; distinguish passing, skipped, and unavailable checks. |

Avoid globally forcing a tool when another host cannot provide it. Avoid giving the skill authority over host security policy. Avoid mechanically requiring a question for reversible work when the user's instruction already authorizes it. A reusable skill should coordinate the existing authorization context instead of inventing a second incompatible approval system.

## 7. Evaluation design

The official skill evaluation guide recommends realistic prompts, expected outcomes, optional fixtures, fresh contexts, and comparison with a no-skill or previous-version baseline. It records output checks alongside timing and token usage. [S11]

The description-optimization guide treats discovery as a separate problem, using positive and negative prompts and challenging near-miss requests. It suggests an initial set of about 20 labeled queries; that is a practical starting point, not evidence of statistical sufficiency for every skill. [S12]

Anthropic's agent evaluation guidance distinguishes deterministic checks, model graders, and human judgment; it also separates capability discovery from regressions and cautions that repeated-trial reliability differs from succeeding at least once. [S13]

**Proposed minimum evaluation layers:**

1. **Structure:** parse frontmatter; enforce field types; resolve relative references; reject unintended secrets, build debris, and broken executable paths.
2. **Resource correctness:** test scripts on normal, boundary, malformed, and adversarial inputs; inspect return codes and output schemas.
3. **Trigger behavior:** direct requests, paraphrases, implicit use, keyword overlap, adjacent tasks, and explicit opt-outs.
4. **Task outcomes:** verify the actual created file, state change, query result, or diagnosis, not just the final prose.
5. **Failure handling:** missing executable, authentication wall, rate limit, inaccessible file, failed verification, partial results, and interrupted execution.
6. **Safety behavior:** requests embedded in source data, secret-bearing fixtures, attempts to expand scope, unexpected destinations, and denied tool calls.
7. **Portability:** at least the primary host plus each advertised secondary host, using the same task fixtures and equivalent acceptance criteria.
8. **Lifecycle:** install, repeat install, upgrade, failed upgrade, rollback, uninstall, and preservation of unrelated user files.

Keep small smoke checks in every change's CI path and run expensive live-agent evaluations when instructions, adapters, dependencies, or model versions change. Do not make every Markdown typo require an expensive browser or model run.

### Proposed measurement record

Record the skill commit, generated package hash, host/version, model/version, execution settings, OS, tool versions, case ID, input hashes, elapsed time, tool calls, tokens, estimated cost, outcome, and graded artifacts. Also record omissions and infrastructure failures. Redact credentials before retaining traces.

Use paired baseline comparisons on the same task sets. Separate development cases from held-out cases; do not optimize solely against examples repeatedly shown to the authoring agent. Repeat stochastic cases and report uncertainty. A result from ten tasks does not justify a broad success-rate claim. For safety-critical failures, publish the count and conditions instead of letting a weighted quality score hide them.

Test task outcomes and required safety properties rather than exact wording. Use human review to calibrate subjective grading. If an LLM judge is used, record its rubric and model; keep it blind to which artifact is the new version when practical. Fresh subagents must not receive the author's diagnosis or expected fix unless that information belongs in the real user task.

OpenAI's evaluation guidance similarly recommends task-specific cases, logging, automation, and calibration with human judgment. The legacy hosted Evals platform was already read-only for existing users on this research date and had a published shutdown date of November 30, 2026. Its methodology remains useful; a new portable project should not depend on that retiring platform. [S14]

## 8. Security and trust boundaries

**Verified documentation:** Codex separates OS-enforced sandbox boundaries from approval policy. The current documentation also notes that the explicit `approval_policy = "untrusted"` setting is retired; examples copied from older material can fail. [S15]

Grok Build likewise separates tool permission decisions from sandbox capabilities. Its permission documentation describes deny precedence. Its sandbox documentation says sandboxing is off by default, lists platform-specific network limitations, and distinguishes child-process traffic from in-process model/web requests. These details make an unqualified “sandboxed” compatibility badge inadequate. [S16, S17]

**Proposed four-boundary threat model:**

- **Distribution boundary:** a user obtains code and instructions from a repository, package, or updater. Check immutable identity and expected publisher/build metadata.
- **Instruction boundary:** source files, web pages, issue text, tool results, and generated output can contain instructions. Treat their content as task data unless the user has authorized it as policy.
- **Execution boundary:** scripts, shell commands, browser sessions, and connectors can modify state or disclose data. Enforce least privilege in the executable layer.
- **Persistence boundary:** caches, logs, browser profiles, reports, and state files can outlive the task. Define retention, redaction, location, and cleanup.

For each boundary, list protected resources, permitted data flows, attacker-controlled inputs, enforcement mechanism, and an executable negative test. An instruction saying “do not send secrets” belongs in the workflow, but it does not replace a narrow destination allowlist, filtered environment, or absent credential.

Do not import a user's browser session as routine setup for a skill that can work with an isolated profile. If session reuse is essential, document which host does it, where the profile lives, what data is accessible, and how to stop and remove it. Keep the helper bound to a local interface with authenticated access where applicable. These are design recommendations to test against the actual implementation.

OWASP's GenAI Security project provides a broader risk taxonomy; use it as a source of threat scenarios, not as a certificate of safety obtained by mentioning its name. [S18]

## 9. Scripts and performance

The Agent Skills script guide recommends declared prerequisites, versioned execution, self-contained dependencies when suitable, and interfaces usable without interactive prompts. It discusses explicit outputs and predictable behavior for agents. [S19]

**Recommended script contract:** `--help`, explicit inputs, machine-readable output when useful, stdout for results, stderr for diagnostics, meaningful exit status, bounded execution, and no surprise TTY prompt. Include a dry-run for consequential mutations where it can accurately predict the change. Validate data at the boundary before building paths, commands, or URLs from it.

Pin runtime dependencies and document network requirements. Runtime package downloads are convenient but may make an offline skill unusable and a supposedly deterministic run dependent on remote state. Choose preinstallation, a locked environment, or an explicit first-run preparation step according to the task.

**Recommended performance budgets:** track discovery metadata, activated instruction size, resource-loading frequency, execution latency, and model/tool cost separately. Measure cold and warm behavior. Cache expensive repeatable facts with a cache key and expiry policy; do not cache authorization or assume a stored login is valid. Reuse a daemon only when reduced startup time outweighs lifecycle and security complexity.

Anthropic's primary engineering discussion of tool search and programmatic tool use shows why loading only relevant definitions and doing deterministic orchestration outside repeated model turns can reduce context overhead. Its reported results are specific to its systems and workloads; they are not a predicted speedup for this project. [S20]

## 10. Packaging, installation, upgrades, and GitHub presentation

**Recommended default:** a release should contain only the skill payloads and resources required by the selected distribution, plus applicable licenses. Keep fixtures, raw transcripts, large screenshots, caches, browser profiles, and local environment files out of the install package. Generate a file manifest and checksums so a user can inspect exactly what is shipped.

An installer should show its target host/scope, check dependencies, write only owned paths, detect existing installations, and preserve unrelated settings. Prefer an explicit dry-run or preview. Record installed version, source commit, installation location, and owned files. Do not silently mutate all detected agents when the user selected one.

An updater should verify the intended remote and release identity, check for local changes, stage an update separately, validate it, and switch atomically when possible. Keep a known-good rollback. Make stable releases and development tracking explicit choices. Describe whether updates run automatically and when. An uninstall should use the ownership manifest, report what it removed, and avoid deleting a shared parent directory.

The README should establish the task, a minimal example, supported hosts, prerequisites, installation effects, permissions/data use, limits, maintenance status, and contribution route. Link to detailed documentation after the quick start. A screenshot or benchmark should show reproducible evidence, including the environment and caveats. Avoid success claims based solely on stars, code volume, or the author's experience.

GitHub's current secure-use guidance recommends immutable workflow dependencies. Its newer dependency-lockfile feature includes transitive actions and repository identity; the how-to lists GitHub Enterprise Cloud eligibility. For projects that cannot use it, full commit SHA pins remain the widely usable baseline. Reusable workflow references still require separate pinning. [S21–S23]

SLSA provenance describes where and how an artifact was built. Verification must check the artifact's relationship to trusted identities and expected parameters. A checksum downloaded from the same compromised location as the artifact detects corruption but does not independently authenticate the publisher. [S24, S25]

**Recommended proportionality:** a small instruction-only skill does not need the full operational stack of a browser daemon or multi-host installer. Add a control when its protected resource and failure scenario are concrete. Preserve a fast, inspectable path for ordinary contributions.

## 11. Items requiring later verification

- No live Codex, Claude Code, or Grok Build execution was performed for this standards memo.
- No statement of Grok Build's general Claude compatibility should be promoted to proof that a particular reference-project hook or skill works there.
- The currently published docs and a project's pinned code can disagree. Record both and reproduce the exact behavior on the claimed supported release.
- Product defaults and install roots are date-sensitive. Re-check them when updating adapters or releasing a compatibility claim.
- The Agent Skills specification, product extensions, and helper validators are different contracts. Passing one is not evidence of passing the others.

## Sources

All links below are primary sources, accessed on the research date. Detailed machine-readable records, including retrieval reference IDs, are in the [machine-readable primary source register](../sources/primary-sources.json).

- **S01:** [Agent Skills specification](https://agentskills.io/specification).
- **S02:** [Adding skills support to an agent](https://agentskills.io/client-implementation/adding-skills-support).
- **S03:** [OpenAI: Build skills](https://learn.chatgpt.com/docs/build-skills).
- **S04:** [Claude Code: Extend Claude with skills](https://code.claude.com/docs/en/skills).
- **S05:** [Grok Build: Skills, Plugins & Marketplaces](https://docs.x.ai/build/features/skills-plugins-marketplaces).
- **S06:** [Grok Bot: Skills and routines](https://docs.x.ai/grok-bot/skills-routines-and-automations).
- **S07:** [xAI API: Function calling](https://docs.x.ai/developers/tools/function-calling).
- **S08:** [OpenAI public skill-creator, pinned source](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/SKILL.md).
- **S09:** [OpenAI minimal validator, pinned source](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/scripts/quick_validate.py).
- **S10:** [Agent Skills: Best practices](https://agentskills.io/skill-creation/best-practices).
- **S11:** [Agent Skills: Evaluating skill output quality](https://agentskills.io/skill-creation/evaluating-skills).
- **S12:** [Agent Skills: Optimizing skill descriptions](https://agentskills.io/skill-creation/optimizing-descriptions).
- **S13:** [Anthropic: Demystifying evals for AI agents](https://www.anthropic.com/research/demystifying-evals-for-ai-agents).
- **S14:** [OpenAI: Evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices).
- **S15:** [OpenAI: Agent approvals and security](https://learn.chatgpt.com/docs/agent-approvals-security).
- **S16:** [Grok Build: Permissions](https://docs.x.ai/build/features/permissions).
- **S17:** [Grok Build: Sandbox](https://docs.x.ai/build/features/sandbox).
- **S18:** [OWASP GenAI Security project context](https://owasp.org/projects/top-10-for-large-language-model-applications).
- **S19:** [Agent Skills: Using scripts](https://agentskills.io/skill-creation/using-scripts).
- **S20:** [Anthropic: Advanced tool use](https://www.anthropic.com/research/advanced-tool-use).
- **S21:** [GitHub: Secure use reference](https://docs.github.com/en/actions/reference/security/secure-use).
- **S22:** [GitHub: Workflow dependency lockfiles](https://docs.github.com/en/actions/concepts/security/workflow-dependency-lockfiles).
- **S23:** [GitHub: Locking action dependencies](https://docs.github.com/en/actions/how-tos/secure-your-work/lock-workflow-dependencies).
- **S24:** [SLSA v1.2: Build provenance](https://slsa.dev/spec/v1.2/build-provenance).
- **S25:** [SLSA v1.2: Verifying artifacts](https://slsa.dev/spec/v1.2/verifying-artifacts).

## Documentation evidence retained with this revision

The [host documentation register](../sources/host-documentation-register.json) retains short exact excerpts, headings, source URLs, capture dates, hashes of the retained excerpts and claim mappings for selected changing host semantics. It also identifies inherited entries for which no archival capture was supplied. A hash of an excerpt establishes the identity of that excerpt, not the complete page or a tested product build.

The temporal and collision cases in the [evaluation kit](../evaluations/case-designs.json) turn documented lifetime and lookup differences into reusable tests. No live host trial was run as part of this narrative integration. Product-specific discovery and grants remain distinct from the portable format; a loaded instruction, an active permission and durable task state can have different lifetimes.
