# Secondary instruction audit of reference-project

Source revision: `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`. Audit date: 2026-11-22 America/Los_Angeles (2026-11-23 UTC). This is an instruction-level source review, not an execution certification.

## Coverage and evidence

This memo covers **53 audit units, 118 fully semantically read files totaling 18,540 lines, and 2,249 additional generated lines in 15 explicitly recorded ranges**. An audit unit can be a skill, a collection of model overlays, or a host adapter. Seven further gbrain instruction sources (2,275 lines) were delegated to the lifecycle reviewer and are recorded separately in `gbrain-instruction-audit.md` and `gbrain-instruction-review.json`.

Every assigned canonical secondary `SKILL.md.tmpl`, its section templates, and the listed standalone/reference instruction sources was read. Canonical source reading does **not** by itself establish coverage of text inserted by macros. Expanded design doctrine, design methodology/hard rules, browser setup/cookbook, image feedback loops, outside documentation and DX plan review, test bootstrap, task/report/log machinery, and other selected expansions were additionally read. Exact ranges, SHA-256 fingerprints, and notes are in `secondary-instruction-review.json`.

Shared preambles were compared byte-for-byte with `review/sections/preamble.md`, already semantically reviewed by the lead reviewer. The manifest contains 32 exact-content deduplication mappings, including shared preambles and the identical design doctrine file. No independent semantic credit is claimed for unlisted generated text, all host/model expansion variants, runtime implementation, or test execution. Remaining common expansions are identified for the lead/lifecycle reviewers; their combined coverage must be reconciled before making a repository-wide claim.

**Evidence labels:** source observations below describe what the instructions actually say; risks and recommendations are review judgments derived from those observations. Statements about vendor behavior, benchmarks, psychology, performance multipliers, or implementation safety are not verified solely because reference-project states them. File references are pinned permalinks so the review remains reproducible after the project changes.

## What to carry into a portable skill project

The most reusable design is a small portable procedure supported by explicit host adapters and executable contracts. The secondary skills repeatedly demonstrate useful patterns: inspect existing state before acting; use narrow references only when needed; record the source and freshness of evidence; preserve user-owned files; make partial, skipped, unavailable, and failed outcomes distinct; bind approval and completion to a concrete artifact; and keep external-provider results separate from native fallback results. These patterns are stronger than adopting reference-project's exact rhetoric, scores, or ceremony.

The files also show why an instruction suite needs semantic consistency checks. The same idea is often encoded in canonical templates, generator macros, standalone host forks, CLI snippets, examples, and report templates. A policy stated correctly in one layer can be contradicted by another. Static fixtures, private temporary files, local URLs, a passed process exit, and model agreement each establish a limited fact; none proves the larger outcome on its own.

### Priority corrections before reuse

| Finding | Source evidence | Portable replacement |
|---|---|---|
| Accessibility contrast uses an incorrect large-text unit: 18px is given where the relevant WCAG threshold is 18pt regular or 14pt bold. | [design-review/SKILL.md:644](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L644) | Use authoritative criteria and distinguish CSS pixels from points; verify actual computed typography and contrast. See [W3C contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html). |
| Static fixture replay is said to detect future live HTML changes. An unchanged fixture cannot do that. | [browser-skills/hackernews-frontpage/SKILL.md:51-52](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbrowser-skills%2Fhackernews-frontpage%2FSKILL.md%23L51-L52) | Separate deterministic fixture regression tests from scheduled, authorized live contract probes; version and refresh fixtures. |
| A current-window freshness guard treats no recent commit as a stale clone even after fetch succeeds. Quiet activity is legitimate. | [retro/SKILL.md.tmpl:121](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl%23L121) | Check fetch/ref provenance directly; report an empty observed window without inventing activity or staleness. |
| Commit spacing, file concentration, LOC totals, and test LOC are promoted into work hours, cognitive focus, impact, or test assurance. | [retro/SKILL.md.tmpl:233-301](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl%23L233-L301); [retro/sections/report-format.md.tmpl:35-53](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2Fsections%2Freport-format.md.tmpl%23L35-L53) | Name metrics after their actual unit; treat behavioral interpretations as unverified hypotheses, not personal performance scores. |
| The release-body workflow claims race safety while fetching a PR body, later modifying it, and replacing the full remote body without a compare-and-swap condition. | [document-release/sections/release-body.md.tmpl:237-345](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Frelease-body.md.tmpl%23L237-L345) | Preserve concurrent edits using API version preconditions where supported, or re-read/rebase/revalidate immediately before the write and report remaining race limits. |
| Localhost or `.test` is treated as sufficient authority for mutating browser actions. Local applications can call production backends. | [design-review/SKILL.md:226](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L226); [devex-review/SKILL.md:208](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md%23L208) | Determine account, environment, data, and effect scope; inherit existing user authorization and require fresh authority only for an uncovered action. |
| A standalone OpenClaw full-build overlay says to ask no human questions until the PR is ready while requiring an approved plan earlier. | [openclaw/templates/reference-project-full-CLAUDE.md:6-12](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-full-CLAUDE.md%23L6-L12) | Carry approval gates through orchestration with machine-readable pending decisions and exact-scope replies. |
| An iOS Tailscale policy example uses an invalid deny-style ACL action and has a port inconsistency. | [ios-qa/docs/tailscale-acl-example.md:112-117](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2Fdocs%2Ftailscale-acl-example.md%23L112-L117) | Validate configuration against the vendor schema; express least privilege with accepted allow rules and default denial. See [Tailscale policy syntax](https://tailscale.com/docs/reference/syntax/policy-file). |
| A model overlay allows hidden chain-of-thought disclosure if asked, and other model descriptions include unsupported behavioral stereotypes. | [model-overlays/o-series.md:1-11](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fo-series.md%23L1-L11); [codex/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2FSKILL.md.tmpl) | Ask for concise rationale, evidence, and actions consistent with the host; retain model tuning only when current evaluation supports it. |
| Bootstrap and factory instructions mix tests of real behavior with absolute coverage claims and unmeasured speed ratios. | [design-review/sections/test-bootstrap.md:168-192](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Ftest-bootstrap.md%23L168-L192); [plan-design-review/sections/review-sections.md:340](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md%23L340) | Use risk-based behavioral coverage, explicit test limitations, measured timing, and uncertainty instead of universal multipliers. |

These are source-level defects or limitations. They do not establish exploitability or prove a runtime incident. Where a helper may add protection beyond the text, the runtime reviewer must verify it.

## Audit by skill and adapter

Each unit below records the distinctive instruction clusters, the parts worth adopting, the contextual adaptations needed, and the clauses that should not become generic best practice.

### 1. benchmark-models

**Instruction sources:** [benchmark-models/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark-models%2FSKILL.md.tmpl).

**Approach.** Trigger excludes web benchmarking; prompt selection; dry-run provider readiness; disclosure for OpenRouter file access; optional paid model judge; bounded command construction; speed/cost/quality comparison; optional JSON retention.

**Adopt.** Provider availability preview and explicit external-provider data-flow disclosure; safe free-text prompt file; clear error remediation.

**Adapt.** Use a host-neutral provider adapter and stable run IDs, repeated paired trials, calibrated blind judges and frozen model versions. Reuse already collected result data for JSON export.

**Avoid or correct.** Step 6 reruns the entire benchmark to save JSON, adding cost and producing a different measurement. A one-run quality score from Claude while Claude is a candidate is not independent proof. Fixed USD 0.05 cost text and model recommendations require freshness.

**Trace points.** [benchmark-models/SKILL.md.tmpl:72-107](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark-models%2FSKILL.md.tmpl%23L72-L107), [benchmark-models/SKILL.md.tmpl:127-148](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark-models%2FSKILL.md.tmpl%23L127-L148).

### 2. benchmark

**Instruction sources:** [benchmark/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2FSKILL.md.tmpl), [benchmark/sections/vet-the-number.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2Fsections%2Fvet-the-number.md.tmpl).

**Approach.** Same-origin page discovery with destructive-path skips; load-state and PerformanceEntry collection; missing metric versus zero; five runs and medians/ranges; immutable baseline history; thresholded comparison, resource attribution, budgets, trend report; read-only. Seven-question measurement validity gate checks limiter, tuning, physical bound, errors, reproduction, user impact and actual completed work.

**Adopt.** Explicit scope contrast; failure versus slowness; no comparison without baseline; immutable raw evidence; missing/zero handling; diagnose timed work and end-to-end impact.

**Adapt.** Record browser/version, network/cache/load profile and use appropriate uncertainty methods. Budget values and regression percentages are house defaults, not universal standards. Report which Web Vitals were actually measured.

**Avoid or correct.** Description promises Core Web Vitals broadly but canonical collection lists LCP/FCP/navigation/resource data, not a complete INP/CLS measurement design. TransferSize can be zero for cache/cross-origin cases, so summing it is not proof of physical bundle size. Range-overlap heuristics do not replace a calibrated statistical comparison.

**Trace points.** [benchmark/SKILL.md.tmpl:80-109](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2FSKILL.md.tmpl%23L80-L109), [benchmark/SKILL.md.tmpl:143-186](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2FSKILL.md.tmpl%23L143-L186), [benchmark/SKILL.md.tmpl:4-58](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2FSKILL.md.tmpl%23L4-L58).

### 3. build-check

**Instruction sources:** [build-check/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbuild-check%2FSKILL.md.tmpl).

**Approach.** Quick precommit path bypasses preamble and performs no edits; declared-command detection and trust gate; structured check statuses; focused fix loop with five-run/repeated-failure bounds; environment stop; exact-tree readiness handoff.

**Adopt.** No declared checks is reported as no checks, never green. Distinguish failures, absent coverage, zero tests, environment and timeout. Bind readiness to exact tree and list uncovered lanes.

**Adapt.** Apply scope and authorization from the user; choose proportional test obligations. Allow legitimate test updates for changed contracts under review rather than a universal ban.

**Avoid or correct.** Blanket prohibition on editing any test/config/script can block correct maintenance. Environment failures are unconditionally stopped rather than permitting an already authorized reversible repair. Quick mode allows a skipped result to continue a commit; report that state plainly.

**Trace points.** [build-check/SKILL.md.tmpl:25-41](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbuild-check%2FSKILL.md.tmpl%23L25-L41), [build-check/SKILL.md.tmpl:59-110](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbuild-check%2FSKILL.md.tmpl%23L59-L110).

### 4. test-audit

**Instruction sources:** [test-audit/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2FSKILL.md.tmpl).

**Approach.** Read-only discovery; spawned/headless report-only; source content untrusted; mechanical candidate screen; eight-minute budget and cap; complete test/owner/caller/history review; retire/rewrite/extend/retain cards; per-owner approval; scratch-worktree build proof before production deletion; JSON sidecar.

**Adopt.** A mechanical match is a lead, not a verdict; report retained false positives and suppressions. Make deletion depend on protected behavior and replacement evidence, not test count. Use ownership batches and resumable coverage. Expanded value bar asks protected contract, credible failure, distinct coverage and unnecessary seam; retention card records independent stronger proof and grep limitations.

**Adapt.** Tune time/candidate limits, runner detection, test patterns and file-safe parsing for the project. Preserve user authorization already given for an audit-and-cleanup task.

**Avoid or correct.** Filename and shell xargs heuristics need quoting/newline robustness. Never treat lack of an assertion keyword or grep hits as proof of dead production code. Mandatory regression-test pass at base assumes a newly introduced regression; a longstanding defect can fail at base and still justify a behavioral regression test. Label historical controls accurately rather than discarding valid tests.

**Trace points.** [test-audit/SKILL.md.tmpl:35-44](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2FSKILL.md.tmpl%23L35-L44), [test-audit/SKILL.md.tmpl:64-106](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2FSKILL.md.tmpl%23L64-L106), [test-audit/SKILL.md.tmpl:127-144](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2FSKILL.md.tmpl%23L127-L144).

### 5. eval-plan

**Instruction sources:** [eval-plan/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl).

**Approach.** Decision-first evaluation; quick versus publishable study; frozen preregistration; decoys and held-out exposure audit; no-skill control for each model; hostile-agent-repository grader isolation; planted diagnostic counts; paired comparisons and calibrated judge; current model policy; candidate/judge blinding; zero-cost stub dry run; per-arm pilot; concurrent spend reservations and unknown-charge ledger; approval gate; bounded interim look; result publication checks.

**Adopt.** Preregister bars and action decisions; preserve held-out data; prove the test mechanism with planted cases; independent baseline; actual transcript evidence; immutable model/settings identity; actual versus estimated spend; explicit unsupported future controls.

**Adapt.** House numbers (100 labeled samples, kappa >=0.6, 8192 output floor, USD 100/500 thresholds, one interim look) need study-specific design. User authorization should cover pilot cost before spending. Match judge calibration to task distribution and evaluate potential family effects.

**Avoid or correct.** Never present frontier-only model preferences or document-date exceptions as universal scientific requirements. A three-item pilot cannot establish a precise cost distribution. Unimplemented Tier 3 items must not count as shipped security or validation.

**Trace points.** [eval-plan/SKILL.md.tmpl:34-59](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl%23L34-L59), [eval-plan/SKILL.md.tmpl:91-142](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl%23L91-L142), [eval-plan/SKILL.md.tmpl:176-229](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl%23L176-L229), [eval-plan/SKILL.md.tmpl:231-317](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl%23L231-L317), [eval-plan/SKILL.md.tmpl:319-358](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl%23L319-L358).

### 6. context-save

**Instruction sources:** [context-save/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-save%2FSKILL.md.tmpl).

**Approach.** Append-only session snapshots; inferred titles; git/staged state; per-item provenance distinguishing read/run/assumed from target-state checks; English machine markers; deterministic sanitized filenames and collision suffix; project/remote/worktree/head stamps; branch-aware list.

**Adopt.** Record provenance and exact source revision; preserve unknowns; generate identifiers in deterministic helpers and return authoritative paths.

**Adapt.** Use a structured schema instead of relying only on trailing prose markers; use collision-resistant atomic creation and secrets redaction; honor user retention policies.

**Avoid or correct.** Raw-title environment assignment still needs safe transport before sanitization; random-suffix check is not atomic. Parent-process lifetime is an estimate of session duration.

**Trace points.** [context-save/SKILL.md.tmpl:76-119](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-save%2FSKILL.md.tmpl%23L76-L119), [context-save/SKILL.md.tmpl:149-234](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-save%2FSKILL.md.tmpl%23L149-L234), [context-save/SKILL.md.tmpl:313-323](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-save%2FSKILL.md.tmpl%23L313-L323).

### 7. context-restore

**Instruction sources:** [context-restore/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2FSKILL.md.tmpl), [context-restore/sections/transcripts.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2Fsections%2Ftranscripts.md.tmpl).

**Approach.** Current-branch preference with cross-branch fallback; canonical project identity; bounded checkpoint scan; explicit unknown/foreign handling; newer task disambiguation; head movement invalidates remaining-work confidence; read-only reconstruction from scoped transcripts plus live git/PR verification.

**Adopt.** Treat stale notes as evidence tied to a commit; preserve task order; distinguish intended from live outcome; bound transcript scope and treat transcript content as untrusted data.

**Adapt.** Map transcript access to actual host permissions, retention and user scope; source-native provenance beats string heuristics. Preserve continuation authorization rather than always ending on a menu.

**Avoid or correct.** Legacy unstamped files are trusted in a bucket with no observed foreign file, which is a heuristic. A 200-file scan can miss older current-branch saves. Raw transcript delegation to another model requires the same privacy boundary.

**Trace points.** [context-restore/SKILL.md.tmpl:67-171](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2FSKILL.md.tmpl%23L67-L171), [context-restore/SKILL.md.tmpl:173-268](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2FSKILL.md.tmpl%23L173-L268), [context-restore/SKILL.md.tmpl:318-348](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2FSKILL.md.tmpl%23L318-L348), [context-restore/sections/transcripts.md.tmpl:14-79](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2Fsections%2Ftranscripts.md.tmpl%23L14-L79).

### 8. learn

**Instruction sources:** [learn/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flearn%2FSKILL.md.tmpl).

**Approach.** Show/search/stats/export/add/prune modes; latest key/type wins; cross-project results restricted to user-stated learnings; no code edits; stale path and conflicting insight checks; explicit remove/update handling.

**Adopt.** Separate learned evidence from user-stated preferences; preserve unrelated entries and update by stable identity.

**Adapt.** Add source revision, timestamps, applicability and revalidation beyond a confidence number. Use structured input instead of interpolated JSON shell text.

**Avoid or correct.** Missing path alone does not prove an insight false; two types with one key do not automatically conflict. Confidence 1-10 without calibration is a label.

**Trace points.** [learn/SKILL.md.tmpl:25-55](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flearn%2FSKILL.md.tmpl%23L25-L55).

### 9. health

**Instruction sources:** [health/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fhealth%2FSKILL.md.tmpl).

**Approach.** Project tool detector; persisted Health Stack; private full logs and actual exit capture; independent sequential checks; absent tool versus executed failure; capture errors make composite N/A; weighted categories including GBrain; partial coverage; only identical coverage compared over time.

**Adopt.** Preserve exit status before parsers; parse full logs and display bounded tails; no checks is N/A; compare matching coverage and persist nulls accurately.

**Adapt.** Treat composite weights/rubrics as local heuristics; keep hard failure gates separate. Review configured commands as executable untrusted input. Version score definitions and tool configurations for valid trends.

**Avoid or correct.** Composite can hide a serious failure behind healthy categories. Raw-output tail can leak secrets without redaction. Published example scores do not all follow the discrete rubric; do not use illustrative rows as verified measurements.

**Trace points.** [health/SKILL.md.tmpl:89-187](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fhealth%2FSKILL.md.tmpl%23L89-L187), [health/SKILL.md.tmpl:274-317](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fhealth%2FSKILL.md.tmpl%23L274-L317), [health/SKILL.md.tmpl:367-375](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fhealth%2FSKILL.md.tmpl%23L367-L375).

### 10. modernize

**Instruction sources:** [modernize/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodernize%2FSKILL.md.tmpl).

**Approach.** Manual sensitive stale-PR review; separates semantic validity from clean rebase; guarded PR text; pins observed head; rejects head/base identity and merge-commit rebase proof gap; MODERNIZE/REWORK/CLOSE verdict before mutation; range-diff explanation; exact force-with-lease; owner permission and author credit.

**Adopt.** Observed-head lease and semantic-contract review; refuse proof that cannot cover merge commits; evaluate fork code before running it with credentials; explain every changed hunk.

**Adapt.** Use isolated worktree and preserve dirty local state; adapter-specific posting identity; avoid authorization duplication when already granted.

**Avoid or correct.** git switch -C can reset an existing local modernization branch; conflict resolution must preserve valid current contracts as well as original intent. Never infer permission from the ability to push.

**Trace points.** [modernize/SKILL.md.tmpl:39-55](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodernize%2FSKILL.md.tmpl%23L39-L55), [modernize/SKILL.md.tmpl:57-115](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodernize%2FSKILL.md.tmpl%23L57-L115), [modernize/SKILL.md.tmpl:117-167](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodernize%2FSKILL.md.tmpl%23L117-L167).

### 11. deslop-shared-libs

**Instruction sources:** [deslop-shared-libs/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdeslop-shared-libs%2FSKILL.md.tmpl).

**Approach.** Strict no-write/no-execution review including no temp files or telemetry; fixed UTC window; observed tip versus review commit and overlay; safe-git helper and GET-only remote fallback; no raw object-store bypass; isolated Python reads; no escaping symlinks; bounded older-open-PR overlap scan; independent caller proof and full LOC accounting.

**Adopt.** Precise source provenance, negative evidence scope, hostile git/runtime awareness, bounded API budgets, and zero-finding outcome. Excellent example of matching operational controls to strict read-only review. Expanded rubric requires verified first-party callers and shared semantic contract, compares reuse versus extraction, accounts total implementation/test/integration lines, and excludes generated duplicates from savings.

**Adapt.** Use available safer reader APIs and host adapters; balance a strict no-temp-file profile against reproducible audit evidence needs explicitly.

**Avoid or correct.** Do not transplant every exceptional git constraint into ordinary trusted coding tasks. Mechanical repetition/LOC savings are not sufficient without contract equivalence and shared-failure analysis. Net LOC reduction is one cost measure, not a substitute for reliability/maintainability or appropriate boundaries.

**Trace points.** [deslop-shared-libs/SKILL.md.tmpl:25-98](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdeslop-shared-libs%2FSKILL.md.tmpl%23L25-L98), [deslop-shared-libs/SKILL.md.tmpl:117-148](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdeslop-shared-libs%2FSKILL.md.tmpl%23L117-L148), [deslop-shared-libs/SKILL.md.tmpl:150-181](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdeslop-shared-libs%2FSKILL.md.tmpl%23L150-L181).

### 12. captain

**Instruction sources:** [captain/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2FSKILL.md.tmpl), [captain/templates/AGENTS.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FAGENTS.md), [captain/templates/CREW.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FCREW.md), [captain/templates/DIGEST.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FDIGEST.md), [captain/templates/NOTES.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FNOTES.md), [captain/templates/READY.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FREADY.md), [captain/templates/automation-flaky-pass.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fautomation-flaky-pass.md), [captain/templates/brief.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fbrief.md), [captain/templates/flaky-ledger.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fflaky-ledger.md), [captain/templates/merge-ask.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fmerge-ask.md), [captain/templates/merge-train-peer.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fmerge-train-peer.md), [captain/templates/plan-ask.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fplan-ask.md), [captain/templates/postmortem.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fpostmortem.md), [captain/templates/report.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Freport.md), [captain/templates/slot-call.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fslot-call.md).

**Approach.** Controller/lane ownership; parameterized rule pointers and standing approvals; exact-head READY and receipt validation; frozen heads; sequential prefix-tree merge trains; stamp-only gate reuse; server-side head match; postmerge verification; red-train attribution and freeze/repair; compact digest, exact-word approval ledger, plan exemptions, flaky-cause repair and evidence-based postmortems. Templates cover rules, parameters, digest, append-only notes, READY, daily flake automation, brief, ledger, asks, peer trains, postmortem, report and slot call.

**Adopt.** Use immutable identity and explicit completion contracts; disjoint file ownership; central merge coordination; verify actual merged tree; distinguish incomplete from failed; retain failed/skipped/unverified disclosures; handoff and postmortem cite evidence.

**Adapt.** A train is warranted for active concurrent integration, not every small skill project. Make spent-money/merge/publication authorization explicit. Approval language should match user capability, without patronizing wording or treating a general reply as consent to unspecified follow-ons.

**Avoid or correct.** The two-failures-is-real and one-pass-is-flaky rule is operational triage, not statistical proof. Treating every external contribution as rewrite-on-main is a project policy, not OSS best practice. Turning every lesson into a global rule risks instruction bloat. Slot instructions include discarding unnamed worktree/staged changes; preserve user work instead.

**Trace points.** [captain/SKILL.md.tmpl:48-129](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2FSKILL.md.tmpl%23L48-L129), [captain/SKILL.md.tmpl:131-248](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2FSKILL.md.tmpl%23L131-L248), [captain/SKILL.md.tmpl:267-320](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2FSKILL.md.tmpl%23L267-L320), [captain/SKILL.md.tmpl:322-373](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2FSKILL.md.tmpl%23L322-L373), [captain/templates/slot-call.md:11-25](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fslot-call.md%23L11-L25), [captain/templates/postmortem.md:32-70](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fpostmortem.md%23L32-L70).

### 13. pair-agent

**Instruction sources:** [pair-agent/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl).

**Approach.** Browser pairing with expiring one-time key and scoped session; local credential writing or internet tunnel; daemon restart confirmation; standing tunnel consent; remote-provider instructions; ngrok secret handoff outside chat; connection verification; scoped tabs/domain/rate limits; narrowing re-pair revokes old session; explicit revoke and restart behavior.

**Adopt.** State access surface and local/remote distinction; separate destructive restart from pairing; verify connection and revocation; never transmit long-lived tunnel secret in chat; revoke old privilege when narrowing.

**Adapt.** Default to task-necessary access and assess session sharing, domain egress and page injection. Credentials, output block and helper implementation need runtime tests, not prose trust alone.

**Avoid or correct.** Lines 44-45 overclaim that a leaked five-minute key cannot be abused. Line 189 claims JS in default access but lines 279-285 forbid it remotely; qualify local versus tunnel. Same-machine credential writing is still a trust decision.

**Trace points.** [pair-agent/SKILL.md.tmpl:37-52](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl%23L37-L52), [pair-agent/SKILL.md.tmpl:109-173](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl%23L109-L173), [pair-agent/SKILL.md.tmpl:189-232](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl%23L189-L232), [pair-agent/SKILL.md.tmpl:270-303](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl%23L270-L303), [pair-agent/SKILL.md.tmpl:344-369](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl%23L344-L369).

### 14. runaway-stopper

**Instruction sources:** [runaway-stopper/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2FSKILL.md.tmpl), [runaway-stopper/templates/rotation-handoff.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2Ftemplates%2Frotation-handoff.md), [runaway-stopper/templates/successor-brief.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2Ftemplates%2Fsuccessor-brief.md).

**Approach.** Capy-only thread/subagent resource sweep; batched bounded transcript metadata; ownership-restricted stopping; defer during ship/merge/open-PR work; separate unavailable input from clean; standing role rotation with successor subscriptions/waits; event-driven quiet wakes and compact output; thresholds tied to dated org rules.

**Adopt.** Bound work and detect missing input; protect live ownership; successor confirms subscriptions before prior role stops; capture known state and cost at handoff.

**Adapt.** Abstract host lifecycle APIs and make quotas configurable from measured cost/reliability. Preserve user-required progress updates even if internal agent chatter stays quiet.

**Avoid or correct.** The very large token thresholds and timing rules reflect one host/org and changed accounting; do not present as general budgets. Source author-specific Captain rotation authority is not a portable rule.

**Trace points.** [runaway-stopper/SKILL.md.tmpl:25-30](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2FSKILL.md.tmpl%23L25-L30), [runaway-stopper/SKILL.md.tmpl:34-92](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2FSKILL.md.tmpl%23L34-L92), [runaway-stopper/SKILL.md.tmpl:94-132](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2FSKILL.md.tmpl%23L94-L132).

### 15. landing-report

**Instruction sources:** [landing-report/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flanding-report%2FSKILL.md.tmpl).

**Approach.** Queue dashboard discovers base/version, fetches current base, computes micro/patch/minor/major slots, shows claims and active siblings, offline state, collisions and next action.

**Adopt.** Show observation freshness, missing queue information and collision evidence; share one deterministic version allocator with ship.

**Adapt.** Prefer one read-only state query and compute four scenarios in memory; use user-scoped private temp directory if files are needed; qualify snapshot predictions.

**Avoid or correct.** Explicit contradiction: lines 165-166 claim no file writes or git mutations; line 56 runs git fetch and line 75 writes predictable /tmp JSON files. Next /ship collision-free claim can be invalidated immediately by concurrent actors. Four-component versioning and sibling activity are project-specific.

**Trace points.** [landing-report/SKILL.md.tmpl:39-77](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flanding-report%2FSKILL.md.tmpl%23L39-L77), [landing-report/SKILL.md.tmpl:81-159](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flanding-report%2FSKILL.md.tmpl%23L81-L159), [landing-report/SKILL.md.tmpl:163-166](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flanding-report%2FSKILL.md.tmpl%23L163-L166).

### 16. ios-qa

**Instruction sources:** [ios-qa/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2FSKILL.md.tmpl), [ios-qa/docs/tailscale-acl-example.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2Fdocs%2Ftailscale-acl-example.md).

**Approach.** Real-device source-driven QA; explicit supported Swift observation/SPM scope; preserve production install on unsupported projects; deterministic debug bridge generation; compile-time Release guard; one-use bootstrap token rotation; device/app-bound private session cache; screenshot/accessibility/state loop with lock; separate local/tailnet listeners and capability tiers; UI-only demo mode; uncertain mutation response is never replayed blindly; documented platform limits.

**Adopt.** Validate environment before editing; preserve production builds; structural enforcement separate from cleanup instructions; bind persisted credentials to device/app; classify evidence from state fixtures versus real provider behavior; observe after uncertain writes.

**Adapt.** Port platform details through optional resource modules. Verify Release-symbol isolation and actual entitlement/install behavior. Redact state and screenshots before retaining fixtures. Use upstream-valid tailnet policy and port configuration.

**Avoid or correct.** Tailscale example lines 112-117 uses unsupported ACL action drop; official syntax permits accept only (https://tailscale.com/docs/reference/syntax/policy-file; turn559604442search1). Local instruction uses daemon default port 9099 but ACL example uses 9999 without showing override. Bootstrap commands and documented security claims require real-device/runtime checks.

**Trace points.** [ios-qa/SKILL.md.tmpl:108-196](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2FSKILL.md.tmpl%23L108-L196), [ios-qa/SKILL.md.tmpl:198-240](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2FSKILL.md.tmpl%23L198-L240), [ios-qa/SKILL.md.tmpl:261-301](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2FSKILL.md.tmpl%23L261-L301), [ios-qa/docs/tailscale-acl-example.md:91-119](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2Fdocs%2Ftailscale-acl-example.md%23L91-L119).

### 17. ios-clean

**Instruction sources:** [ios-clean/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-clean%2FSKILL.md.tmpl).

**Approach.** Inventory and approval before removing generated dependencies, markers, debug wiring and device token; preserve unrelated source; Release build plus symbol check; clean exit from framework.

**Adopt.** Document uninstall and structural release isolation separately. Inventory owned generated assets and verify compiled artifact after removal.

**Adapt.** Use an install manifest and backup/untracked-file handling; avoid installing a Release app onto a production device solely for cleanup verification.

**Avoid or correct.** Claim that every delete can be undone with git restore is false for untracked files and device state. A grep absence check can miss dynamic references and can flag innocent documentation; pair it with actual build/symbol evidence.

**Trace points.** [ios-clean/SKILL.md.tmpl:32-38](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-clean%2FSKILL.md.tmpl%23L32-L38), [ios-clean/SKILL.md.tmpl:46-60](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-clean%2FSKILL.md.tmpl%23L46-L60), [ios-clean/SKILL.md.tmpl:68-107](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-clean%2FSKILL.md.tmpl%23L68-L107).

### 18. ios-design-review

**Instruction sources:** [ios-design-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-design-review%2FSKILL.md.tmpl).

**Approach.** Device visual review by ten dimensions; Apple/platform conventions, contrast, touch, dynamic type, motion and UI states; screenshots plus accessibility; observed screen-count gaps; report-only findings and prioritized user choices.

**Adopt.** Use screenshot evidence and explicit missing-screen coverage; separate visual diagnosis from edits and share report into planning.

**Adapt.** Cite current accessibility/platform requirements and label aesthetic preferences. A screenshot cannot establish VoiceOver, Dynamic Type or contrast without direct checks. Bootstrap is an installation action, not purely read-only.

**Avoid or correct.** A below-7 question per dimension can create needless interruption. Fixed font/grid/animation prescriptions and 0-10 scores are house preferences, not proof of compliance.

**Trace points.** [ios-design-review/SKILL.md.tmpl:40-90](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-design-review%2FSKILL.md.tmpl%23L40-L90), [ios-design-review/SKILL.md.tmpl:94-111](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-design-review%2FSKILL.md.tmpl%23L94-L111).

### 19. ios-fix

**Instruction sources:** [ios-fix/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-fix%2FSKILL.md.tmpl).

**Approach.** Capture reproducible state and screenshots; root-cause trace; minimal patch; rebuild/redeploy; restore pre-state and compare; bounded three tries; real-device regression fixture and test.

**Adopt.** A reproducible before-state and independent after-verification; preserve evidence and stop on bounded failure.

**Adapt.** Support bugs not captured by snapshot-eligible state; use deterministic assertions for outcome rather than screenshot difference alone; report device-test skips as unverified.

**Avoid or correct.** Description promises a bug can never recur silently, but regression test is skipped without device. Asking user to choose among root-cause hypotheses transfers diagnosis instead of testing hypotheses. Re-snapshot after schema mismatch can lose the original reproduction.

**Trace points.** [ios-fix/SKILL.md.tmpl:36-64](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-fix%2FSKILL.md.tmpl%23L36-L64), [ios-fix/SKILL.md.tmpl:66-103](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-fix%2FSKILL.md.tmpl%23L66-L103).

### 20. ios-sync

**Instruction sources:** [ios-sync/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-sync%2FSKILL.md.tmpl).

**Approach.** Version marker; deterministic regenerator; restricted supported source types; removes only known obsolete generated files; composite hash key; generated diff inspection; handwritten source preserved; compile/device schema verification.

**Adopt.** Explicit source/output ownership, exact generator provenance, supported-type diagnostics, safe obsolete-file list.

**Adapt.** Let content hash decide whether regeneration is required; preserve local generated edits with a warning or backup; measure no-op latency instead of copying the 50ms claim.

**Avoid or correct.** Early exit at lines 51-52 checks version and new classes, while changed marked properties within existing classes also require regeneration; that can bypass the stronger composite-hash logic later. Broad git restore can erase unrelated work unless paths are precise.

**Trace points.** [ios-sync/SKILL.md.tmpl:34-52](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-sync%2FSKILL.md.tmpl%23L34-L52), [ios-sync/SKILL.md.tmpl:54-99](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-sync%2FSKILL.md.tmpl%23L54-L99).

### 21. codex

**Instruction sources:** [codex/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2FSKILL.md.tmpl), [codex/sections/review-mode.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Freview-mode.md.tmpl), [codex/sections/challenge-mode.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fchallenge-mode.md.tmpl), [codex/sections/consult-mode.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fconsult-mode.md.tmpl).

**Approach.** Mutually exclusive progressive mode loading; actual model entitlement/sandbox probes; explicit overrides outrank configured models; execution completion plus structured verdict; timeout nesting; private prompt files; scoped diff and review receipts; resumed consultation.

**Adopt.** Preserve provider choice, diagnose unavailable versus clean, bind evidence to actual diff/version, and validate outside results independently of model prose.

**Adapt.** Use neutral reviewer persona; date and benchmark token/cost/effort claims; redact reviewer traces; treat delimiter boundaries as one mitigation; review untracked input explicitly; make source/executable path rules task-specific.

**Avoid or correct.** Persona equating autism with 200 IQ is inappropriate and unsubstantiated. Broad prohibition on reading .agents/SKILL.md creates blind spots for skill repositories. Never-modify-files claim conflicts with session/log/temp writes. Prompt blacklists are not sandbox enforcement. Mode defaults and xhigh 23x claims require dated evidence. Shell variables assumed to persist across separate fences reduce portability.

**Trace points.** [codex/SKILL.md.tmpl:201-205](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2FSKILL.md.tmpl%23L201-L205), [codex/SKILL.md.tmpl:244-263](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2FSKILL.md.tmpl%23L244-L263), [codex/SKILL.md.tmpl:327-344](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2FSKILL.md.tmpl%23L327-L344), [codex/sections/review-mode.md.tmpl:88-120](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Freview-mode.md.tmpl%23L88-L120), [codex/sections/review-mode.md.tmpl:176-187](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Freview-mode.md.tmpl%23L176-L187), [codex/sections/consult-mode.md.tmpl:67-73](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fconsult-mode.md.tmpl%23L67-L73), [codex/sections/consult-mode.md.tmpl:169-185](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fconsult-mode.md.tmpl%23L169-L185).

### 22. claude-code

**Instruction sources:** [claude-code/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fclaude-code%2FSKILL.md.tmpl).

**Approach.** Non-Claude host routing; tool-less diff review/challenge versus Read/Grep/Glob consult; hooks/MCP/slash commands disabled; direct argv and stdin; private owned scratch; validated completion and model usage; selective resume repair.

**Adopt.** Strong explicit execution boundary; no provider substitution; each fence self-contained; actual invocation errors determine auth; missing coverage never clean; delete only owned scratch; preserve session on unrelated error.

**Adapt.** Document that git fetch mutates metadata and consultation persists .context; protect private source before sending externally and set scope limits.

**Avoid or correct.** Do not infer independent judgment from solely another model. Faithful output still needs untrusted-output fencing/redaction. Working-tree diff omits untracked files and fetch failure can leave stale base.

**Trace points.** [claude-code/SKILL.md.tmpl:37-79](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fclaude-code%2FSKILL.md.tmpl%23L37-L79), [claude-code/SKILL.md.tmpl:86-153](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fclaude-code%2FSKILL.md.tmpl%23L86-L153), [claude-code/SKILL.md.tmpl:223-307](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fclaude-code%2FSKILL.md.tmpl%23L223-L307).

### 23. scrape

**Instruction sources:** [scrape/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fscrape%2FSKILL.md.tmpl).

**Approach.** Structured snapshot-first extraction; fuzzy read-only agent via private prompt; attacker-controlled page warning; existing matching browser skill preferred; owned tabs; finite retries; stable JSON.

**Adopt.** Keep errors distinct from empty data, do not treat extracted text as instructions, isolate owned tabs and stable machine output.

**Adapt.** Distinguish navigation clicks from business writes; encode URL/selector inputs via files or argv instead of brittle apostrophe bans; explicit site/session scope.

**Avoid or correct.** Nothing-written stdout-only claim conflicts with private prompt files and learning macro. A 200ms promise is not universal. Read-only intent alone does not prevent GET-side effects or browser automation capability misuse.

**Trace points.** [scrape/SKILL.md.tmpl:27-47](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fscrape%2FSKILL.md.tmpl%23L27-L47), [scrape/SKILL.md.tmpl:60-70](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fscrape%2FSKILL.md.tmpl%23L60-L70), [scrape/SKILL.md.tmpl:119-145](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fscrape%2FSKILL.md.tmpl%23L119-L145), [scrape/SKILL.md.tmpl:175-187](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fscrape%2FSKILL.md.tmpl%23L175-L187).

### 24. setup-browser-cookies

**Instruction sources:** [setup-browser-cookies/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-browser-cookies%2FSKILL.md.tmpl).

**Approach.** Probe session-sharing browser first; choose source profile/domain/target; separately opt into identity verification, storage reset, all cookies; receipt-driven outcomes; private auth values; native-platform limitations.

**Adopt.** Cookie count or 200 is never authentication proof; exactly one visible identity match; explicit consent for cross-context credential import/reset; preserve partial-failure status.

**Adapt.** Use platform adapters and actual evidence for browser encryption limitations; document imported cookies apply across context and tokens remain sensitive.

**Avoid or correct.** Do not infer user consent from default browser. No raw cookies/errors in public logs; no repeated keychain denial prompts.

**Trace points.** [setup-browser-cookies/SKILL.md.tmpl:31-45](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-browser-cookies%2FSKILL.md.tmpl%23L31-L45), [setup-browser-cookies/SKILL.md.tmpl:54-82](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-browser-cookies%2FSKILL.md.tmpl%23L54-L82).

### 25. open-reference-project-browser

**Instruction sources:** [open-reference-project-browser/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopen-reference-project-browser%2FSKILL.md.tmpl).

**Approach.** Non-autostart status, destructive daemon replacement approval, preserve spawned-session daemon, verify headed mode and extension, user visible activity/demo.

**Adopt.** Consent tied to actual session loss; verify real state before celebrating; report reconnect failures.

**Adapt.** Probe liveness before deleting profile locks; adapt shortcuts/platform paths; optional demo and sidebar onboarding.

**Avoid or correct.** Unqualified claims that anti-bot patches make major sites work without captchas are not guarantees. Failed status alone is not proof Chromium profile is unused; removing lock files first merits runtime race review.

**Trace points.** [open-reference-project-browser/SKILL.md.tmpl:33-86](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopen-reference-project-browser%2FSKILL.md.tmpl%23L33-L86), [open-reference-project-browser/SKILL.md.tmpl:100-114](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopen-reference-project-browser%2FSKILL.md.tmpl%23L100-L114), [open-reference-project-browser/SKILL.md.tmpl:189-245](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopen-reference-project-browser%2FSKILL.md.tmpl%23L189-L245).

### 26. diagram

**Instruction sources:** [diagram/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdiagram%2FSKILL.md.tmpl).

**Approach.** Offline versioned render bundle; editable source/scene plus SVG/PNG; types with image-only scene explicitly disclosed; confined loopback staging; base64 transport; render errors visible; show PNG and round-trip editable scene.

**Adopt.** Deliver editable source with rendered artifacts; state editability limitations; inspect actual output; preserve offline contract and concurrent content-addressed bundles.

**Adapt.** Fixed resolution/node counts are defaults; paths need shell-safe quoting; UTF-8 decode should be standard TextDecoder rather than deprecated escape.

**Avoid or correct.** Do not equate creating a PNG with visually verifying layout. Slug output may overwrite existing user work without unique naming or version checks.

**Trace points.** [diagram/SKILL.md.tmpl:45-91](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdiagram%2FSKILL.md.tmpl%23L45-L91), [diagram/SKILL.md.tmpl:93-159](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdiagram%2FSKILL.md.tmpl%23L93-L159).

### 27. make-pdf

**Instruction sources:** [make-pdf/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmake-pdf%2FSKILL.md.tmpl).

**Approach.** Single-file HTML/PDF/DOCX; font checks; consistent print CSS; offline by default; path/type/size guards for assets; strict CI; vector diagrams; TOC verification failures; explicit exit/output contract.

**Adopt.** Asset boundaries, useful diagnostics, honest DOCX layout limitations, network opt-in, and independently verified TOC.

**Adapt.** Require render-and-inspect/readback QA; accessible tagging is not proof of accessibility; choose branding/footer/page defaults for audience; preserve original source.

**Avoid or correct.** Publication-quality and zero-truncation claims exceed an instruction promise. Debug advice removing fenced code can discard requested content; diagnose renderer instead.

**Trace points.** [make-pdf/SKILL.md.tmpl:127-177](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmake-pdf%2FSKILL.md.tmpl%23L127-L177), [make-pdf/SKILL.md.tmpl:226-255](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmake-pdf%2FSKILL.md.tmpl%23L226-L255).

### 28. ubicloud

**Instruction sources:** [ubicloud/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2FSKILL.md.tmpl).

**Approach.** TTL and owner-scoped ephemeral compute; quota preflight; bounded watchdog; committed verification definition; explicit env forwarding; in-tree artifact pulls; teardown verification; resume/ownership.

**Adopt.** Cost includes confirmed deletion; unknown create/teardown never clean; explicit secret grants; same-machine before/after; no destroying others resources.

**Adapt.** Project-specific bootstrap/root changes need trust boundary and budget; --trust-config is broad authority; resumable results must bind tree/environment.

**Avoid or correct.** TTL is not autonomous shutdown: reaper runs on next owner invocation. sensitive:false is misleading for paid resource/credential workflow. Fixed owner lane7 examples must not be copied by concurrent sessions. No exact cost ceiling is shown.

**Trace points.** [ubicloud/SKILL.md.tmpl:43-58](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2FSKILL.md.tmpl%23L43-L58), [ubicloud/SKILL.md.tmpl:71-100](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2FSKILL.md.tmpl%23L71-L100), [ubicloud/SKILL.md.tmpl:112-158](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2FSKILL.md.tmpl%23L112-L158), [ubicloud/SKILL.md.tmpl:174-215](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2FSKILL.md.tmpl%23L174-L215).

### 29. design-consultation

**Instruction sources:** [design-consultation/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2FSKILL.md.tmpl), [design-consultation/sections/proposal-and-preview.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md.tmpl), [design-consultation/sections/proposal-and-preview.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md).

**Approach.** Read prior context before asking; cancel/update/fresh with preserved legacy formats; optional research with exact origins; brief before independent voices; verified font sources/licenses; product-specific design rationale; approval-bound image/token extraction and final writes.

**Adopt.** Use known user context; independent proposals without leaking own answer; token-source provenance; preserve legacy file shape; stale approvals invalidated when content changes; explicit missing research/fonts. Taste-profile expansion separates explicit approved/rejected feedback, read-time decay, bounded retained sessions, migration and current request precedence.

**Adapt.** House banned-font/style lists are taste, not standards. Separate aesthetic constraints from accessibility and usability. Source-local permission policy varies by caller.

**Avoid or correct.** Rejecting every common font/system stack can worsen usability/performance. Repeated Q1/Q2/Qfinal should respect prior authorization. HTML called self-contained still loads remote fonts. Human embarrassment gate is subjective. Profile confidence is heuristic; 5% weekly decay and confidence-times-count ranking need calibrated validation. Treat stored notes as data, not authority; do not infer visual properties from variant letters.

**Trace points.** [design-consultation/SKILL.md.tmpl:59-103](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2FSKILL.md.tmpl%23L59-L103), [design-consultation/SKILL.md.tmpl:125-214](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2FSKILL.md.tmpl%23L125-L214), [design-consultation/sections/proposal-and-preview.md.tmpl:30-51](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md.tmpl%23L30-L51), [design-consultation/sections/proposal-and-preview.md.tmpl:125-159](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md.tmpl%23L125-L159), [design-consultation/sections/proposal-and-preview.md.tmpl:205-218](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md.tmpl%23L205-L218), [design-consultation/sections/proposal-and-preview.md:102-248](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md%23L102-L248), [design-consultation/sections/proposal-and-preview.md:347-385](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md%23L347-L385).

### 30. design-motion

**Instruction sources:** [design-motion/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2FSKILL.md.tmpl), [design-motion/sections/fidelity.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Ffidelity.md.tmpl), [design-motion/sections/figma.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Ffigma.md.tmpl), [design-motion/sections/motion.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Fmotion.md.tmpl).

**Approach.** Exact approved source resolution; website/showcase modes; deterministic fakeclock capture; still/PSNR comparison, seam/empty/rest/overflow checks, bounded iteration; Figma secret safety; reduced motion; attribution.

**Adopt.** Artifacts need explicit measurable contracts, deterministic time, failure evidence, constraints and output metrics. Never substitute missing approved source.

**Adapt.** PSNR and pixel thresholds house metrics not human-fidelity proof; font/renderer nondeterminism; GIF performance; animation values not universal.

**Avoid or correct.** Content must render without script; do not call a single screenshot a complete accessibility test. Motion filter/clip-path permitted here but design-review checklist says only transform/opacity.

**Trace points.** [design-motion/SKILL.md.tmpl:43-50](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2FSKILL.md.tmpl%23L43-L50), [design-motion/SKILL.md.tmpl:114-173](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2FSKILL.md.tmpl%23L114-L173), [design-motion/sections/fidelity.md.tmpl:37-45](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Ffidelity.md.tmpl%23L37-L45), [design-motion/sections/motion.md.tmpl:101-120](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Fmotion.md.tmpl%23L101-L120).

### 31. design-shotgun

**Instruction sources:** [design-shotgun/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2FSKILL.md.tmpl), [design-shotgun/sections/doctrine.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md.tmpl), [design-shotgun/sections/doctrine.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md).

**Approach.** Bounded context questions; honor design source; taste memory limited to actual feedback dimensions; distinct concepts before paid generation; preserve correct approved-image identity; comparison feedback and downstream handoff.

**Adopt.** Explicit final artifact identity and stale-feedback prevention; costs before paid variants; shared system constraints; retained editable revision provenance. Expanded batch generation uses per-run staging, per-variant outcomes, no-overwrite claim helper, exact board-image mapping, readiness marker instead of PID, and stale Submit archival.

**Adapt.** User taste can evolve; memory needs scope/expiry/edit/delete. UX principles are contextual heuristics even though doctrine claims observed universal laws.

**Avoid or correct.** No blanket instruction that thought or reading means failure; complex/legal/medical interfaces require explanation. Mandatory 44px all-target rule is a house target, not full WCAG conformance. Board feedback should bind an immutable run/revision and image hashes; second-resolution feedback archival may collide, and pending old feedback requires validation. Automatic paid retries/sequential fallback need one total budget/deadline. Saved variants do not equal billable images because regeneration may add charges. Image-generated layout remains proposed design, not implementation proof.

**Trace points.** [design-shotgun/SKILL.md.tmpl:101-184](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2FSKILL.md.tmpl%23L101-L184), [design-shotgun/SKILL.md.tmpl:201-244](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2FSKILL.md.tmpl%23L201-L244), [design-shotgun/SKILL.md.tmpl:270-314](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2FSKILL.md.tmpl%23L270-L314), [design-shotgun/sections/doctrine.md:5-20](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md%23L5-L20), [design-shotgun/sections/doctrine.md:79-86](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md%23L79-L86).

### 32. design-review

**Instruction sources:** [design-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md.tmpl), [design-review/sections/build-loop.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fbuild-loop.md.tmpl), [design-review/sections/craft-audit.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fcraft-audit.md.tmpl), [design-review/sections/outside-voices.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Foutside-voices.md.tmpl), [design-review/sections/test-bootstrap.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Ftest-bootstrap.md.tmpl), [design-review/sections/outside-voices.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Foutside-voices.md), [design-review/sections/craft-audit.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fcraft-audit.md), [design-review/sections/test-bootstrap.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Ftest-bootstrap.md).

**Approach.** Screenshot-backed rendered audits, per-page routes and states, design-system calibration, before/after commit evidence; exact-tree build receipt with state inventory; separate incomplete/stale/waived statuses; transient redacted DOM; outside source consistency audit.

**Adopt.** State inventory and final read-only verification are strong reusable patterns. Distinguish no detector from clean; grants for remote targets; stale receipts invalidated; preserve local source edits in build mode. Expanded setup gives bounded readiness and deterministic optional checksum-pinned detector with explicit opt-out and evidence confirmation.

**Adapt.** Scores, goodwill percentages, risk percentages and AI-style rules are subjective house rubrics, not measured probability; allow existing test edits when needed.

**Avoid or correct.** Verified WCAG text error: generated SKILL644 large text 18px+ should be18pt regular/14pt bold. CSS changes are not zero risk despite canonical255. Never blanket commit all existing user changes. Screenshot-only checks do not prove reduced-motion handling: matchMedia only observes a setting. Marketing claims need real sources. Browser LOCAL hostname test does not prove sandbox/test-data authority: localhost/.test may proxy production. Full test-bootstrap assumes existing documented command works, and claims current research even when forced to built-in fallback; 100% coverage rhetoric is not measured assurance. Default CI generation and repository instruction edits need appropriate scope. Detector source hits are clues, confirmed in render, not automatic defects.

**Trace points.** [design-review/SKILL.md.tmpl:58-74](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md.tmpl%23L58-L74), [design-review/SKILL.md.tmpl:209-261](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md.tmpl%23L209-L261), [design-review/SKILL.md.tmpl:323-329](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md.tmpl%23L323-L329), [design-review/sections/build-loop.md.tmpl:33-58](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fbuild-loop.md.tmpl%23L33-L58), [design-review/sections/build-loop.md.tmpl:82-114](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fbuild-loop.md.tmpl%23L82-L114), [design-review/SKILL.md:644](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L644), [design-review/SKILL.md:664](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L664), [design-review/SKILL.md:689-695](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L689-L695), [design-review/SKILL.md:789-801](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L789-L801), [design-review/SKILL.md:844-875](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md%23L844-L875).

### 33. design-html

**Instruction sources:** [design-html/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2FSKILL.md.tmpl), [design-html/sections/craft.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fcraft.md.tmpl), [design-html/sections/doctrine.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdoctrine.md.tmpl), [design-html/sections/pretext-patterns.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fpretext-patterns.md.tmpl), [design-html/sections/detector-install-offer.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdetector-install-offer.md.tmpl), [design-html/sections/detector-install-offer.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdetector-install-offer.md).

**Approach.** Approved/mockup/plan/freeform/evolve routing; craft checklist and real-claim discipline; Pretext implementation examples; browser viewports; bounded targeted refinement; source metadata; optional project copy.

**Adopt.** Keep artifact provenance; protect edits and approved source; behavior states; no invented claims; report unavailable measurement; checksum-pinned optional third-party detector consent.

**Adapt.** Use Pretext only if actual layout requires it; freeze versions; inspect node/line API compatibility. Contenteditable belongs in editing preview rather than default production. Browser fonts/CDN affect offline claims.

**Avoid or correct.** Every-page mandatory dependency and unversioned esm.sh fallback conflict with zero-deps/self-contained promises. Source edit does not persist a user DOM contenteditable change automatically. Obstacle pattern subtracts widths but always x=0, cannot model arbitrary left/right obstacles without offset handling. parseFloat(lineHeight) can be NaN for normal.

**Trace points.** [design-html/SKILL.md.tmpl:230-260](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2FSKILL.md.tmpl%23L230-L260), [design-html/SKILL.md.tmpl:270-280](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2FSKILL.md.tmpl%23L270-L280), [design-html/SKILL.md.tmpl:346-372](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2FSKILL.md.tmpl%23L346-L372), [design-html/SKILL.md.tmpl:463-480](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2FSKILL.md.tmpl%23L463-L480), [design-html/sections/pretext-patterns.md.tmpl:23-41](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fpretext-patterns.md.tmpl%23L23-L41), [design-html/sections/pretext-patterns.md.tmpl:65-88](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fpretext-patterns.md.tmpl%23L65-L88), [design-html/sections/detector-install-offer.md:8-40](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdetector-install-offer.md%23L8-L40).

### 34. plan-design-review

**Instruction sources:** [plan-design-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2FSKILL.md.tmpl), [plan-design-review/sections/review-sections.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md.tmpl), [plan-design-review/sections/checklist.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Fchecklist.md.tmpl).

**Approach.** Scope resolved before tools; host plan-state provenance; UI applicability; visual references; seven passes with six numeric scores; approval ledger continuity; worst-dimension overall score; read-back before completion receipt.

**Adopt.** Separate required verification from optional future scope; reuse exact prior decisions; report unanswered gaps; include error/empty/partial states; bind mockups to decisions. Expanded report read-back gates completion logging, tracks unknown provenance, latest failure over old success, and diff fingerprints versus plan freshness.

**Adapt.** Use proportionate approvals and respect explicit user delegation; aesthetic scores as rubric; host plan mode rules always prevail; separate paid image budget from availability.

**Avoid or correct.** Skill cannot unilaterally declare writes ALWAYS allowed in host plan mode. Automatic paid mockups whenever binary exists needs configured user budget/consent. Requiring individual questions for every obvious correction causes high friction under autonomous task authorization. Delete-then-append report replacement is multi-step and can lose report on interruption; write atomically with content/version check where possible. Seven-day plan freshness with optional plan hash can bless changed plans; bind review to exact plan and dependency inputs. Shared task file names collide across concurrent same-phase runs. 100x/50x/30x effort ratios lack measured basis.

**Trace points.** [plan-design-review/SKILL.md.tmpl:32-73](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2FSKILL.md.tmpl%23L32-L73), [plan-design-review/SKILL.md.tmpl:168-236](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2FSKILL.md.tmpl%23L168-L236), [plan-design-review/SKILL.md.tmpl:240-259](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2FSKILL.md.tmpl%23L240-L259), [plan-design-review/sections/review-sections.md.tmpl:18-47](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md.tmpl%23L18-L47), [plan-design-review/sections/review-sections.md.tmpl:153-181](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md.tmpl%23L153-L181), [plan-design-review/sections/review-sections.md.tmpl:229-247](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md.tmpl%23L229-L247).

### 35. devex-review

**Instruction sources:** [devex-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md.tmpl).

**Approach.** Live versus inferred DX, onboarding clock, typed error-path capture, no-terminal/scrubbed environment/deadline, redacted evidence, versioned rubric comparisons, documentation/search/community audit.

**Adopt.** Explicit TESTED/PARTIAL/INFERRED and unknown; compatible baseline rubric; error redaction and safe recovery contract; isolation before malformed CLI trials. Browser cookbook separates tool/script failure from application failure; requires sentinel and precondition evidence, fresh refs, and owner-tab boundaries.

**Adapt.** Validate target CLI before any execution; --help alone may execute repository code; preserve user-selected noninteractive paths and real human onboarding clock.

**Avoid or correct.** Template step times are marked estimates while final TTHW says measured—must actually time full path. Screenshots are not sufficient for CLI behavior or source performance; no rating based on simple link existence. Embedded cookbook flow submits before reading back values despite browser rule requiring readback; examples and surrounding safety contract must agree. Fixed sleeps are only illustrative and should become state waits. A prose 120-second budget does not independently cancel running commands.

**Trace points.** [devex-review/SKILL.md.tmpl:52-63](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md.tmpl%23L52-L63), [devex-review/SKILL.md.tmpl:86-159](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md.tmpl%23L86-L159), [devex-review/SKILL.md.tmpl:215-259](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md.tmpl%23L215-L259).

### 36. plan-devex-review

**Instruction sources:** [plan-devex-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2FSKILL.md.tmpl), [plan-devex-review/sections/review-sections.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Freview-sections.md.tmpl), [plan-devex-review/sections/checklist.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Fchecklist.md.tmpl), [plan-devex-review/dx-hall-of-fame.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fdx-hall-of-fame.md).

**Approach.** Product/persona evidence, empathy as hypothesis, same-boundary competitive clocks, explicit scope and decision ledger; eight passes; agent-ready eight-item errors; trace/side-effect/reconcile classifications; plan/live comparison version.

**Adopt.** Known scope and approvals persist; no expansion from a checklist; separate measured execution from human onboarding; failure channel consistent; instructions/data boundary for other-agent documents. Expanded independent challenge preserves exact accepted scope and unresolved evidence; excludes partial/late agent output and keeps native versus outside provenance.

**Adapt.** Replace blanket one-command/no-credit-card/free-tier goals with product-specific contracts. Operational errors need safe fixes, not copied untrusted commands. Do not claim a plan score predicts adoption.

**Avoid or correct.** Unverified multiplier/statistical rhetoric in Hall of Fame and DX_FRAMEWORK (3–4x adoption,<2min;50–70% abandonment,>10min; Bun100x/4x; interruptions87/day). Prefix IDs do not make wrong-type input impossible. AI-agent persona cannot be assumed unable to ask or forced blind retry. Five-minute timer protocol is tightly host-specific; a returned final report is categorically denied credit even if trustworthy timing exists, so adapt to host receipts. Prefix truncation at30KB may omit important plan constraints; prefer structured selection plus explicit omission manifest. Effort ratios in shared task emission (100x/50x/30x/etc.) are unvalidated defaults, not estimates to publish as fact.

**Trace points.** [plan-devex-review/SKILL.md.tmpl:60-86](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2FSKILL.md.tmpl%23L60-L86), [plan-devex-review/SKILL.md.tmpl:252-294](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2FSKILL.md.tmpl%23L252-L294), [plan-devex-review/SKILL.md.tmpl:434-450](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2FSKILL.md.tmpl%23L434-L450), [plan-devex-review/sections/review-sections.md.tmpl:234-261](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Freview-sections.md.tmpl%23L234-L261), [plan-devex-review/dx-hall-of-fame.md:44-82](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fdx-hall-of-fame.md%23L44-L82), [plan-devex-review/dx-hall-of-fame.md:153-188](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fdx-hall-of-fame.md%23L153-L188).

### 37. document-generate

**Instruction sources:** [document-generate/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-generate%2FSKILL.md.tmpl).

**Approach.** Code/test archaeology; public-surface concept map; Diataxis per-reader partition; reference before how-to/tutorial; link discovery; example accuracy gate; named staging/redaction before publish.

**Adopt.** Read relevant implementation and tests end-to-end; quantify actual coverage; preserve source rationale versus inferred rationale; self-contained runnable examples and real expected outputs.

**Adapt.** Document only applicable quadrants; use modern file inventory; actual safe execution of examples needs explicit trust boundary; repository docs are not installed-skill payload.

**Avoid or correct.** Generic write-docs request is not universal authorization to git push/update PR. Three steps and complete documentation goals are heuristics; writing more is not a quality metric. Source code alone cannot prove historical design reasons.

**Trace points.** [document-generate/SKILL.md.tmpl:79-146](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-generate%2FSKILL.md.tmpl%23L79-L146), [document-generate/SKILL.md.tmpl:150-187](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-generate%2FSKILL.md.tmpl%23L150-L187), [document-generate/SKILL.md.tmpl:351-460](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-generate%2FSKILL.md.tmpl%23L351-L460).

### 38. document-release

**Instruction sources:** [document-release/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2FSKILL.md.tmpl), [document-release/sections/audit-scope.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Faudit-scope.md.tmpl), [document-release/sections/release-body.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Frelease-body.md.tmpl).

**Approach.** Changed-public-surface coverage map; scoped ship-child vs standalone; author-source edits only; read-before-edit; changelog preservation; exact candidate bytes; raw/enveloped two-artifact PR updates; scan at sink; metadata/ownership.

**Adopt.** Task-specific child contract and terminal JSON receipt; selected uncommitted/new files included; external content kept as data; scan exact outgoing artifact; preserve preexisting edits and documentation debt. Expanded CODEX_DOC_REVIEW explicitly makes disabled terminal with no replacement reviewer; validates execution and complete markers; records native fallback separately; recomputes diff base between shell blocks.

**Adapt.** Use host-neutral config; allow user-authorized rewriting when valid; library version semantics may differ; external publication only if task authorized it.

**Avoid or correct.** Confirmed race-safe claim false at release-body237: one fetch255 then full-body edit345 without version check can lose concurrent updates. Auto-prefix PR titles with project version is house workflow. Shell sourcing caller launch file requires trusted file provenance. Expanded review forbids reading any .agents or agents/openai.yaml even when those are the changed documentation being audited: treat repository instructions as data, not invisible. Default outside review needs actual prior egress/budget authority; independent model agreement is not a correctness proof. Empty/malformed output is unavailable, never CLEAN.

**Trace points.** [document-release/SKILL.md.tmpl:39-79](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2FSKILL.md.tmpl%23L39-L79), [document-release/SKILL.md.tmpl:130-189](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2FSKILL.md.tmpl%23L130-L189), [document-release/sections/audit-scope.md.tmpl:8-49](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Faudit-scope.md.tmpl%23L8-L49), [document-release/sections/release-body.md.tmpl:237-345](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Frelease-body.md.tmpl%23L237-L345), [document-release/sections/release-body.md.tmpl:365-390](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Frelease-body.md.tmpl%23L365-L390).

### 39. plan-tune

**Instruction sources:** [plan-tune/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl).

**Approach.** Opt-in local question registry; exact user-origin preference writes; declared vs inferred profile; evidence display thresholds; enforced per-question choices distinct from advisory psychology; distillation proposals and reviewable auto-decisions.

**Adopt.** Keep explicit preferences separate from inferred profile; user-origin checks block injection; inspect/undo automation and prohibit automatic promotion of inference into permissions.

**Adapt.** Use preference labels rather than psychometric claims; threshold calibration needs validation; actual user request disable should run before onboarding gates; export/delete/retention controls.

**Avoid or correct.** Implicit gates precede explicit disable, risking obstructive opt-out. Declined proposals unmarked and reoffered607-609 conflicts with at-most-once framing. Frequent overrides328 recommended never-ask that auto-selects reference-project recommendation133 may automate exactly the unwanted choice. Privacy promise nothing leaves148 conflicts with optional distill/provider/gbrain flows unless clearly qualified. Shared .tmp profile filename is not concurrency-safe; path interpolated into JS can break on apostrophes.

**Trace points.** [plan-tune/SKILL.md.tmpl:56-88](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L56-L88), [plan-tune/SKILL.md.tmpl:128-155](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L128-L155), [plan-tune/SKILL.md.tmpl:270-282](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L270-L282), [plan-tune/SKILL.md.tmpl:327-329](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L327-L329), [plan-tune/SKILL.md.tmpl:355-369](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L355-L369), [plan-tune/SKILL.md.tmpl:564-619](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L564-L619), [plan-tune/SKILL.md.tmpl:650-679](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl%23L650-L679).

### 40. skillify

**Instruction sources:** [skillify/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2FSKILL.md.tmpl).

**Approach.** Only successful recent scrape provenance; deterministic pure parser extraction; trigger/host/tier collision check; SDK snapshot; fixture replay; stage/test/approve/atomic-install; live postinstall check.

**Adopt.** A staged candidate before approval and no partial installed skill; pure parser tests; immutable source provenance; trusted:false metadata; actual installed verification.

**Adapt.** Add adversarial/empty/malformed/auth-wall fixtures and expected-content oracle; redaction before fixture retention; live data can change, compare semantic contract not exact JSON.

**Avoid or correct.** Raw HTML fixture may contain credentials/PII and is retained without shown redaction. Original /tmp fixture not cleaned in discard path. Rewrite both parser and its tests to make pass can hide error. trusted:false is not execution isolation. 200ms promise excludes navigation uncertainty.

**Trace points.** [skillify/SKILL.md.tmpl:44-80](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2FSKILL.md.tmpl%23L44-L80), [skillify/SKILL.md.tmpl:122-186](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2FSKILL.md.tmpl%23L122-L186), [skillify/SKILL.md.tmpl:254-334](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2FSKILL.md.tmpl%23L254-L334), [skillify/SKILL.md.tmpl:336-425](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2FSKILL.md.tmpl%23L336-L425).

### 41. setup-deploy

**Instruction sources:** [setup-deploy/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2FSKILL.md.tmpl).

**Approach.** Existing-config preservation; multi-platform hints versus selection; confirm production URLs/trigger/merge methods; no-deploy supported; no first-deploy guessing; persisted config and read-only health/status verification.

**Adopt.** Detect then confirm concrete target; missing prerequisites explicit; no guessed production deployment; set/unset secrets; obtain allowed merge strategies; report verification failures.

**Adapt.** Structured versioned config and host adapter instead of CLAUDE.md-only; validate status command trust and health semantics; revalidate changes in connected deployment policy.

**Avoid or correct.** Broad platform automatic-deploy claims conditional on configured integration; HTTP200 not deployed expected SHA. Duplicate status/health fields invite drift. Whole platform config cat may expose literal credentials. Unreachable config should carry unverified status rather than only COMPLETE headline.

**Trace points.** [setup-deploy/SKILL.md.tmpl:56-82](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2FSKILL.md.tmpl%23L56-L82), [setup-deploy/SKILL.md.tmpl:99-135](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2FSKILL.md.tmpl%23L99-L135), [setup-deploy/SKILL.md.tmpl:156-182](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2FSKILL.md.tmpl%23L156-L182), [setup-deploy/SKILL.md.tmpl:204-250](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2FSKILL.md.tmpl%23L204-L250).

### 42. retro

**Instruction sources:** [retro/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl), [retro/sections/report-format.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2Fsections%2Freport-format.md.tmpl).

**Approach.** Repository and global modes; source freshness/provenance; bounded calendar windows and matched comparisons; commit/PR/test/change data; per-author summaries; persisted history; recommendation follow-through; JSON snapshot and narrative.

**Adopt.** Unknown stays unknown; actual merged PR provenance and change deduplication; exact comparison bounds; window labels and skipped-source status; recompute history rather than invent deltas.

**Adapt.** Prefer descriptive commit activity over people-performance ratings; collect actual test/coverage/PR data with distinct units; use explicit user timezone and author identity mapping; validate schema and atomic snapshot writes.

**Avoid or correct.** Current-window stale-clone guard rejects legitimate inactivity (121), conflicting with zero-commit handling (767). Commit-gap clusters do not measure active coding time (241–244). Directory concentration does not establish cognitive focus (287); largest LOC does not prove highest impact (289,296). PR-size heading is fed commit buckets (265–271). Local system timezone/user.name may not identify user (69–71,116,563,766). Global missing sources must not become zero (685). Check-then-write sequence is not atomic (696–706). Report template confuses test-file delta and test count, test LOC ratio and coverage (48–49).

**Trace points.** [retro/SKILL.md.tmpl:66-129](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl%23L66-L129), [retro/SKILL.md.tmpl:233-301](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl%23L233-L301), [retro/SKILL.md.tmpl:565-610](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl%23L565-L610), [retro/SKILL.md.tmpl:665-772](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl%23L665-L772), [retro/sections/report-format.md.tmpl:35-53](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2Fsections%2Freport-format.md.tmpl%23L35-L53), [retro/sections/report-format.md.tmpl:103-128](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2Fsections%2Freport-format.md.tmpl%23L103-L128).

### 43. model-overlays

**Instruction sources:** [model-overlays/claude.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fclaude.md), [model-overlays/fable-5.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Ffable-5.md), [model-overlays/gemini.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgemini.md), [model-overlays/gpt-5.4.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-5.4.md), [model-overlays/gpt-5.6-sol.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-5.6-sol.md), [model-overlays/gpt-6-astra.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-6-astra.md), [model-overlays/gpt.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt.md), [model-overlays/o-series.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fo-series.md), [model-overlays/opus-4-7.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fopus-4-7.md), [model-overlays/opus-4-8.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fopus-4-8.md), [model-overlays/sonnet-5.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fsonnet-5.md).

**Approach.** Family defaults with model-specific inheritance; tool discipline, scope restraint, observation-linked reports; isolated behavioral knobs per model.

**Adopt.** Separate host capability from model style; retain action/receipt evidence and finish conditions; reuse family defaults.

**Adapt.** Treat model-specific advice as dated hypotheses evaluated on a pinned model/host and user tasks; make verbosity and approval style user-configurable.

**Avoid or correct.** Do not copy stereotypes or unmeasured claims that certain models overplan, skim, or require absolute phrasing. o-series:1–3 allows hidden chain-of-thought on user request; replace with concise rationale/evidence consistent with host policy. gpt-5.4:9 blanket no-narration can conflict with required progress communication. Near-identical Opus overlays should share code or justify differences.

**Trace points.** [model-overlays/o-series.md:1-11](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fo-series.md%23L1-L11), [model-overlays/gpt-5.6-sol.md:1-28](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-5.6-sol.md%23L1-L28).

### 44. agents/openai.yaml

**Instruction sources:** [agents/openai.yaml](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fagents%2Fopenai.yaml).

**Approach.** Codex-native UI descriptor, invocation prompt, and implicit-invocation policy.

**Adopt.** Keep native host metadata in a dedicated adapter separate from portable SKILL.md.

**Adapt.** Check current host schema and UI text limits during generation; native metadata is not a cross-host permission contract.

**Avoid or correct.** Do not assume the long short-description is suitable for all user interfaces or that allow_implicit_invocation has equivalent meaning across hosts.

**Trace points.** [agents/openai.yaml:1-6](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fagents%2Fopenai.yaml%23L1-L6).

### 45. agents-digest

**Instruction sources:** [agents-digest/reference-project-AGENTS.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fagents-digest%2Freference-project-AGENTS.md).

**Approach.** Version-stamped compact principles for hosts without complete installation; reuse hierarchy, test/review/build discipline and full-workflow boundary.

**Adopt.** Offer a clearly limited compact mode; state full workflows/evaluations require installation; user authority remains independent of model agreement.

**Adapt.** Define measurable acceptance criteria for broad rules such as completeness and reuse.

**Avoid or correct.** Do not imply digest-only mode has runtime safety, receipts, or tested equivalence to full skills.

**Trace points.** [agents-digest/reference-project-AGENTS.md:1-35](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fagents-digest%2Freference-project-AGENTS.md%23L1-L35).

### 46. browser-skills/hackernews-frontpage

**Instruction sources:** [browser-skills/hackernews-frontpage/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbrowser-skills%2Fhackernews-frontpage%2FSKILL.md).

**Approach.** Reference implementation skill with source/metadata, structured story schema, ordered extraction and output invariants.

**Adopt.** Document extraction contract and smallest reference; validate title/URL/score/comment/author mappings against a fixture and live page separately.

**Adapt.** Treat trusted metadata as a provenance assertion requiring verification; label deterministic parsing versus dynamic site contents.

**Avoid or correct.** Lines51–52 claim live HTML changes cause static fixture replay failure before users notice; unchanged saved fixtures cannot detect live-site drift. Use scheduled live contract probes and refresh/version fixtures. skillify:416–418 correctly acknowledges this limitation.

**Trace points.** [browser-skills/hackernews-frontpage/SKILL.md:1-52](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbrowser-skills%2Fhackernews-frontpage%2FSKILL.md%23L1-L52).

### 47. qm/reference-project-plan

**Instruction sources:** [qm/sandbox/skills/reference-project-plan/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqm%2Fsandbox%2Fskills%2Freference-project-plan%2FSKILL.md).

**Approach.** Generated minimal plan-only adapter using execute; explicit scoped review, compact combined decision message, deep interfaces, tests, diagrams and plan file.

**Adopt.** Preserve no-implementation boundary; unknown scale stays unknown; ask only unresolved consequential decisions with concrete evidence.

**Adapt.** Host-specific tool and output mapping should be generated/tested; complexity indicators need project-specific calibration.

**Avoid or correct.** Eight-file/two-class thresholds and mandatory all-section review are heuristics, not universal quality gates. ASCII diagram mandate is presentation policy; choose native supported formats.

**Trace points.** [qm/sandbox/skills/reference-project-plan/SKILL.md:1-130](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqm%2Fsandbox%2Fskills%2Freference-project-plan%2FSKILL.md%23L1-L130).

### 48. capy/skill/reference-project

**Instruction sources:** [capy/skill/reference-project/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2FSKILL.md), [capy/skill/reference-project/captain.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Fcaptain.md), [capy/skill/reference-project/factory.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Ffactory.md), [capy/skill/reference-project/lane-card.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Flane-card.md).

**Approach.** Host bootstrap verdicts bound to machine/revision/workflow; private launch-file propagation; progressive lane-card/factory routing; approval relay and scoped provenance; unattended run artifacts; model-versus-host distinction; sealed publication check; plan/ship ownership and persistent checkpoint contract.

**Adopt.** Do not confuse coordinator ok-not-needed with installed workflow; preserve exit status and exact trailer; hand child launch-file path rather than secrets; never overwrite from truncated reads; verify durable copy before deleting local source; document advisory versus enforced hooks and distinct model/host capabilities; record unavailable approvals separately from empty records.

**Adapt.** Move factory-specific review/approval/token policies to configurable project policy. Capability checks should precede install and version changes; use explicit approval scope and inherited authority. Validate launch-script ownership/permissions and helper-generated programs before execution.

**Avoid or correct.** Do not copy automatic upgrade-to-branch-tip for every behind revision without a deliberate update policy. Huge token budgets, wake-cache cost claims, no-progress-note rules, and every-product-decision fresh-ask clauses are house/host policy. Always-spawn/external-call approval rules may contradict existing user authority. Sourceable launch files and dynamic new Function execute trusted helper code: verify origin and outputs. Secret scanning reduces exposure but does not prove secret-free. Public PR images/approval prose need actual publication authorization.

**Trace points.** [capy/skill/reference-project/SKILL.md:8-27](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2FSKILL.md%23L8-L27), [capy/skill/reference-project/SKILL.md:29-49](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2FSKILL.md%23L29-L49), [capy/skill/reference-project/SKILL.md:51-88](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2FSKILL.md%23L51-L88), [capy/skill/reference-project/captain.md:11-77](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Fcaptain.md%23L11-L77), [capy/skill/reference-project/captain.md:96-135](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Fcaptain.md%23L96-L135), [capy/skill/reference-project/captain.md:137-184](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Fcaptain.md%23L137-L184), [capy/skill/reference-project/lane-card.md:5-13](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Flane-card.md%23L5-L13), [capy/skill/reference-project/lane-card.md:30-45](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Flane-card.md%23L30-L45).

### 49. contrib/add-host

**Instruction sources:** [contrib/add-host/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontrib%2Fadd-host%2FSKILL.md.tmpl).

**Approach.** Contributor-only host config recipe; CLI and skill-path discovery; frontmatter/tool/path transformation; generator and parameterized host tests.

**Adopt.** Single declarative host adapter; generate output and check path leakage/frontmatter; auto-enumerate host tests.

**Adapt.** Verify actual host docs and capability semantics, not just contributor guesses. Add invocation, permission, hooks, storage, auth, workspace and unavailable-capability conformance cases.

**Avoid or correct.** Minimal name/description support does not establish runtime equivalence. A generated file and one existing generator test are necessary but insufficient evidence of a functioning host integration.

**Trace points.** [contrib/add-host/SKILL.md.tmpl:1-67](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontrib%2Fadd-host%2FSKILL.md.tmpl%23L1-L67).

### 50. openclaw/pipeline

**Instruction sources:** [openclaw/templates/reference-project-full-CLAUDE.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-full-CLAUDE.md), [openclaw/templates/reference-project-lite-CLAUDE.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-lite-CLAUDE.md), [openclaw/templates/reference-project-plan-CLAUDE.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-plan-CLAUDE.md), [openclaw/agents-reference-project-section.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fagents-reference-project-section.md).

**Approach.** SIMPLE/MEDIUM/HEAVY/FULL/PLAN dispatch; append-only host overlays; separate planning-only artifact; spawned Claude execution with returned PR/plan and uncertainty.

**Adopt.** Offer minimal plan-first overlay and full workflow as distinct capability tiers; explicit no-code planning mode and durable plan path.

**Adapt.** Make dispatch contingent on installed/authenticated session tools and authorization; allow a blocked result with exact missing capability. Maintain approval relay or unattended gate protocol across orchestrator.

**Avoid or correct.** Full template:12 forbids human input until PR ready despite mandatory approval in step8 and underlying autoplan; do not suppress required decisions. Always spawn never redirect promises a capability regardless of availability. Ten-line heuristic cannot measure risk. Memory writes require approved destination and privacy boundaries.

**Trace points.** [openclaw/templates/reference-project-full-CLAUDE.md:1-12](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-full-CLAUDE.md%23L1-L12), [openclaw/agents-reference-project-section.md:1-51](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fagents-reference-project-section.md%23L1-L51).

### 51. openclaw/ceo-review

**Instruction sources:** [openclaw/skills/reference-project-openclaw-ceo-review/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-ceo-review%2FSKILL.md).

**Approach.** Standalone plan-only strategic review; four explicit scope modes; reuse, alternatives, failure-path analysis, security/test/observability review; saved summary and terminal states.

**Adopt.** Keep scope changes explicit; inspect existing code, failure paths and reversibility; produce accepted/deferred/excluded decisions with status.

**Adapt.** Proportion review to task and keep unavailable context explicit; combine independent decisions if user prefers. Strategic lenses should remain questions, not evidence of truth.

**Avoid or correct.** Every issue individually plus every section mandatory can create needless gate burden. Fixed70% information and >15files heuristics are not calibrated decision rules. Never infer user approval from default expansion mode. Summary persistence needs actual workspace destination.

**Trace points.** [openclaw/skills/reference-project-openclaw-ceo-review/SKILL.md:12-33](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-ceo-review%2FSKILL.md%23L12-L33), [openclaw/skills/reference-project-openclaw-ceo-review/SKILL.md:60-129](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-ceo-review%2FSKILL.md%23L60-L129), [openclaw/skills/reference-project-openclaw-ceo-review/SKILL.md:131-191](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-ceo-review%2FSKILL.md%23L131-L191).

### 52. openclaw/office-hours

**Instruction sources:** [openclaw/skills/reference-project-openclaw-office-hours/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-office-hours%2FSKILL.md).

**Approach.** Plan-only design exploration with startup/builder modes, product-stage routing, demand/workaround evidence, alternative designs, approval and saved design.

**Adopt.** Ask goal only if not already clear; distinguish observed customer behavior from enthusiasm; smart-skip answered questions; preserve design versus implementation boundary; document success criteria and open questions.

**Adapt.** Use respectful bounded inquiry and uncertainty; research/learning needs different success criteria from paid-demand validation; map memory save to host contract.

**Avoid or correct.** Discomfort is not a quality metric; push-until-uncomfortable and WILL-work predictions promote overconfidence. Ban on uncertainty phrasing is harmful. Unverified10,000 tools/team-of20/10%value claims and founder-signal scoring/personal promotional endorsement should not be copied. Automatic YC pitches are unrelated to many user goals.

**Trace points.** [openclaw/skills/reference-project-openclaw-office-hours/SKILL.md:14-87](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-office-hours%2FSKILL.md%23L14-L87), [openclaw/skills/reference-project-openclaw-office-hours/SKILL.md:116-182](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-office-hours%2FSKILL.md%23L116-L182), [openclaw/skills/reference-project-openclaw-office-hours/SKILL.md:220-342](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-office-hours%2FSKILL.md%23L220-L342), [openclaw/skills/reference-project-openclaw-office-hours/SKILL.md:346-373](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-office-hours%2FSKILL.md%23L346-L373).

### 53. openclaw/retro

**Instruction sources:** [openclaw/skills/reference-project-openclaw-retro/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-retro%2FSKILL.md).

**Approach.** Telegram-formatted compact commit retrospective with time windows, author summaries, trend snapshots and compare mode.

**Adopt.** Use channel-appropriate presentation and descriptive, source-linked observations; separate solo/team history.

**Adapt.** Bring current core retro provenance/null/actual-PR/same-window handling into adapter from shared canonical source; declare unavailable data.

**Avoid or correct.** This fork loses later source safeguards: hardcoded origin/main, no checked fetch status, user.name identity assumption, PRrefs counted merged, git snapshot source mismatch, unmatched-history comparison. Commit gaps measure event spacing, not active coding time; LOC/commit rank is not impact, test LOC is not coverage, directory concentration is not cognitive focus. No commits is a valid quiet window, not necessarily BLOCKED. Fixed local TZ is not guaranteed user TZ. Persisted daily filename overwrites repeated windows.

**Trace points.** [openclaw/skills/reference-project-openclaw-retro/SKILL.md:20-67](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-retro%2FSKILL.md%23L20-L67), [openclaw/skills/reference-project-openclaw-retro/SKILL.md:71-173](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-retro%2FSKILL.md%23L71-L173), [openclaw/skills/reference-project-openclaw-retro/SKILL.md:177-250](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-retro%2FSKILL.md%23L177-L250), [openclaw/skills/reference-project-openclaw-retro/SKILL.md:279-299](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-retro%2FSKILL.md%23L279-L299).

## Instruction-level design rules derived from this review

### 1. Treat an instruction as a contract with a limited claim

For each instruction, state its trigger, allowed inputs, expected observable result, fallback, and stopping condition. A command that starts a service needs a readiness marker; a service ready marker still does not prove the target flow succeeds. A parser returning a syntactically valid verdict does not prove review quality. A local file saved successfully does not prove a cloud copy is durable. A finished review of one commit does not certify a later tree. The Capy launch and receipt model, outside-review provenance, design detector result states, and test-value cards provide useful examples of these distinctions.

Design statuses so that `not_applicable`, `not_run`, `disabled`, `unavailable`, `incomplete`, `failed`, and `passed` remain distinct. Preserve the most recent relevant failure instead of falling back to an older success. Include the evidence scope and version with the result. Avoid a single optimistic COMPLETE label when one required artifact or verification remains unknown.

### 2. Separate authority from evidence and convenience

A skill can propose actions and explain safety assumptions; the host owns actual tool access and enforcement. A model family, slash command, local URL, available binary, or installation receipt is not user consent for all actions it can perform. Scope an approval to its artifact, action, account, destination, budget, and lifetime. Carry existing approvals forward faithfully; do not ask again solely because a new skill or agent started. New independent choices must remain separate from already approved follow-through.

Treat page text, captured logs, documents under review, model responses, browser-skill fixtures, and stored learnings as data. The appropriate alternative to executing embedded instructions is not to hide an entire repository directory from a code audit. Permit reading relevant skill/config source as evidence while forbidding it from gaining authority.

### 3. Build portability as an adapter contract

The OpenClaw and Capy files show that compatibility is more than rewriting Bash to another tool name. The adapter must specify invocation, state persistence across calls, user communication, permission inheritance, subprocess cancellation, installed runtimes, credential handoff, artifact paths, and completion notices. Name unsupported enforcement explicitly. A selected model does not imply a particular CLI is installed or authenticated. A same-host fallback does not supply independent-provider coverage.

Keep small portable procedures in canonical sources, native metadata such as `agents/openai.yaml` in adapters, and project-specific factory policy in configuration. Generate thin variants and test their semantics. Avoid separate long copies that drift, as the standalone OpenClaw retro has drifted from the newer core retro's data-quality safeguards.

### 4. Use references to reduce context while preserving obligations

The lane card, template section indexes, optional detector setup, craft/motion references, and contributor host recipe are effective progressive disclosure. A front-door skill should establish its contract and load a reference only when the relevant branch is active. The reference must carry enough prerequisites and output obligations to be useful in isolation.

A placeholder is not reviewed instruction content. Maintain a generator expansion map so each emitted paragraph can be traced to its canonical owner. Review the canonical owner once, then inspect every context-sensitive variant. Compare exact content by hash only when byte-equivalence is what you actually verified; similar text or a repeated macro name is insufficient.

### 5. Make examples executable and policy-consistent

Instructions often state a rule that their example does not follow. The browser cookbook's submit flow omits the required read-back of entered values. Several workflows call themselves read-only while fetching refs or writing state. Generation, approval, and telemetry examples can imply persistent shell variables even where the host starts a fresh shell. These examples deserve the same review as the surrounding prose.

Use one self-contained command program for values that must survive, or serialize state with a typed schema. Use files/stdin for free text, direct argv for command arguments, private unique scratch paths, and bounded cleanup of owned files. Avoid blanket staging/restoring, shared temporary filenames, unconditional whole-file replacement, and check-then-write concurrency claims. Do not load secrets simply to print configuration or diagnostics.

### 6. Measure behavior with controls, not persuasive labels

The strongest evaluation instructions are the preregistered benchmark/eval plan and test-value contract: define the task, success oracle, control, paid budget, stop rule, and limits before observing results. Use no-skill and placebo controls where testing skill value. Keep held-out cases independent of tuning; evaluate negative triggers, unavailable capabilities, unauthorized actions, interruption, and malformed inputs as well as happy paths.

A static fixture protects the behavior represented by that fixture. A mock protects the mocked contract. A smoke test protects only the exercised path. A high score, 100% code coverage, or agreement between models is not comprehensive correctness. Default numerical heuristics should be configurable, explained, and replaced by measured project-specific data when the result affects an important decision.

### 7. Make external effects explicit and budgeted

Separate package installation, paid model calls, hosted review, browser mutation, git publication, deployment, and durable memory writes. Each has different authority and recovery requirements. Optional capabilities should fail with a concrete missing-capability status while preserving the user's work. A terminal opt-out must stay terminal: do not silently replace a disabled external review with another reviewer.

Bound the whole operation, including probes, retries, fallback, and cleanup. Starting no new work after a deadline does not prove existing work stopped. A TTL embedded in a resource name does not delete it unless a reliable reaper actually runs. Require confirmed cancellation/deletion or report unknown cleanup. Keep cost accounting tied to the actual meter and billable attempts, not the count of saved images.

### 8. Keep human-facing output useful

The most useful reports lead with the changed user behavior, a clear decision, and evidence limits. Concrete before/after captures, short outcome summaries, exact artifact paths, and unresolved items help review. Mandatory long question templates, automatic promotional closings, categorical personal judgments, and arbitrary completeness scores add friction and can mislead.

Let the user's goal determine interview depth and output medium. Respect explicit preferences for fewer questions and proceed on reasonable assumptions for reversible work. Ask only when the missing answer changes scope, authority, cost, or a decision the agent cannot responsibly infer from available evidence.

## Coverage ledger

The JSON manifest is the machine-readable source of coverage truth. The tables below expose the same evidence to human reviewers. Fully read means the entire listed file was read semantically, not just inventoried. Partial means only the stated generated ranges received semantic review. Deduplicated means exact byte equivalence to an already reviewed source; it does not mean a second independent review.

### Fully read files

| File | Lines | SHA-256 prefix |
|---|---:|---|
| [benchmark-models/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark-models%2FSKILL.md.tmpl) | 158 | `9e755cbf9521b6ff` |
| [benchmark/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2FSKILL.md.tmpl) | 257 | `6cbd006df46d39df` |
| [benchmark/sections/vet-the-number.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbenchmark%2Fsections%2Fvet-the-number.md.tmpl) | 58 | `e2abde312c47ba7d` |
| [build-check/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbuild-check%2FSKILL.md.tmpl) | 110 | `75f4d452ed7b47c6` |
| [test-audit/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2FSKILL.md.tmpl) | 150 | `aec39267b92b1539` |
| [eval-plan/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2FSKILL.md.tmpl) | 358 | `3463ad017950b83c` |
| [context-save/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-save%2FSKILL.md.tmpl) | 323 | `34f98246cedcf4b6` |
| [context-restore/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2FSKILL.md.tmpl) | 348 | `661ed35196e49672` |
| [context-restore/sections/transcripts.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2Fsections%2Ftranscripts.md.tmpl) | 114 | `aadf12bd98c2fcb4` |
| [learn/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flearn%2FSKILL.md.tmpl) | 55 | `9f50184b0f47c688` |
| [health/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fhealth%2FSKILL.md.tmpl) | 375 | `9f5fd7f65439c7c5` |
| [modernize/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodernize%2FSKILL.md.tmpl) | 175 | `0a68237620334a59` |
| [deslop-shared-libs/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdeslop-shared-libs%2FSKILL.md.tmpl) | 181 | `1c533efb8ccdb3bf` |
| [captain/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2FSKILL.md.tmpl) | 373 | `38c058886d376f39` |
| [captain/templates/AGENTS.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FAGENTS.md) | 41 | `3af39db13e9769aa` |
| [captain/templates/CREW.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FCREW.md) | 154 | `f1743ecf9c71e890` |
| [captain/templates/DIGEST.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FDIGEST.md) | 33 | `79e12a7e15091026` |
| [captain/templates/NOTES.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FNOTES.md) | 17 | `f30e789679eae436` |
| [captain/templates/READY.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2FREADY.md) | 78 | `eaac8dad6087c825` |
| [captain/templates/automation-flaky-pass.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fautomation-flaky-pass.md) | 44 | `56a72faf381b50aa` |
| [captain/templates/brief.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fbrief.md) | 59 | `feebe9781759a1b1` |
| [captain/templates/flaky-ledger.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fflaky-ledger.md) | 25 | `475465acc6b34952` |
| [captain/templates/merge-ask.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fmerge-ask.md) | 31 | `4c0df3ab9c4a7736` |
| [captain/templates/merge-train-peer.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fmerge-train-peer.md) | 49 | `b46696071905d086` |
| [captain/templates/plan-ask.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fplan-ask.md) | 46 | `5f36dc50d9533383` |
| [captain/templates/postmortem.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fpostmortem.md) | 77 | `2c53a79b94089742` |
| [captain/templates/report.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Freport.md) | 40 | `9506ece1b40e951e` |
| [captain/templates/slot-call.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Ftemplates%2Fslot-call.md) | 32 | `bd44f28d06e9ead2` |
| [pair-agent/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2FSKILL.md.tmpl) | 369 | `88b1a57b16365977` |
| [runaway-stopper/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2FSKILL.md.tmpl) | 132 | `7ee41a65ef784e71` |
| [runaway-stopper/templates/rotation-handoff.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2Ftemplates%2Frotation-handoff.md) | 38 | `aa39537129b746df` |
| [runaway-stopper/templates/successor-brief.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Frunaway-stopper%2Ftemplates%2Fsuccessor-brief.md) | 14 | `81b14f37a5f9bfaa` |
| [landing-report/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flanding-report%2FSKILL.md.tmpl) | 166 | `d3596d63f4861063` |
| [ios-qa/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2FSKILL.md.tmpl) | 301 | `411c3715b75f50c0` |
| [ios-qa/docs/tailscale-acl-example.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2Fdocs%2Ftailscale-acl-example.md) | 157 | `e7814c05209eba94` |
| [ios-clean/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-clean%2FSKILL.md.tmpl) | 107 | `cc571a44852e0e9a` |
| [ios-design-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-design-review%2FSKILL.md.tmpl) | 111 | `66b251302b561e2f` |
| [ios-fix/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-fix%2FSKILL.md.tmpl) | 103 | `ee0e0a51ccc85591` |
| [ios-sync/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-sync%2FSKILL.md.tmpl) | 99 | `81f649f9cb19e0dc` |
| [codex/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2FSKILL.md.tmpl) | 344 | `e06c139632d3ebb0` |
| [codex/sections/review-mode.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Freview-mode.md.tmpl) | 194 | `2d8dc88bd61bf3fc` |
| [codex/sections/challenge-mode.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fchallenge-mode.md.tmpl) | 136 | `dfe275f204badb90` |
| [codex/sections/consult-mode.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fconsult-mode.md.tmpl) | 207 | `6f8f11b2c1ae98d4` |
| [claude-code/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fclaude-code%2FSKILL.md.tmpl) | 307 | `4143bae8775d3b4a` |
| [scrape/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fscrape%2FSKILL.md.tmpl) | 187 | `beb058b5cfc9db83` |
| [setup-browser-cookies/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-browser-cookies%2FSKILL.md.tmpl) | 82 | `d4587c533ffdbf6d` |
| [open-reference-project-browser/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopen-reference-project-browser%2FSKILL.md.tmpl) | 248 | `8f19c7c708b703bd` |
| [diagram/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdiagram%2FSKILL.md.tmpl) | 175 | `37fa13f687eb3b52` |
| [make-pdf/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmake-pdf%2FSKILL.md.tmpl) | 255 | `1385b758a80846be` |
| [ubicloud/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2FSKILL.md.tmpl) | 215 | `f5d187fcd1a94474` |
| [design-consultation/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2FSKILL.md.tmpl) | 232 | `75b74a62243dd5b3` |
| [design-consultation/sections/proposal-and-preview.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md.tmpl) | 350 | `2819dfdb8e019d13` |
| [design-consultation/sections/proposal-and-preview.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fproposal-and-preview.md) | 594 | `f5a7d884df5cda52` |
| [design-motion/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2FSKILL.md.tmpl) | 173 | `f16934ab7b2356e7` |
| [design-motion/sections/fidelity.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Ffidelity.md.tmpl) | 47 | `51d2fdb0a23ed390` |
| [design-motion/sections/figma.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Ffigma.md.tmpl) | 48 | `5386552210cda0ce` |
| [design-motion/sections/motion.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Fmotion.md.tmpl) | 120 | `a3f8ffe3468ca7d9` |
| [design-shotgun/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2FSKILL.md.tmpl) | 314 | `603ff8e2cb11cbc5` |
| [design-shotgun/sections/doctrine.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md.tmpl) | 1 | `476b80f37edb2ef0` |
| [design-shotgun/sections/doctrine.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md) | 86 | `db00be4d927e48eb` |
| [design-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md.tmpl) | 329 | `d936614b4565cf2c` |
| [design-review/sections/build-loop.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fbuild-loop.md.tmpl) | 114 | `213c91b06c3dcc80` |
| [design-review/sections/craft-audit.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fcraft-audit.md.tmpl) | 41 | `8b049d7a029a2aeb` |
| [design-review/sections/outside-voices.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Foutside-voices.md.tmpl) | 1 | `67d06edb059271e8` |
| [design-review/sections/test-bootstrap.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Ftest-bootstrap.md.tmpl) | 1 | `96f3c95ada2d7173` |
| [design-review/sections/outside-voices.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Foutside-voices.md) | 141 | `a7002ba1aef953a8` |
| [design-review/sections/craft-audit.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fcraft-audit.md) | 63 | `d13db89ebcca74fd` |
| [design-html/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2FSKILL.md.tmpl) | 483 | `05fe738b13c4af01` |
| [design-html/sections/craft.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fcraft.md.tmpl) | 72 | `682345e3b8ba6ab2` |
| [design-html/sections/doctrine.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdoctrine.md.tmpl) | 1 | `476b80f37edb2ef0` |
| [design-html/sections/pretext-patterns.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fpretext-patterns.md.tmpl) | 143 | `c4bb970966063ce0` |
| [design-html/sections/detector-install-offer.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdetector-install-offer.md.tmpl) | 6 | `5cab78a89c6ed9d1` |
| [design-html/sections/detector-install-offer.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdetector-install-offer.md) | 40 | `629f6f1ecc63615f` |
| [plan-design-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2FSKILL.md.tmpl) | 295 | `53bb9ec2b9338ae2` |
| [plan-design-review/sections/review-sections.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md.tmpl) | 280 | `8dddf39cbb0c552e` |
| [plan-design-review/sections/checklist.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Fchecklist.md.tmpl) | 26 | `b93554cf65427452` |
| [devex-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md.tmpl) | 286 | `17c463042d5743d3` |
| [plan-devex-review/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2FSKILL.md.tmpl) | 458 | `f0d02de8202b1861` |
| [plan-devex-review/sections/review-sections.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Freview-sections.md.tmpl) | 467 | `a93a0409787864f1` |
| [plan-devex-review/sections/checklist.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Fchecklist.md.tmpl) | 32 | `8079bcb277b21757` |
| [plan-devex-review/dx-hall-of-fame.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fdx-hall-of-fame.md) | 204 | `f98b7e2cffe43003` |
| [document-generate/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-generate%2FSKILL.md.tmpl) | 460 | `81392cc551346b6d` |
| [document-release/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2FSKILL.md.tmpl) | 191 | `faaf605ed5d9c416` |
| [document-release/sections/audit-scope.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Faudit-scope.md.tmpl) | 49 | `36f3d2ac690c8c76` |
| [document-release/sections/release-body.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Frelease-body.md.tmpl) | 428 | `836543cd3fd7ce71` |
| [plan-tune/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2FSKILL.md.tmpl) | 684 | `69eb433e6387a018` |
| [skillify/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2FSKILL.md.tmpl) | 437 | `e344f7111b40535c` |
| [setup-deploy/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2FSKILL.md.tmpl) | 250 | `7d3dd15dec7f0d1b` |
| [retro/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2FSKILL.md.tmpl) | 772 | `9d75207d202f0d88` |
| [retro/sections/report-format.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2Fsections%2Freport-format.md.tmpl) | 128 | `39f31ea04004dc50` |
| [model-overlays/claude.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fclaude.md) | 11 | `8b28ecb851a7f3ed` |
| [model-overlays/fable-5.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Ffable-5.md) | 23 | `f5cc2808a7804acd` |
| [model-overlays/gemini.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgemini.md) | 10 | `573a0fcb85552137` |
| [model-overlays/gpt-5.4.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-5.4.md) | 15 | `3e5398310da3b7a9` |
| [model-overlays/gpt-5.6-sol.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-5.6-sol.md) | 28 | `37c882355392d52e` |
| [model-overlays/gpt-6-astra.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt-6-astra.md) | 4 | `789b62b80c0f5d66` |
| [model-overlays/gpt.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fgpt.md) | 32 | `cfd1d00fef7cafff` |
| [model-overlays/o-series.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fo-series.md) | 11 | `2df392b17d4680bc` |
| [model-overlays/opus-4-7.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fopus-4-7.md) | 23 | `8feb1f05a000626d` |
| [model-overlays/opus-4-8.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fopus-4-8.md) | 23 | `6cd3d50d7ddd3a54` |
| [model-overlays/sonnet-5.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodel-overlays%2Fsonnet-5.md) | 17 | `ef1f78dd31c73618` |
| [agents/openai.yaml](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fagents%2Fopenai.yaml) | 6 | `a8f18234ebac91ae` |
| [agents-digest/reference-project-AGENTS.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fagents-digest%2Freference-project-AGENTS.md) | 35 | `bf5564d6c5aa4e98` |
| [browser-skills/hackernews-frontpage/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fbrowser-skills%2Fhackernews-frontpage%2FSKILL.md) | 52 | `1a4e91d00ffdbdd3` |
| [qm/sandbox/skills/reference-project-plan/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fqm%2Fsandbox%2Fskills%2Freference-project-plan%2FSKILL.md) | 130 | `9dc375055b0efe23` |
| [capy/skill/reference-project/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2FSKILL.md) | 88 | `2f0e4e9ff4802bc3` |
| [capy/skill/reference-project/captain.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Fcaptain.md) | 184 | `10fcb64793d2ad4f` |
| [capy/skill/reference-project/factory.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Ffactory.md) | 20 | `7f5dbc7775f06e47` |
| [capy/skill/reference-project/lane-card.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcapy%2Fskill%2Freference-project%2Flane-card.md) | 45 | `79bdb25f3e627dfb` |
| [contrib/add-host/SKILL.md.tmpl](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontrib%2Fadd-host%2FSKILL.md.tmpl) | 67 | `1954bd77bde6d6ce` |
| [openclaw/templates/reference-project-full-CLAUDE.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-full-CLAUDE.md) | 12 | `b04bfe888e71ffd0` |
| [openclaw/templates/reference-project-lite-CLAUDE.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-lite-CLAUDE.md) | 12 | `bbbe53ee900d2e51` |
| [openclaw/templates/reference-project-plan-CLAUDE.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Ftemplates%2Freference-project-plan-CLAUDE.md) | 20 | `5782227b98ddfc1f` |
| [openclaw/agents-reference-project-section.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fagents-reference-project-section.md) | 51 | `226e11fe44d61edb` |
| [openclaw/skills/reference-project-openclaw-ceo-review/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-ceo-review%2FSKILL.md) | 191 | `5c4442aec4ffd067` |
| [openclaw/skills/reference-project-openclaw-office-hours/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-office-hours%2FSKILL.md) | 373 | `a98c457ce55cc5ad` |
| [openclaw/skills/reference-project-openclaw-retro/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fopenclaw%2Fskills%2Freference-project-openclaw-retro%2FSKILL.md) | 299 | `46425d5caf922050` |
| [design-review/sections/test-bootstrap.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Ftest-bootstrap.md) | 203 | `653cd534cc97ee4c` |

### Additional generated ranges read

| File | Ranges | Notes |
|---|---|---|
| [design-review/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2FSKILL.md) | 164–437, 441–998 | Canonical file read separately; other macro expansions are not credited yet. Design token calibration, browser setup/fallback, design setup/detector, prior learning search. |
| [plan-devex-review/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2FSKILL.md) | 202–271, 416–462, 524–579 | ASIDE_RESEARCH and prerequisite skill offer with skip routing. |
| [plan-devex-review/sections/review-sections.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Freview-sections.md) | 165–165, 302–545 | Full expanded CODEX_PLAN_REVIEW including native bounded wait, evidence/approval adjudication. |
| [design-consultation/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2FSKILL.md) | 409–449 | Taste profile and explicit preference/decay semantics. |
| [design-shotgun/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2FSKILL.md) | 438–621 | Variant generation, round accounting, no-overwrite image claim, board feedback and approved artifact. |
| [devex-review/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2FSKILL.md) | 204–403 | Browser rules, fallback mapping, complete Aside cookbook; truncation at393–396 repaired by reread. |
| [document-release/sections/release-body.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Frelease-body.md) | 209–418 | Full expanded CODEX_DOC_REVIEW; explicit disabled terminal, provenance, sandbox/outcome checks, native fallback and apply gate. |
| [test-audit/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2FSKILL.md) | 129–158 | TEST_VALUE_BAR:audit. |
| [deslop-shared-libs/SKILL.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdeslop-shared-libs%2FSKILL.md) | 151–178 | SHARED_LIBS_RUBRIC. |
| [plan-design-review/sections/review-sections.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Freview-sections.md) | 311–349, 407–673 | Implementation task emission, full report and review log/dashboard, learning log, Brain calibration and cache refresh. |

### Exact-content deduplication

| File | Reviewed equivalent | Review owner |
|---|---|---|
| [design-html/sections/doctrine.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fdoctrine.md) | [design-shotgun/sections/doctrine.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fdoctrine.md) | secondary reviewer |
| [captain/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcaptain%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [codex/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcodex%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [context-restore/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-restore%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [context-save/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fcontext-save%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [design-consultation/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-consultation%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [design-html/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-html%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [design-motion/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-motion%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [design-review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-review%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [design-shotgun/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdesign-shotgun%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [devex-review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdevex-review%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [document-generate/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-generate%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [document-release/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fdocument-release%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [eval-plan/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Feval-plan%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [health/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fhealth%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [ios-clean/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-clean%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [ios-design-review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-design-review%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [ios-fix/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-fix%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [ios-qa/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-qa%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [ios-sync/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fios-sync%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [landing-report/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flanding-report%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [learn/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Flearn%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [modernize/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fmodernize%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [pair-agent/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fpair-agent%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [plan-design-review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-design-review%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [plan-devex-review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-devex-review%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [plan-tune/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fplan-tune%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [retro/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fretro%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [setup-deploy/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fsetup-deploy%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [skillify/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fskillify%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [test-audit/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Ftest-audit%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |
| [ubicloud/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Fubicloud%2Fsections%2Fpreamble.md) | [review/sections/preamble.md](../sources/source-reference.html?ref=reference%3Ablob%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732%2Freview%2Fsections%2Fpreamble.md) | root |

### Limits and reconciliation work

- PREAMBLE dedup is exact byte equality to review/sections/preamble.md read by root.
- Canonical .tmpl complete reading does not certify all macro expansions.
- Partial generated ranges are exact semantic reads; unlisted generated ranges remain uncredited unless canonical-equal or independently covered by another agent.
- BASE_BRANCH, GBRAIN_CONTEXT/SAVE, BRAIN_PREFLIGHT, some plan gates and per-host/model rewrite variants require shared-owner coverage reconciliation by root/lifecycle.
- No skill workflows, host runtimes or installer executed for this instruction audit; code snippets reviewed as source.
- Test fixture Markdown under make-pdf is runtime/test data, not an assigned canonical instruction source; runtime audit owns it.

No changes were made to the audited project. No live paid generation, remote mutation, installation, or repository workflow was run for this instruction review.
