# Lifecycle entrypoints and user-data preservation

This matrix extends the preserved lifecycle audit with the supplied improvement report's F03. The source baseline is `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`. Package version is `1.102.2`; runtime `VERSION` contents are `1.102.2.0`. Source-relative identifiers use the reference-project alias. Original blob identities and full file hashes remain in the [file ledger](../catalogs/file-review.json).

## Evidence boundary

The original ledger is historical. The report adds targeted static reading of team initialization at lines 43–59 and 196–232 and the shared settings reader/writer at lines 492–553. It does not execute those helpers. Existing test source demonstrates that cases exist; it does not show that they ran in this task. Report artifact SHA-256: `f15d006ed7ab7f36b571362ec0a382a1e7cf9a034f3a3e49b55ce6dd578f2c63`.

## Entrypoint matrix

| Entrypoint / owner | Ownership and local edits | Missing or malformed settings | Backup and recovery | Evidence / remaining work |
|---|---|---|---|---|
| Main setup — `setup` | Inspected ownership paths protect foreign directories and edited owned copies. Other branches retain their recorded depth. | Settings may be delegated; identify each actual writer. | Backups for edited copies are observed; Unix live-checkout activation remains nontransactional. | [Lifecycle audit](lifecycle-project.md), `setup` lines 755–815, 883–952, 1938–1960. No runtime pass. |
| Team initialization — `bin/reference-project-team-init` | A nonsymlink directory with `VERSION` or `.git` is treated as vendored. Edited, untracked and local-only nested work is not checked before recursive removal in the inspected branch. | A catch-all read/parse failure falls back to an empty object; a writable malformed destination can be replaced. | No pre-removal preservation proof or configuration predecessor backup in the reported paths. | Report F03; lines 43–59 and 196–232. Two static findings below. |
| Shared settings editor — `bin/reference-project-settings-hook` | Settings identity, modes and changes are handled by a dedicated owner. This does not cover independent callers' writers. | Reported reader refuses unreadable or malformed existing JSON. | Preserves backups, file modes and change identity. | Report F03/G16; lines 492–553. Targeted static observation, no general proof over its 1,329 lines. |
| Upgrade — `reference-project-upgrade/SKILL.md.tmpl` and migration owners | Preserve local state and identify the actual mutation owner. Source/prompt migration ownership conflicts remain in the original audit. | Do not inherit setup's positive settings behavior without following the actual call. | Code rollback and state-schema rollback are separate. | [Lifecycle audit](lifecycle-project.md); existing migration findings remain open at the baseline. |
| Refresh / repair — `setup` registered-refresh routes | Registration and copied-file ownership narrow scope; inspect destination and local changes again. | Dependency fallback or repair must not silently mean that malformed settings are disposable. | Preserve old valid artifact and identify partial activation. | Existing targeted setup review; full refresh branch and concurrent mutation tests remain unexecuted. |
| State migrations — versioned migration files | One owner must record the source/target schema and completed steps. | Preserve missing/corrupt distinctions for every state format. | Success marker only after verified completion; recovery policy precedes mutation. | Existing full instruction reads do not establish all helper execution paths. |
| Rollback — settings helper and documented release procedures | Restore only identified owned changes; do not erase later unrelated edits. | Revalidate the selected predecessor before replacement. | Settings single-step backup restoration is distinct from full package/dependency/state rollback. | Source-specific claims only; complete rollback trials not run. |
| Uninstall — `bin/reference-project-uninstall` | Inspected path preserves nested repositories, tracked state and unsafe worktrees; force options have different effects. | Remove owned hooks, preserve unrelated configuration and chosen state. | Retention options and independent project-instruction cleanup must be visible. | [Lifecycle audit](lifecycle-project.md) and source `docs/uninstall.md`; no platform execution result. |

## F03-A: vendored migration can discard local work

**Classification:** static source concern; priority P1 before copying this migration mechanism. Owner: `bin/reference-project-team-init`, lines 43–59, blob `e1a152b1a44456978b6c6fa534dade35ca2cef38`.

The helper recognizes a nonsymlink directory by a `VERSION` file or `.git` directory, removes its cached Git entry, updates ignore rules and recursively removes the directory. This is an intentional migration operation. The concern is that this branch does not first establish project identity, check modified or untracked files, preserve local-only nested repository work, or produce a verified backup. If such material exists, deletion can discard it. No incident or execution is claimed.

An ownership-aware migration should verify the project's identity and inventory all material that would be removed. It should stop while preserving bytes when identity or local-work status is uncertain, or create a verified recoverable predecessor before an authorized migration. A generic version filename alone cannot prove ownership.

## F03-B: malformed settings can be replaced by new hook settings

**Classification:** static source concern; priority P1 before copying this settings writer. Owner: `bin/reference-project-team-init`, lines 196–232, same pinned blob.

The writer initializes an empty object and catches read and JSON parse failures. When the destination is still writable, newly generated settings can replace an existing malformed file. A missing file is a normal creation case; an existing unreadable or malformed file is a different state. Atomic rename avoids partial visibility of the replacement but cannot preserve the predecessor's meaning or bytes.

Use the same preservation-aware settings owner across setup, bootstrap, repair and removal. The separately inspected settings helper rejects malformed/unreadable existing files and preserves predecessor information; that benefit does not transfer automatically to an independent writer.

## Proposed preservation fixtures

| Fixture | Required observable result | Execution status |
|---|---|---|
| Clean, verified vendored installation | Migration succeeds and intended hooks/settings exist. | Not run here; existing clean test source is reported. |
| Modified owned file | File survives, is backed up with verified bytes, or migration blocks. | Proposed. |
| Untracked file and local-only nested commit | Both survive or block before destructive work. | Proposed. |
| Foreign folder with generic `VERSION` | Folder and all contents remain unchanged. | Proposed. |
| Existing malformed settings | Exact bytes remain unchanged; actionable error is returned. | Proposed. |
| Existing unreadable settings | No replacement; preserve mode and bytes and report limitation. | Proposed. |
| Missing settings | Create only the authorized settings at the declared path. | Proposed. |
| Repeated installation with unrelated valid hooks | Preserve unrelated hooks; no duplicate owned effects. | Proposed; existing well-formed test source is reported. |

Reported existing test locations are `test/team-mode.test.ts` lines 365–404 for clean migration and symlinks, and lines 245–268 for well-formed settings/hooks. Those cases do not establish the missing negative preservation properties. Follow the [installation handbook](../handbook/09-installation-and-releases.md) and retain each test's exact input/output identities in a receipt.
