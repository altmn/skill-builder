# Audit reading guide

Read [scope and conclusions](../handbook/00-scope-and-conclusions.md) first. The following reports retain source-level detail and pinned references:

| Report | Coverage |
|---|---|
| [Core instructions](core-instructions.md) | Root policy/router; office hours, planning, autoplan, review, QA, spec, canary and skill-authoring instructions. |
| [Secondary instructions](secondary-instructions.md) | 53 skill/adapter audit units, including design, developer experience, iOS, documentation, context, evaluation, host variants and model overlays. |
| [Runtime, security and tests](runtime-security-tests.md) | Browser/runtime architecture, safety hooks, CSO, process/network/data boundaries, testing/evals, performance and native publication guards. |
| [Lifecycle and project](lifecycle-project.md) | Generation, hosts, installation, upgrades, migrations, releases, CI, ship/deploy workflows and GitHub presentation. |
| [Memory instructions](memory-instructions.md) | Setup/sync workflows, data flows, consent, secrets and concurrent writes. |
| [Shared macros](shared-macros.md) | Shared resolver ownership, actual expansions, evidence, browser/QA variants and remaining rendering limits. |
| [Standards and OpenAI creator](standards-and-skill-creator.md) | Current primary-source guidance, host differences, creator file roles and reproduced validator gaps. |

Per-track JSON files preserve the underlying coverage records. They overlap by design. **Do not add their counts together.** The merged [file-review.json](../catalogs/file-review.json) and [coverage summary](../catalogs/coverage-summary.json) are the authority for unique repository counts.

`skill-creator-validator-observations.json` contains the actual isolated probe results for the pinned public helper. `tools/test-results.json` separately records tests of the original validator shipped with this knowledge base.

Source-level findings are not claims of demonstrated exploitation. Static evidence can establish a contradictory instruction, an encoded fallback, or a missing condition; runtime consequences and platform behavior may require further tests. The reports say when that work was not performed.


## Applied review and continuing work

The [lifecycle entrypoint matrix](lifecycle-entrypoints.md) adds the team-initialization preservation branches identified in the supplied review. [Review follow-ups](review-followups.md) record source-update examples, documentation evidence gaps and named high-impact owners requiring further semantic work. These additions preserve historical depth counts; they do not convert proposed source tests into completed executions. The complete finding-by-finding change record is [review-application.md](../validation/review-application.md).
