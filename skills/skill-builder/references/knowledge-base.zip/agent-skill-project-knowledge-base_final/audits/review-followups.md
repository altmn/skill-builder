# Review follow-ups and evidence history

This addendum applies the supplied research-and-improvement report without replacing the baseline analysis. Report SHA-256: `f15d006ed7ab7f36b571362ec0a382a1e7cf9a034f3a3e49b55ce6dd578f2c63`. Its date is November 22, 2026, America/Los_Angeles. The report's independent checks, static observations and unexecuted recommendations remain distinct from this revision's local checks.

## F03 lifecycle preservation

The [entrypoint matrix](lifecycle-entrypoints.md) records the two new static team-initialization concerns and the positive shared-settings path. The baseline source and recorded blob identify the evidence. Proposed preservation tests are not labeled passed. Main-installer and uninstall observations keep their original implementation scope.

## Capture and process evidence

F04 corrects the interpretation of file-based subprocess capture. Post-exit capped reads bound returned stdout/stderr text; they do not demonstrate a capture byte quota during execution. Preserve the earlier stderr-truncation reporting concern separately. Controlled noisy-child, startup, timeout, descendant and cleanup tests remain proposed upstream follow-up work. No disk-exhaustion attack was reproduced.

## Three traceable slices

The [approach map](../catalogs/approach-catalog.md) and [command map](../catalogs/command-catalog.md) organize browser interaction, review/ship evidence and installation/removal. Each entry links owners, caller evidence, test leads and limits. The maps are intentionally candid about implementation gaps: a source filename, test label or architecture claim does not establish semantics or a passing test.

| Review owner at the baseline | Existing coverage | Next concrete question | Disposition |
|---|---|---|---|
| `bin/reference-project-team-init` — 269 lines | Structural in the original ledger; report adds targeted lines 43–59 and 196–232. | Do all ownership/settings branches preserve local work? | Two static concerns recorded; negative tests proposed. |
| `browse/src/snapshot.ts` — 659 lines | Structural. | When are element references invalidated, and do stale-reference errors lead to safe recovery? | Architecture evidence retained; do not claim verified implementation. |
| `lib/run-evidence.ts` — 554 lines; `lib/ci-carry.ts` — 297 lines | Structural. | Which external evidence proves this exact candidate under each carry/refusal path? | Priority semantic review; later report's narrow update recorded below. |
| `scripts/test-free-shards.ts` — 2,317 lines | Structural. | Which cases execute, how are exclusions/retries counted, and how are missing summaries rejected? | Priority semantic review before adopting this runner. |
| Optional native device runtimes | Mixed/structural as recorded. | Which device, authority and platform guarantees are actually needed? | Optional capability-specific work; no new support claim. |

## Observed source update

| Identity | Historical baseline | Fixed later observation |
|---|---|---|
| Source commit | `ccd80de8ebdd7ca3384cc54bc138b53cd311a732` | `261f380002d19f67bca028dd48364729803c8bc5` |
| Commit time, Los Angeles | 2026-11-22 17:08:54 | 2026-11-22 19:51:23 |
| Package version | `1.102.2` | `1.102.2` |
| Runtime `VERSION` contents | `1.102.2.0` | `1.102.2.0` |
| Tracked paths | 5,375 | 5,385 |

The supplied review reports 29 changed paths: 10 added and 19 modified, with 641 insertions and 42 deletions. This is a fixed observed delta, not the current default branch. The complete changed-path list was not included in the report and has not been reconstructed here. The machine-readable update inside [approach-catalog.json](../catalogs/approach-catalog.json) marks this boundary and enumerates only specifically identified owners.

### Scoped CI evidence equivalence

The later revision expands one PR CI-carry path when the base moved: evidence reuse depends on stated parentage and unchanged-own-diff conditions, preserves the tested merge tree in run evidence and records base movement in the receipt. A merged-tree deployment gate remains separate. Reported source owners are `lib/pregate/run-check.ts` lines 62–88, `lib/run-evidence.ts` and `docs/ship-policy.md` at the later commit.

The general lesson is to state what identity can differ, why retained evidence remains relevant and which downstream actions still need fresh checks. Matching changed lines are not a general proof of program equivalence. No earlier finding is marked resolved and no prior passing receipt is transferred to the later source.

### A secondary judge that failed calibration

The later `docs/evals/ship-panel-plain-reads-results.md` reports 30 planted-bug cases, three trials per case, two model/host settings and four review configurations. Its primary planted-bug measure uses a frozen rule-based scorer. A secondary model judge failed calibration and remained unscored. The 120-item calibration reference labels came from Claude Opus 5.5; they are not human validation. A frozen GitHub-network rule and a separate, unplanned sensitivity analysis affect interpretation.

The cases derive from the project's historical bugs, and the upstream report discloses exposure flags and other departures. These reported results were not independently rerun here. A planted-defect review study measures a different task from the earlier whole-pack experiment on completing fixes and features. Preserve each study's task, models, exclusions and limits; one cannot reverse the other's conclusion by simple comparison.

### Smaller reported changes

The report describes clearer tradeoff wording in a review prompt, captured recommendation-grader examples around a scoring threshold, a documentation-sync fixture aligned with actual arguments and records, and Windows exclusions for new direct-shebang cases. Exact paths for all of these changes were not supplied. The useful lessons are to improve the grader, distinguish a harness contract problem from product failure, and report exclusions. These are dated examples, not additional universal rules.

## Documentation history

The [host documentation register](../sources/host-documentation-register.json) stores bounded supporting excerpts and hashes for selected changing claims. Inherited source entries remain visible when no original capture or revision was supplied. An excerpt hash identifies the retained text; it does not authenticate a whole webpage or establish live behavior. Future updates should append a resolution/verification event and retain the source and result that supported the original finding.
