# License status and component coverage

## Original knowledge-base material

**No public reuse license has been selected in the supplied materials. This revision does not make a new license grant on the rights holder’s behalf.** The handbook, original analysis and rules, task briefs, validator, indexer, build tools, schemas, examples, and scaffolding remain subject to their existing rights. Their inclusion in a downloadable working archive is not a statement that they are licensed under a referenced project’s terms.

This explicitly records the remaining publication decision identified by review finding F11. Before distributing this knowledge base as an openly reusable project, the rights holder must select and include the full license text for the components they are authorized to license. They may choose one license for prose and code or identify separate grants. Record the covered paths, rights holder and effective revision, and check all retained exceptions. Until that decision is made, an open-reuse publication gate is **blocked**. Local research, maintenance and validation results are independent of that gate.

| Component | Current recorded status |
| --- | --- |
| Original handbook, audit synthesis, checklists and rules | No additional public license grant in this revision; rights holder selection pending. |
| Original validator, indexer and build/check tools | Same pending status; no inference from a dependency’s license. |
| Original schemas, examples, task briefs and generic scaffolding | Same pending status. An adopting project must independently choose terms for its own material. |
| Short excerpts and adapted identifiers from the reference source | Retained upstream terms; see the MIT license and detailed third-party notices under `sources/upstream-notices/`. |
| OpenAI public helper comparison and retained license | The retained Apache 2.0 text applies to covered upstream material; the original validator is a separate implementation. |
| Other primary documentation | Attributed summaries and bounded supporting evidence, subject to the source’s terms; no site-wide relicensing. |

## Retained third-party material

The full license texts and copyright notices already supplied with the knowledge base remain included. [NOTICE.md](NOTICE.md) identifies the sources and exceptions. The reference source’s notice uses normalized project identifiers for this edition; its copyright attributions, license declarations, descriptions of modified material, and complete license texts are preserved. See [the provenance policy](sources/PROVENANCE.md) for the difference between an adapted display excerpt and original source bytes.

This file records distribution status. It does not decide ownership of any passage, remove an existing upstream permission, or impose new terms on third-party material.
