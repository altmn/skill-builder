# Knowledge-base change record

## Review-integration revision — November 22, 2026, America/Los_Angeles

This revision applies the supplied improvement report to the complete knowledge base. It preserves the original architecture and detailed research. All 99 rules, 5,375 file records, 25,693 instruction records, 136 skill-artifact records, 24 original findings, 18 original evaluation designs and original detailed reader inputs remain. New findings and cases are appended. Source display identifiers are normalized with explicit provenance; original source hashes and commit identities retain their meanings.

### Correctness

- Repaired the portable validator's Markdown masking, with report-specific regressions, controls and a finite CommonMark differential panel. Ambiguous unsupported constructions fail the required coverage gate explicitly.
- Replaced the mixed worktree/index/commit inventory with an explicit-revision Git-object reader. Dirty, staged and conflicted working trees do not change the committed bytes it reports; symlinks, gitlinks and large-file pointers have declared treatment.
- Corrected the explicit runtime `VERSION` value to `1.102.2.0`, retaining package version `1.102.2` separately. Replaced the nonexistent standards source-register reference.
- Clarified that capped returned output does not establish a capture-storage quota; retained stderr truncation reporting as a separate issue.

### Reusable implementation

- Added versioned evidence schemas, local validation and six filled examples. Independent support claims, exact artifact identity, attempts, usage units, unknown measurements and numeric source ranges are explicit.
- Added a completed read-only manifest-inspection project, deterministic three-file package, two fixtures, frozen local panel, filled audit and unexecuted host recipes.
- Retained the eighteen original evaluation designs and added four temporal/discovery/namespace host cases.
- Added three proportionate profiles and five capability modifiers joined to the existing rule catalog, with full rule-decision traceability.

### Research and maintenance

- Added a lifecycle-entrypoint matrix and two conditional static preservation findings for team initialization.
- Added ten approach records and eleven selected command/interface contracts connecting owners, callers, tests, rules and limits.
- Added dated documentation evidence and a source-update record while retaining historical claims and explicit capture/review gaps.
- Added deterministic full readers, catalog projections, sample packaging, manifest generation, relational bundle checks, a review-merge workflow and CI recipe. Historical receipts are separate from current results.
- Clarified original-material licensing status without making an unselected owner license grant. Full existing third-party license texts and copyright attributions remain included.

[The implementation record](validation/review-application.md) maps every review finding to its changes, evidence and remaining boundaries. [The validation guide](validation/README.md) identifies the current receipts and the preserved historical browser result.
