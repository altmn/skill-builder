# Evaluation kit

[case-designs.json](case-designs.json) supplies **22 reusable case designs**: the original 18 designs plus four focused host lifetime and identity cases. Instantiate each applicable design with a real prompt, fixture, reset procedure and independent acceptance check. These are **not executed agent results**.

Use the [versioned evaluation receipt](../templates/evaluation-receipt.json.template) for each evaluation and validate it with [the evidence schemas](../schemas/README.md). Freeze the panel, acceptance criteria, budget, retries and exclusions before comparison. Separate development and held-out cases. Compare candidate/previous/no-skill conditions without inherited skill instructions in the control. Preserve every attempt and label unavailable infrastructure.

## Across turns, refreshes and namespaces

| Case | Tests | Evidence boundary |
| --- | --- | --- |
| `HOST-03` | Second turn, compaction/context loss and optional worker handoff | Record instruction text, invocation permissions and durable task state separately. A simulated context-loss test is not a live compaction trial. |
| `HOST-04` | Re-invocation, changed source, removal and disablement | Identify the artifact actually governing each attempt; cached content and fresh-session discovery may differ. |
| `HOST-05` | Duplicate names, namespaces and reserved-name behavior | Observe which artifact was selected; do not impose one host's precedence on another. |
| `HOST-06` | Relative resources, namespaces, optional symlinks and worker identity | Resolve resources from the activated artifact and label unexposed identity inconclusive. |

The paired [probe A](fixtures/root-a/identity-probe/SKILL.md) and [probe B](fixtures/root-b/identity-probe/SKILL.md) have the same skill name and distinct markers/resources. They are test fixtures, not installed skills. A returned marker helps distinguish branches but cannot by itself prove the host loaded the expected bytes. Retain native artifact IDs or resolved source paths and hashes where the host exposes them. Record unknown behavior honestly.

Read [the testing chapter](../handbook/06-testing-and-evaluation.md) for interpretation and reporting and [the completed manifest-inspection example](../examples/manifest-inspector/README.md) for runnable local resource tests and an explicitly unrun host panel. The local structural validator's tests validate the checker itself, not a host or this task panel.
