---
name: identity-probe
description: Return a fixed identity marker and read a bundled marker resource for a disposable host-adapter identity test. Use only when the user explicitly requests this identity test.
---

# Identity probe A

Return the literal marker `PROBE-A`. Read [the bundled marker](references/identity.txt) relative to the skill actually loaded and report its contents. Report the loaded source path or native artifact identity only if the host exposes it; otherwise say it is unknown. Do not infer a source path from this text. Do not write, install, fetch, or run a process. Respect a missing or denied resource as blocked.
