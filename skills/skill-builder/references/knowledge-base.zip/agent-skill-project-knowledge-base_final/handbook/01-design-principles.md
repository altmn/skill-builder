# 1. Design principles and project size

## The recommended default

Build a small portable task contract, attach deterministic resources only where they improve reliability, and add explicit adapters for the hosts you support. Begin with Codex as the primary target. Treat Claude Code and Grok Build as separate integration targets with shared task logic. A reusable skill should make a real task more reliable or less expensive than the same agent working without it.

This knowledge base uses four kinds of statements:

| Label | Meaning |
|---|---|
| Format requirement | A requirement of the published Agent Skills specification. |
| Documented host behavior | What a named product's current documentation says; live execution may still need confirmation. |
| Benchmark observation | What is present in the pinned reference-project source. Presence is not proof that every execution behaves correctly. |
| Project recommendation | An engineering choice proposed here. Adopt it when its failure scenario applies; it is not a universal industry mandate. |

The rules catalog makes these distinctions machine readable. Use **required** for controls your project chooses to enforce, **recommended** for a justified default, and **conditional** for controls triggered by a capability. Do not describe every preference as a standard.

## Three practical sizes

| Size | Appropriate when | Minimum contents | Do not add by default |
|---|---|---|---|
| Instruction skill | A repeatable reasoning or writing workflow needs expertise and structure. | `SKILL.md`, task examples, short references if needed, tests/evals maintained at repository level. | Installer, daemon, database, telemetry, generator, model routing. |
| Skill with resources | Exact parsing, formatting, transformations, or validation recur. | Above plus a small script/library, declared runtime, fixtures and observable tests. | A new service for a task a local script can finish. |
| Skill suite/runtime | Several related tasks share durable state, commands, adapters, or a managed service. | Above plus versioned contracts, ownership-aware lifecycle, capability matrix and integration tests. | Cross-provider automation, automatic update, or fleet coordination without a demonstrated need. |

reference-project is in the third category. Its browser runtime, release controls, review ledgers, host rendering, and large test corpus explain much of its complexity. Its file count is not a target for a new skill.

## Separate the contracts

1. **Discovery:** what requests should activate this skill, and which should not?
2. **Task:** what outcome is promised, with what inputs and authority?
3. **Execution:** which resources or tools perform work, and with what side effects?
4. **Evidence:** what establishes success, failure, partial completion, or missing coverage?
5. **Distribution:** what gets installed, where, by which versioned process?
6. **Maintenance:** which changes invalidate prior evaluations or compatibility claims?

Many failures come from collapsing these contracts. A description can match a request while the needed tool is absent. A script can exit successfully without creating the intended artifact. A review can finish while the change still has unresolved defects. A package can install on a host whose permission fields have different meanings.

## Reusable patterns supported by the source research

The benchmark repeatedly binds review results to specific source inputs, distinguishes incomplete checks from clean checks, keeps conditional instructions in separate sections, uses deterministic helpers for state and evidence, and develops regression fixtures for real incidents. Those are useful patterns. Its instruction diet also asks whether a failure belongs in code, command help, a conditional reference, or the main prompt before adding another rule. See the [core audit](../audits/core-instructions.md) and [runtime audit](../audits/runtime-security-tests.md).

Adapt these patterns to the task's stakes. A document-formatting skill needs artifact checks and a clear output contract; it does not automatically need a multi-reviewer release gate. A publishing skill needs an exact destination and authorization boundary; it does not need to ask again when the current request already covers the exact publication.

## A usefulness test for every new instruction

Before adding a rule, answer:

- What observed error or plausible high-impact failure does this prevent?
- Why cannot the resource, schema, default, or tool error prevent it more reliably?
- At what point must the agent know it?
- What observable behavior would show that the rule worked?
- What reasonable task could the rule obstruct?
- Which existing instruction owns the same meaning?

Delete an instruction when it repeats another owner, describes general competence without changing behavior, promises a capability the host lacks, or preserves an obsolete incident workaround. Keep rare but consequential safety conditions when their enforcement boundary still exists. Concision is a means to better behavior, not a word-count competition.

## Quality without misleading scores

Use a release verdict with named blockers. A high average score must not offset data loss, unexpected publication, secret disclosure, or missing required verification. Record user-visible quality, task correctness, safety, portability, performance, and maintainability separately.

You can use a weighted score for choosing among designs after all mandatory conditions pass. Publish the weights, missing-data policy, sample size, and limits. A reviewer confidence value is a judgment; it becomes a probability only after calibration against known outcomes.

## Definition of done

A skill project is ready for its stated support tier when its distributed artifact is structurally valid, its intended activation behavior has been evaluated, representative tasks meet independent acceptance conditions, denied actions remain denied, lifecycle instructions match their actual effects, and the README makes supported environments and limits clear. Record any unavailable test as unavailable. Do not turn a deadline into a passing result.

Sources: [Agent Skills specification](../sources/primary-sources.md#s01), [creator best practices](../sources/primary-sources.md#s10), [OpenAI creator](../sources/primary-sources.md#s08), and the pinned reference-project audit reports. The size categories and contract model above are original recommendations.

## Select a profile and record applicability

Choose one [application profile](../catalogs/application-profiles.md): instruction skill, resource-assisted skill, or suite/runtime. Add capability modifiers for network access, external publication, persistent state, authenticated browser use and installation only when those effects exist. The [machine-readable profile selection](../catalogs/application-profiles.json) refers to the canonical rule IDs; it does not create a second copy of the rules.

For every adopted rule record the failure scenario, authority or source, verification method, evidence artifact and release consequence. Record a justified override when the default does not fit. `not_applicable` needs a reason; `not_assessed` means work remains. Selecting a required local policy does not convert it into a format requirement or an industry mandate. The original catalog still distinguishes five specification-based entries from 94 project-policy entries, with strengths of 43 required, 34 conditional and 22 recommended.

A writing skill should not acquire migration or daemon gates from the suite profile. A script-bearing skill should retain relevant input, output, error, timeout and resource tests. A publishing skill must document why an authorization rule could be inapplicable; the profile name alone cannot waive a real external effect.
