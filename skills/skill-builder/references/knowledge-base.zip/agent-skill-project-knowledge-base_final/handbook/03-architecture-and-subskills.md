# 3. Repository architecture, sub-skills, and generation

## Repository and installed payload have different audiences

The repository serves users, maintainers, reviewers, release automation and the agent. The installed payload serves execution. Keep the repository well documented while keeping the payload selective.

| Path | Role | Installed by default? |
|---|---|---|
| `README.md` | Purpose, example, installation, support and limits. | No, unless the distribution needs it. |
| `LICENSE`, `NOTICE` | Applicable rights and attribution. | Include where required for distributed material. |
| `CONTRIBUTING.md`, `SECURITY.md`, `CHANGELOG.md` | Maintenance, reporting and release contracts. | Normally no. |
| `AGENTS.md` | Instructions for agents contributing to this repository. | No; it is not the task skill. |
| `skills/<name>/SKILL.md` | Portable entry point. | Yes. |
| `skills/<name>/references/` | Conditional domain detail. | Only referenced runtime documents. |
| `skills/<name>/scripts/` | Deterministic resources. | Only required executables and locked dependencies. |
| `skills/<name>/assets/` | Output templates or small required assets. | Only what execution uses. |
| `adapters/<host>/` | Host metadata and rendering rules. | Into the target host artifact. |
| `tests/`, `evals/` | Fixtures, tests, task panels and graders. | Normally no. |
| `schemas/` | Input/output and state contracts. | If runtime validation needs them. |
| `dist/` | Generated release artifacts. | This is what users install; do not edit manually. |

For a single instruction skill, omit empty directories. The table is a map of responsibilities, not a requirement to create fourteen folders.

## When to split a skill

Split into separately discoverable skills when the user intent differs, side effects or authority differ materially, the required tools differ, or users can benefit from invoking each workflow independently. For example, auditing a change and publishing a release can be related skills with separate entry points.

Use conditional references when the intent is unchanged but details vary: platform-specific commands, different input formats, or a deep checklist. A user should not have to choose among six sub-skills to complete one coherent task.

Use a script/module when the work is deterministic and repeatedly error-prone: parsing, path confinement, hashing, schemas, redaction, ledger writes, or command execution. Moving a calculation into another prompt does not make it deterministic.

## Compose through explicit artifacts

Each sub-skill should accept a small input contract and produce a verifiable output contract. A handoff should include:

- Task and scope identifiers.
- Input paths and hashes or revision identity.
- Decisions already made and their source of authority.
- Output paths and schemas.
- Completed, failed, skipped and pending work.
- Known constraints and capability gaps.
- External effects already attempted and their observed state.

Avoid making the receiving skill reconstruct state from a long chat transcript. Avoid making it trust a summary that claims approval without identifying the action covered. A persisted decision is evidence of an earlier decision; whether it still applies depends on scope, freshness and policy.

## Parallel work

Parallelize independent reads, bounded research and disjoint tasks when it saves elapsed time. Give every worker a task, source scope, output contract, budget and stop condition. Keep shared writes under one owner or use isolated workspaces with an explicit integration step.

Before editing a file under review, make sure readers that need a stable snapshot have finished or are confirmed stopped. A tool timeout alone does not establish process termination. Record incomplete results from failed workers; successful peers do not retroactively complete missing coverage.

Review quality depends on independent evidence, not the number of workers. Fresh contexts can reduce shared assumptions, but workers may still share the same model, instructions and blind spots. Do not advertise an independent-model review unless actual runtime identity supports it.

## Introduce generation only when it earns its cost

reference-project authors many workflows in `SKILL.md.tmpl`, expands shared sections, applies host capabilities and model overlays, and validates generated artifacts. That is useful at suite scale. Its source and output distinction also creates a maintenance obligation: generated text can drift from current helper behavior.

A smaller project can author portable `SKILL.md` directly and maintain a thin metadata adapter. If generation becomes necessary, document:

1. Authoritative input files and their owners.
2. All interpolation variables and allowed types.
3. The host capability schema and unsupported-feature behavior.
4. Deterministic ordering and environment dependencies.
5. The output manifest, source revision and generator version.
6. A drift check comparing regenerated output with committed/distributed output.
7. A direct way to inspect the exact artifact users receive.

Test generated outputs for unresolved placeholders, invalid YAML, broken references, wrong shell paths, accidental permissions, repeated preambles and missing safety conditions. Run host tests against the release package, not a privileged developer checkout.

## Shared policy and overlays

Shared text helps when the same invariant truly applies to several workflows. Centralize it, but avoid loading an entire suite policy into every small task. Loading a reference on a stated condition can be better than copying a universal preamble.

Keep host adaptation separate from model adaptation. A host controls tools, discovery and permissions. A model influences reasoning quality, verbosity and context behavior. An overlay that simplifies instructions for a model must pass the same acceptance and safety tests. Do not assume a model family requires a smaller workflow solely from its name.

## State ownership

Use a resolved application state root rather than scattered hardcoded home paths. Separate configuration, cache, logs, credentials and user outputs. Record which files the project owns. An uninstall should not delete a shared parent directory or unrelated data.

Use versioned schemas and atomic file replacement for durable records where interrupted writes matter. For concurrent writers, choose a tested locking/transaction strategy. JSON lines are convenient append records, but append behavior, partial lines and multi-process writers still need handling.

## Architecture review questions

- Can each workflow explain its outcome in one sentence?
- Can a user install only the capability they need?
- Is every runtime dependency reachable from an entry point or declared resource?
- Is there one owner for policy, schema, command behavior and generated output?
- Are the same conditions represented consistently in instructions, code and tests?
- Is a plain directory sufficient, or is a plugin/runtime actually needed?
- Does complexity protect a concrete resource or reduce measured work?

Sources: [reference-project lifecycle audit](../audits/lifecycle-project.md), [core audit](../audits/core-instructions.md), [Agent Skills client guidance](../sources/primary-sources.md#s02), and [OpenAI creator](../sources/primary-sources.md#s08). The proposed layout and split criteria are recommendations.
