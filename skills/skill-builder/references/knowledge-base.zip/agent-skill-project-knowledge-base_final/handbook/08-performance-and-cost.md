# 8. Performance, context, and cost

## Measure the user's whole task

A faster helper is useful only when it improves the complete workflow without losing correctness. Measure discovery, instruction loading, model work, tool work, verification, user interruptions and recovery separately. A small entry point that always loads several long references may not reduce total context.

Track at least these dimensions when relevant:

| Dimension | Suggested measure | Common misleading substitute |
|---|---|---|
| Discovery | Total advertised metadata and selection accuracy. | Number of installed skills. |
| Activated context | Actual loaded text/tokens for a task. | `SKILL.md` line count alone. |
| Latency | End-to-end elapsed time; cold and warm runs. | Fastest subcommand. |
| Reliability | Correct outcomes per attempted task, with exclusions visible. | Best of several retries. |
| Cost | Provider usage or labeled estimate, including failed calls and retries. | A successful run's model cost only. |
| User effort | Necessary questions, manual repairs and unresolved blockers. | Number of autonomous actions. |
| Resource use | Peak memory, CPU, process count, storage and network where material. | An unsupported “lightweight” label. |

Choose budgets from real workloads and support environments. This knowledge base does not prescribe a universal token, second, dollar or file-count threshold.

## Context management

Use discovery metadata for selection, a short entry point for invariant behavior, and conditional references for specialized branches. Give each reference a purpose and load condition. Avoid repeated preambles and instructions for tools the current host cannot use.

Move deterministic mechanics into a helper when it reduces repeated model reasoning and has a clear interface. Return compact structured results when large raw output is not needed, while preserving a path to the underlying evidence. Do not truncate away failure details or adversarial content needed for the decision.

Token counts depend on the tokenizer. The audit's `bytes / 4` values are rough planning estimates only. reference-project's own estimator has calibration limits. Use actual runtime usage or a named tokenizer for performance claims, and disclose what was measured.

## Concurrency

Parallelize independent reads and computations. Bound worker count, duration, total paid calls and output volume. Keep conflicting writes sequential or isolated. If parallel review requires all results, include the slowest task and integration time in the latency measure.

Do not fan out simply to claim more thoroughness. Ask whether each worker adds a distinct source, hypothesis, platform or expertise. Several workers repeating the same prompt can spend more without improving coverage.

## Daemons and warm state

Persistent processes can amortize expensive startup such as browser launch. They also introduce authentication, lifecycle, stale state, crash recovery, process ownership, port allocation and cleanup obligations. Benchmark cold start, warm commands and repeated sessions separately.

A simple one-shot transformation should usually stay a one-shot command. Add a daemon only after measured startup costs justify it and the maintainer can support its security and lifecycle contract.

## Caching

Cache expensive results when identity and invalidation are clear. Include relevant file hashes, tool versions, configuration and environment in the key. Define retention and size bounds. Do not reuse approval, login state or a prior passing gate solely because its timestamp is recent.

Record cache hits in evaluation receipts so improvements can be attributed correctly. Compare equivalent warm or cold conditions. A warm candidate versus a cold baseline is not a fair speed comparison.

## Paid operations

Use a shared budget for a parent and its workers. Enforce the bound before the paid call where possible, and reconcile actual usage afterward. Reserve capacity for in-flight operations; checking only after the spend is too late. Distinguish token, request and currency units.

Store unknown usage as unknown. Keep costs from failures, refusals, retries, setup probes and discarded candidates. A benchmark that repeats a run solely to obtain a JSON report should instead capture human and machine results from the same attempt.

## Optimization method

1. Identify a specific slow or expensive phase from traces.
2. State a hypothesis and preserve task/safety acceptance conditions.
3. Change one meaningful factor when practical.
4. Compare matched baseline and candidate runs.
5. Report sample size, variation, infrastructure exclusions and tradeoffs.
6. Retain the change only if the benefit is useful and maintenance cost acceptable.

Instruction pruning follows the same process. Removing prose is beneficial when it reduces cost while preserving or improving outcomes; line reduction alone is insufficient.

Sources: [reference-project runtime audit](../audits/runtime-security-tests.md), [instruction diet audit](../audits/core-instructions.md), [Agent Skills evaluations](../sources/primary-sources.md#s11), and [Anthropic advanced tool use](../sources/primary-sources.md#s20). Metrics and optimization procedure are project recommendations.

## Output, capture, deadlines and retention are different budgets

| Resource contract | What is bounded | Independent check |
|---|---|---|
| `response_bytes` | Bytes returned from each stream to the agent. | Produce output above the response limit; verify exact truncation flags and retained error context. |
| `capture_bytes` | Bytes stored while the child is still running. | Cross the quota before exit; verify backpressure, rotation or termination according to policy. |
| `execution_deadline` | Time allowed for startup and execution. | Exercise startup failure and timeout separately from normal completion. |
| `process_tree_cleanup` | Descendants and owned resources left after completion or cancellation. | Observe child and descendant exit plus owned-file cleanup. |
| `retention` | How long captured logs and receipts remain and their total stored size. | Verify expiration/rotation and preservation of needed failure evidence. |

The reference capture helper writes stdout and stderr to files and applies its read cap after exit. This supports a returned-text bound; it does not demonstrate a fixed capture-storage bound. A timeout limits time but permits varying byte production rates. The separate stderr-truncation summary concern remains in the original findings. These are source observations, not a reproduced disk-exhaustion incident. See the [runtime clarification](../audits/runtime-security-tests.md#capture-storage-clarification).
