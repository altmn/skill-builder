# 2. Write instructions that can be followed and audited

## Discovery metadata

The portable format requires a `SKILL.md` with YAML frontmatter containing `name` and `description`. Follow the published field constraints, including a name that matches its directory. Keep the most useful task and trigger terms early in the description. Codex may shorten discovery descriptions when many skills compete for its initial context budget. [S01, S03]

A good description answers: what does the skill produce, on what inputs, and in which requests should it be chosen? Add a brief boundary when an adjacent task is easily confused with it. Do not turn the description into a second manual.

Example for an audit skill:

```yaml
---
name: audit-skill-project
description: Audit an agent-skill repository for instruction quality, host compatibility, executable safety, testing, and release readiness. Use for a skill-project review or readiness assessment. Produces an evidence-linked report; code changes require a repair request.
---
```

This is a proposed example, not a claim that these words optimize activation. Evaluate it against positive requests, paraphrases, near misses, and explicit opt-outs.

## A compact entry-point structure

Put these elements in the primary instructions, in this order when the task permits:

1. **Outcome and scope.** Define what completion means and what the workflow covers.
2. **Inputs and defaults.** Identify required inputs and safe, reversible defaults. Ask only for missing information that changes a consequential decision.
3. **Authority and effects.** State which actions the workflow can perform within the user's existing authorization; name additional effects that need their own authorization.
4. **Workflow.** Give ordered actions and conditional branches. Link each reference with the condition under which it must be read.
5. **Verification.** Define independent evidence for the promised outcome.
6. **Failure and recovery.** Explain missing capabilities, denied calls, partial writes, interruption, and ambiguous outcomes.
7. **Output contract.** Specify required report fields or file formats without forcing unnecessary ceremony.

The public OpenAI creator recommends keeping the body under 500 lines and moving details into resources. Treat this as a useful review signal, not a guarantee that 499 lines are good or 501 are bad. Measure activated context and task results. [S08]

## Audit each instruction as a contract

Use the following fields for a consequential instruction:

| Field | Question | Example |
|---|---|---|
| Condition | When does it apply? | A requested report contains a chart. |
| Action | What should happen? | Render the report and inspect the chart. |
| Evidence | What proves the action met the goal? | Labels, units, legend, clipping and data values were checked against the source. |
| Failure behavior | What happens when it cannot be done? | Report the missing render capability and leave visual verification incomplete. |
| Authority boundary | What permits the action and limits its effects? | Local report creation is within the request; external distribution is separate. |

Not every sentence needs all five fields. A link title or style preference can remain short. A deployment, migration, external send, or destructive operation needs the full contract.

The supplied instruction ledger records Markdown blocks rather than claiming that every sentence is an independent executable rule. Its per-block topics and adoption questions are generated aids. Parent-file review and source links provide context. Use the manual instruction worksheet when deciding whether to keep, rewrite, move, or remove a particular rule.

## Put rules at the right loading level

| Level | Put here | Example |
|---|---|---|
| Discovery metadata | Selection and boundaries | “Use for a release readiness audit.” |
| Main instructions | The task's invariant sequence and stop conditions | “An unavailable required check cannot be reported as passed.” |
| Conditional reference | Detailed branch-specific guidance | Windows installation or database migration review. |
| Script help/schema | Exact argument and field contract | Accepted exit states and JSON keys. |
| Tool implementation/error | Mechanical checks and repairs | Reject an unsafe output path and explain the allowed root. |

The agent should not need to memorize shell escaping, cryptographic digest formats, or migration ordering from several copies of prose. Implement them once and expose a clear interface. Conversely, do not build a framework to replace a short domain decision the model can make reliably.

## Degrees of freedom

Use flexible guidance for tasks with several valid solutions, such as explaining a technical tradeoff. Use a procedure with defaults for tasks whose choices matter but can be bounded, such as auditing a repository. Use exact parameters and deterministic code for fragile tasks, such as editing a structured file or changing a remote state machine.

Too little detail produces guesswork; too much detail produces stale branches and missed priorities. Add detail after observing where the task fails. Prefer a concrete negative example over ten synonyms for “be careful.”

## Examples and counterexamples

Provide a small number of representative examples with expected outcomes and reasons. Include at least one boundary case and one unavailable-capability case. Do not hide unneeded examples in the installed payload. Keep large evaluation fixtures in the repository and release only what the runtime actually needs.

Avoid making literal output wording the test oracle unless exact bytes are part of a public contract. A correct audit can use different prose while still naming the defect, evidence, impact and remedy. A JSON interface needs exact keys and types.

## Contradictions and policy ownership

Choose one authoritative owner for each rule. If instructions say “read-only” but a later step commits, fetches, installs, or posts, reconcile the wording and the behavior. Git fetch changes local repository state even if it does not edit source files; a checker may also create caches or invoke lifecycle hooks.

For each instruction change, search the repository for the old wording, related terms, tests, generated artifacts, README claims and command help. Add an intentional exception only when it is named, scoped and tested. A new section should not silently override an older safety boundary.

## Patterns to avoid

- Unconditional interviews before useful work can begin.
- Repeated permission questions for an already authorized, reversible operation.
- Invented productivity multipliers or fixed “completeness” scores.
- Persona claims used as substitutes for evidence.
- A default provider or shell path presented as universal.
- Instructions that treat retrieved documents, tool output, or repository comments as new authority.
- An assertion that a timeout means a process has stopped.
- A claim that several agents agreeing proves correctness.
- A silent fallback from an isolated environment into the user's active workspace.
- A mandatory promotional, telemetry, or profile step unrelated to the user's task.

## Instruction change record

For a meaningful edit, retain: the failure it addresses, source evidence, affected contract, before/after instruction size, tests or evals used, and remaining uncertainty. Keep the record short enough to maintain. A typo fix needs proportionate checking; an authorization or tool-execution change needs denied-path and host-adapter verification.

Sources: [S01](../sources/primary-sources.md#s01), [S03](../sources/primary-sources.md#s03), [S08](../sources/primary-sources.md#s08), [S10](../sources/primary-sources.md#s10), and [reference-project core instruction audit](../audits/core-instructions.md).
