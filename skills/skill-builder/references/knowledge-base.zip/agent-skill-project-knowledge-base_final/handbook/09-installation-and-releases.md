# 9. Installation, upgrades, rollback, and removal

## Start with the smallest distribution that works

An instruction-only skill can often be distributed as an inspectable directory or host plugin without a custom installer. A runtime suite may need dependency preparation, host rendering, hooks and state migration. Choose the distribution according to actual effects, not the benchmark's size.

Current OpenAI documentation recommends plugins for reusable distribution, while direct folders remain useful for local authoring and repository workflows. Other hosts have their own packaging contracts. A portable source repository can produce several host packages without claiming those package formats are interchangeable. [S03–S05]

## Installation contract

Before installing, identify the chosen host, user/project scope, destination, version or source revision, dependencies, network actions, configuration changes and owned paths. Show a preview when the effects are nontrivial. Do not modify every detected host by default when the user selected one.

An installer should:

1. Resolve and validate the destination.
2. Detect an existing install and local modifications.
3. Verify prerequisites without hiding failure behind a fallback that changes dependencies.
4. Obtain and verify the intended release.
5. Build or unpack in a staging directory.
6. Validate the exact staged artifact.
7. Activate it using a bounded, recoverable operation.
8. Record an ownership manifest and installation receipt.
9. Verify discovery or provide a truthful next check.

Do not label installation successful solely because files were copied. Missing executables, unresolved templates, wrong permissions or an undiscovered skill can leave the user with a broken install.

## Ownership manifest

Record project identity, package version, source commit, target host/scope, installation root, owned files with hashes, generated configuration entries, created links, state schema and installation time. Keep secrets out of the receipt. Record whether a file was created, replaced with a saved predecessor, or already belonged to the user.

This manifest allows repeat installation, safe conflict detection and removal. It also makes installer effects reviewable. Never infer ownership solely from a familiar directory name.

## Stable and development channels

Define stable as a specific release policy. Do not clone a moving default branch and then call the result stable unless that exact commit meets the policy. If the updater can fall back from a release ref to `main`, expose that as a channel change requiring the appropriate authorization.

Pin the exact resolved revision in the receipt. A branch or mutable tag alone does not establish reproducibility. A release version should identify a single artifact set; do not replace bytes under the same version without an explicit correction process.

## Staged updates

For a runtime project, prefer immutable version directories and an activation pointer or equivalent switch. Stage and validate the new version before replacing the current one. Preserve a known-good artifact and its dependencies until the update is confirmed.

reference-project's Unix symlink strategy has useful ownership and convenience properties, but it points at a live checkout. Pulling that checkout can expose new payload bytes before all regeneration and setup complete. Its release stopping and fix-forward behavior are not the same as transactionally restoring every updated user. Use the [lifecycle audit](../audits/lifecycle-project.md) to understand that tradeoff before copying the approach.

## Migrations

Give state migration one deterministic owner. It should know current schema, target schema, ordered migration list, applied receipts, failure behavior and recovery path. Do not have both a prompt and an installer independently loop over migrations with different version bounds or state roots.

Make each migration idempotent or detect whether it has already completed. Write the success marker only after verified completion. Test interruption at meaningful boundaries. Back up state when reversal is not reliable, and explain whether rolling back code also supports the newer state schema.

An update that changes stored user data needs more care than replacing a Markdown file. If rollback is not possible, document forward recovery before release.

## Rollback and uninstall

A rollback should restore the package and a compatible state/dependency set, or clearly state its limits. A command that only changes an update channel does not necessarily restore already-installed bytes. Verify the post-rollback artifact and representative task.

Uninstall using the ownership manifest. Preserve modified user files and unrelated configuration. Remove shared parent directories only when they are empty and owned. Treat credentials, user-created outputs, logs and cache as separate categories with explicit retention decisions. Verify that hooks or background processes do not remain active unexpectedly.

## Required lifecycle scenarios

For projects with installers, test: first install; repeated install; custom destination; spaces and platform path rules; existing unrelated files; local edits; partial dependency failure; failed build; interrupted activation; failed migration; concurrent install/update; rollback; uninstall; and reinstall after removal.

Run on the operating systems you claim to support. A PowerShell script's existence is not proof that native Windows behavior was exercised. Publish unsupported cases rather than silently falling back to destructive behavior.

## Release evidence

Bind checks to the exact candidate tree and final artifact. Preserve checksums and, where relevant, signed provenance. Verify the merge or publication result after the operation; a successful request can still target the wrong revision or artifact. Keep release notes accurate about behavior changes, compatibility, migrations and known problems.

Sources: [reference-project lifecycle audit](../audits/lifecycle-project.md), [OpenAI distribution guidance](../sources/primary-sources.md#s03), [GitHub secure use](../sources/primary-sources.md#s21), and [SLSA provenance/verification](../sources/primary-sources.md#s24). The staged-update design is a recommendation, not an Agent Skills format requirement.

## Check every entrypoint that can change user state

Maintain a [lifecycle entrypoint matrix](../audits/lifecycle-entrypoints.md) covering setup, team initialization, upgrade, refresh or repair, migrations, rollback and uninstall. For each actual writer, record ownership tests, handling of local modifications, missing versus malformed configuration, backups, recovery, platform evidence and unreviewed branches. A well-tested main installer does not establish the same properties for a separate bootstrap helper.

A familiar folder name, a generic `VERSION` file or a nested `.git` directory cannot establish that all local material may be deleted. Before migration, verify project identity and preserve edited, untracked and local-only repository work. Treat a missing settings file as a creation case. Treat malformed or unreadable existing settings as a preservation case: stop without replacing the bytes, or use a deliberately authorized repair process with recovery evidence. Atomic rename protects publication of bytes; it does not preserve configuration meaning.

Test clean migration, local edits, untracked files, a foreign folder containing `VERSION`, malformed settings, missing settings and repeat installation with unrelated hooks. Preserve the matrix's distinction between performed tests and proposed tests. Record package version, runtime version, commit, artifact hash and state schema as separate fields; the preserved baseline uses package version `1.102.2` and runtime `VERSION` contents `1.102.2.0`.
