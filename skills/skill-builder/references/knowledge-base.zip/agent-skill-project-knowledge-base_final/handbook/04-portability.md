# 4. Codex-first portability to Claude Code and Grok

Facts in this chapter were checked on **November 22, 2026, America/Los_Angeles**. Product behavior changes. Re-check the linked primary documentation when shipping an adapter. No live host compatibility trial was performed for this knowledge base.

## Portable syntax does not guarantee portable behavior

The Agent Skills format standardizes the directory and instruction document. It does not make shell tools, approval policies, discovery paths, subagents, hooks, browser sessions, persistence or plugins identical across products. Separate format validation from host integration testing.

| Concern | Codex | Claude Code | Grok Build |
|---|---|---|---|
| Project discovery | Current docs use `.agents/skills`, walking toward repository root. | `.claude/skills`. | `.grok/skills`, walking toward repository root; also documents Claude resource discovery. |
| User discovery | `~/.agents/skills`. | `~/.claude/skills`. | `~/.grok/skills` and user `~/.agents/skills`; plugin/configured locations also exist. |
| Explicit invocation | `$name` or `/skills` in CLI/IDE; ChatGPT uses `@`. | `/name`. | User-visible skills appear as slash commands. |
| Product metadata | `agents/openai.yaml` for interface, invocation policy and tool dependencies. | Additional frontmatter for invocation, tools, context and hooks. | Additional frontmatter and plugin configuration; some accepted keys are ignored. |
| Implicit invocation control | `policy.allow_implicit_invocation` in OpenAI metadata. | `disable-model-invocation` in frontmatter. | `disable-model-invocation` in frontmatter. |
| `allowed-tools` | Do not assume a portable restriction or grant; use the actual Codex execution policy and validate the chosen integration. | Pre-approves listed tools for the invoking turn; it does not remove other tools. | Does not grant or restrict tools. |
| `user-invocable: false` | Do not transplant this Claude field as a Codex policy. | Hides direct user invocation while allowing model use. | Hides the skill from both the user and the model. |

Sources: [S03](../sources/primary-sources.md#s03), [S04](../sources/primary-sources.md#s04), [S05](../sources/primary-sources.md#s05). This table summarizes documentation, not tested equivalence. Other discovery roots and managed policies can apply.

## Recommended adapter boundary

Keep these in the portable core: task goal, accepted inputs, domain procedure, evidence requirements, output schema, safe failure behavior, and existing-authorization semantics.

Keep these in an adapter: discovery location, invocation syntax, resource-root resolution, concrete tool names, subagent lifecycle, approval interaction, platform shell differences, native hooks, product metadata and distribution packaging.

An adapter should declare capabilities with explicit values such as `supported`, `unsupported` and `untested`. Unknown must not mean supported. If a capability is necessary to the task, stop that branch with a useful explanation. If optional, continue and record the missing coverage. Do not substitute a weaker control while retaining the original claim.

## Capability contract example

The provided JSON template is a project-specific format, not a host configuration file. It tracks capabilities such as:

- `read_files`, `write_owned_files`, `run_local_process`.
- `structured_user_input`, `parallel_workers`, `wait_for_worker_completion`.
- `browser_isolated_profile`, `browser_authenticated_session`.
- `network_allowlist`, `filesystem_confinement`, `tool_permission_enforcement`.
- `durable_state`, `secret_storage`, `artifact_export`.

For each capability record the implementation, documented version range, tested version, test case IDs and failure behavior. A natural-language warning can be listed as an advisory measure, but it cannot satisfy a required OS sandbox capability.

## Grok means several different products

Grok Build documents native skills and Claude resource compatibility. Its own field table still describes semantic differences, so test the exact fields you use. Grok Bot has a separate skills/routines product contract. When using an xAI model through a function-calling API, your application supplies tool execution and control. These targets should have separate support rows. [S05–S07]

For a custom API host, implement a loader that validates trusted skill manifests, presents bounded discovery metadata, loads relevant instructions and resources, maps tool calls to scoped executors, records action outcomes, and keeps untrusted tool results separate from task authority. The model choosing a tool call does not by itself authorize execution.

## Host support tiers

Use these proposed labels in your README:

| Tier | Evidence required |
|---|---|
| Format compatible | Distributed files pass the selected format validator. |
| Discoverable | A named host version finds and invokes the installed artifact. |
| Functionally exercised | Shared representative tasks meet the same acceptance conditions. |
| Safety exercised | Allowed and denied actions are checked at actual enforcement boundaries. |
| Supported | Regression coverage, version limits, repair guidance and a maintainer commitment exist. |

These labels are independent claims. A project can be supported on Codex and format-compatible but untested on Grok Build. Publish that clearly. Avoid a “universal” badge based on successful YAML parsing.

## The minimum interoperability panel

Run the same fixture set on each advertised host: explicit invocation, implicit positive match, negative trigger, relative resource read from a different working directory, missing capability, denied action, malformed tool result, interrupted task, artifact verification and cleanup. If the project has scripts, also test supported OS/shell combinations.

Do not expect every host to perform identical tool calls. Compare the task outcome, authority boundary and evidence contract. Record host/model/runtime versions so a failure can be reproduced.

Sources: [primary source register](../sources/primary-sources.md), [standards memo](../audits/standards-and-skill-creator.md), and [reference-project host/lifecycle audit](../audits/lifecycle-project.md).

## Skill identity and behavior across time

Track three lifetimes separately: loaded instruction text, invocation-specific permission grants, and durable task state. A fresh discovery test does not establish that the task remains correct after a second user turn, compaction, re-invocation, source edits, disablement or worker handoff. The [dated documentation captures](../sources/host-documentation-register.json) preserve the source basis for this distinction. Host documentation is not a local compatibility result.

Add the four temporal and collision designs in the [evaluation kit](../evaluations/case-designs.json). Record the resolved source path or native artifact ID, the activated content hash when available, the host product and execution surface, relevant policy, exact version, and any uncertainty about what actually loaded. If the host does not expose the activated bytes, retain an explicit identity limitation rather than substituting the hash of the file you intended to load.

| Case family | Required observations | Passing boundary |
|---|---|---|
| Continuation and compaction | Second-turn behavior, retained task state, skill identity before and after compaction, permission lifetime, worker handoff. | Required controls survive, are restored from trusted artifacts, or cause an honest stop. |
| Re-invocation and source change | Same-content invocation, edited source, stale loaded copy, removal or disablement, already-attempted effects. | Documented refresh behavior is respected; repeated invocation does not duplicate effects. |
| Same-name activation | Identical names at different roots, actual chosen path, explicit selector and relevant namespace. | The receipt identifies which artifact governed the attempt; ambiguity remains visible. |
| Namespace and resource identity | Plugin namespace, reserved names, symlink target where supported, resource reads from another working directory. | Resources resolve to the intended artifact without granting broader authority. |

Use separate support axes for format, discovery, function, safety and maintenance commitment. Mixed outcomes such as format passed, discovery passed and safety blocked are valid records. Claim support only within the tested product, surface, version and policy scope. An ordinary skill cannot dictate the host's context-management algorithm; recovery requires the adapter and durable evidence as well as instructions.
