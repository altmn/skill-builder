# 5. Commands, scripts, resources, and state

## Choose code for deterministic work

Use a resource when it removes a repeated source of error: parsing structured input, normalizing paths, calculating values, validating schemas, generating standard artifacts, managing a process, or writing durable state. Keep judgment about task meaning in the instructions. Do not replace a clear procedure with a large framework unless the runtime needs it.

The Agent Skills script guidance discusses prerequisites and predictable noninteractive interfaces. reference-project demonstrates how a command can become a stable contract shared by many skills. It also shows the cost of maintaining many helpers and keeping their examples synchronized. [S19; runtime and lifecycle audits]

## A command contract

For each public command document:

| Element | Required decision |
|---|---|
| Purpose | The one outcome it owns. |
| Invocation | Executable, arguments, working-directory assumptions and runtime version. |
| Inputs | Types, encoding, maximum sizes, path roots and trust level. |
| Outputs | Human text or versioned machine schema; file creation and overwrite rules. |
| Effects | Files, processes, network destinations, account actions and costs. |
| Status | Exit codes and result states, including partial completion. |
| Time | Deadline, cancellation, retry policy and uncertain-outcome handling. |
| Recovery | How to inspect, resume, undo or clean only owned state. |

Provide `--help`. Use stdout for results and stderr for diagnostics. Do not unexpectedly prompt for a TTY during an agent run. A nonzero status should communicate failure unless a host protocol deliberately requires a different convention; in that case document and test the typed result envelope.

## Safe data transfer

Treat command text as code. Prefer structured tool arguments or a subprocess argument list without a shell. For multiline user-controlled content, write a private input file or pass data on stdin; avoid inserting it into shell source. JSON encoding is not shell escaping. Quoted heredocs still need delimiter-collision handling when their contents are arbitrary.

Validate filenames, URLs and identifiers before using them. Reject out-of-scope paths after resolving symlinks and parent directories according to the chosen file-access policy. Check destination ownership before overwrite or deletion. Escape diagnostic output so it cannot become terminal control input or a spreadsheet formula in an exported CSV.

For executable input formats, distinguish parsing from evaluation. A repository configuration file may run code, load plugins, source environment files, or start hooks. Inspect the actual execution chain before calling a “validator” on an untrusted checkout.

## Result states

Use an explicit result schema when multiple consumers depend on a command. A useful common set is:

- `passed`: the intended check completed and met its acceptance condition.
- `failed`: the check completed and found a violation.
- `blocked`: a prerequisite or policy prevented execution.
- `not_run`: intentionally not attempted, with a reason.
- `inconclusive`: execution occurred but evidence cannot establish the outcome.
- `not_applicable`: the condition does not apply, with a reason.

Separate execution status from domain verdict. A completed audit can find defects. A failed command does not prove the product is defective. An empty result is meaningful only when a successful complete search produced it.

## Identity, freshness and evidence

Bind reusable results to what was actually checked. Depending on the task, this can include repository revision, dirty-tree content, untracked input files, configuration, tool version, schema version and relevant environment choices. A branch name or sanitized directory slug is not a unique input identity.

Hashing proves byte identity, not correctness or authority. A result with a matching digest still needs a trustworthy producer, relevant check and valid interpretation. Invalidate evidence after a relevant change. Do not let a fixing run certify its own edited result without the required fresh verification.

Keep completed and attempted operations distinct. For a remote mutation that timed out, reconcile external state before retrying. Blind repetition can duplicate a post, payment, deployment or record even when the first response was lost.

## Filesystem and process discipline

Use unique private temporary directories. Avoid predictable shared `/tmp` filenames for sensitive or concurrent work. Record owned process identifiers together with enough identity to avoid killing an unrelated reused PID. A cancellation procedure should confirm termination where continued work could conflict with the next step.

Write durable files through a private temporary file on the same filesystem and atomic replacement when the platform supports it. Atomic visibility does not by itself establish power-loss durability; if you promise that property, address the platform's file and directory flush behavior and verify the relevant failure boundary. For multi-file changes, define a transaction or recovery journal. Preserve a valid previous state until the replacement has been verified. Do not advertise all-or-nothing behavior unless it holds across the actual boundary.

Resolve resource paths from the installed skill root, not the user's current directory. Test invocation from a path containing spaces and from a different repository. Keep runtime dependency installation explicit, locked and inspectable. An offline mode must not fetch packages silently.

## Retry and cache policy

Retry only a classified transient failure, with a bound and backoff where appropriate. Keep the original failure. Check idempotency and uncertain completion before repetition. Rate limits, authentication failure, malformed output and permission denial are different states, not reasons to run the same command forever.

A cache requires a key, validity condition, expiry or invalidation strategy, size bound and sensitive-data policy. Cache immutable source analysis more readily than mutable authorization or remote state. Report when a cached result was reused and which identity matched.

## Observable tests

Test a command at the boundary its users rely on: output files, exit status, JSON schema, changed state, preserved unrelated files, denied paths, cancellation and limits. A private function test may help local logic; it cannot replace the interface test when packaging or process behavior is the risk.

Sources: [S19](../sources/primary-sources.md#s19), [reference-project runtime audit](../audits/runtime-security-tests.md), [reference-project lifecycle audit](../audits/lifecycle-project.md), and [core audit](../audits/core-instructions.md). The command contract and result schema are proposed project conventions.

## Join command contracts to their owners

Use the [command catalog](../catalogs/command-catalog.md) as a concrete contract format. A public command needs a name and aliases, invocation surface, owner, input/output schema, effects and authority, errors, retry and timeout behavior, cleanup, supported platforms, callers and tests. An unknown field is a review gap; a filename under `bin/` is not proof of a public API. Keep internal helpers and retired interfaces explicitly classified.

For commands that capture subprocess output, declare `response_bytes`, `capture_bytes`, `execution_deadline`, `process_tree_cleanup` and `retention` separately. A post-exit read limit bounds the response; it does not impose a disk quota on the running child. Preserve per-stream truncation flags and exit/timeout status. Test a controlled noisy child, both streams, startup failure, cancellation and cleanup independently. If the contract promises descendant termination, observe the descendants; the parent's exit alone cannot establish it.
