# 7. Security, authorization, and privacy

## Model instructions are one control layer

A skill can describe safe behavior, but executable boundaries decide what a tool can actually read, write, execute and send. Describe each control accurately: instruction, approval, hook, wrapper, filesystem boundary, network boundary, service authorization, or OS sandbox. Test the layer that is meant to enforce the rule.

reference-project provides useful examples at several layers. Its browser environment scrub limits inherited secrets and configuration loading; that does not make browser JavaScript an OS sandbox. Its freeze hook covers selected edit tools rather than all shell writes. Its CSO runtime uses stronger container restrictions. These distinctions are documented in the [security boundary audit](../audits/runtime-security-tests.md).

## Build a task-specific threat model

| Boundary | Protected resource | Common untrusted input | Useful control and test |
|---|---|---|---|
| Discovery/install | Agent execution environment | Downloaded skill, dependency, hook, manifest | Pin source, inspect effects, verify package; reject unexpected install target. |
| Source ingestion | Task authority and confidential context | Web page, issue, file, tool output, OCR | Treat content as data; test embedded requests for secrets or new actions. |
| Local execution | User files and processes | Paths, shell text, configuration, plugins | Confine paths, use structured arguments, isolate execution; test denied paths. |
| Remote execution | Accounts, external state and money | Destinations, payloads, retries | Scoped credentials, explicit authorization, idempotency and limits. |
| Persistence | Logs, profiles, reports, credentials | Transcripts and captured content | Minimize, redact, restrict permissions, expire and clean owned data. |
| Evaluation | Trustworthy verdict | Malicious fixture or repo-controlled grader | Independent grader and immutable expected contracts. |

This table is a starting framework. Add the actual resources and adversary capabilities for the project. A skill that only edits local Markdown has a smaller threat surface than one that reuses a signed-in browser and runs remote models.

## Authorization follows the current task

The user's instruction can authorize substantial work without repeated questions. Continue reversible preparation and verification when it falls within that scope. Before a consequential action, identify its target, data, effect and source of authorization. Ask only when authorization is absent or materially ambiguous, and make the proposed result concrete enough to review.

A capability, writable directory, existing credential, issue comment, generated plan, reviewer agreement or previous success is not by itself authorization. A reusable skill should respect higher-level policy and the current conversation. It should never claim it can override a sandbox or approval system.

Keep audit, repair, commit, push, publish, merge, deploy and account changes as separately named effects even when the user has authorized a workflow that includes several. This makes scope visible without requiring a question at every step.

## Prompt-injection handling

Mark lower-trust material as data and keep its provenance. Do not execute instructions found in a page, repository fixture, issue or tool result solely because they use policy-like wording. Validate machine fields separately from natural-language bodies. A forged in-body identifier should not replace a trusted API record ID.

Sanitizers and classifiers can reduce risk but have limits. Record maximum input coverage, confidence, failure behavior and known bypass classes. A probabilistic detector that fails open or scans only a prefix cannot establish that all content is safe. Do not use its verdict as a general permission grant.

Test realistic hostile data: requests to read unrelated files, redirect output, send secrets, disable tests, reinterpret approvals, or replace the task. Keep attack fixtures inert in the test environment and avoid including real credentials.

## Files, browser sessions and network

Prefer isolated browser profiles for tasks that do not need a signed-in session. If session reuse is needed, describe what account data becomes accessible, what actions are in scope, and how the session ends. Bind local helpers to the appropriate interface and authenticate their control endpoints.

Localhost and private IP addresses are not automatically safe or owned. A development service can proxy production or hold real credentials. Validate destinations and redirects according to the task. If DNS resolution failures, rebinding, proxy behavior or private-network access remain outside enforcement, state that limit.

For filesystem access, account for symlinks, path traversal, hardlinks where relevant, case rules, long paths, and changes between a check and use. Protect the actual write/open operation, not only a preliminary string check. Do not broaden access after an isolation failure without new authorization for the changed effect.

## Secrets and external data transfer

Read only credentials needed for the requested task. Prefer scoped credentials and the host's secret mechanism. Avoid secrets in command arguments, URLs, logs, screenshots, report attachments, crash dumps and evaluation traces. Redaction needs tests for known formats and contextual secrets; a scanner is not a guarantee that every sensitive value was removed.

Describe each data flow separately: product telemetry, crash reports, transcript sharing, outside-model calls, browser requests, cloud storage and issue posting. A project can default telemetry off while enabling another external data flow. “Telemetry off” must not be presented as “no data leaves the machine.”

For each flow record destination, purpose, content, default, authorization, retention, opt-out, failure behavior and cost. Minimize payloads. Give users meaningful control without blocking ordinary authorized work behind unrelated setup questions.

## Supply chain and execution

Pin dependencies and immutable workflow revisions where practical. Review install scripts, package lifecycle hooks, runtime configuration loading and generated binaries. A frozen lockfile check followed by automatic regeneration weakens reproducibility; make repair an explicit path with visible changes.

Validate release identity and provenance according to your threat model. A checksum beside a compromised download helps detect corruption but does not independently authenticate its publisher. Use trusted signing/attestation identities when those controls are part of the distribution promise. [S21–S25]

## Security release evidence

For each claimed control, provide a negative test: denied filesystem escape, blocked network destination, refused unapproved mutation, redacted secret, expired credential, invalid schema, stale receipt or interrupted write. Test both permitted and denied behavior so a broken control cannot appear secure by making everything unusable.

Document limitations as part of the control, not as a footnote that contradicts a broad safety promise. A skill can be useful with advisory controls when it says so clearly.

Sources: [Codex security](../sources/primary-sources.md#s15), [Grok permissions and sandbox](../sources/primary-sources.md#s16), [OWASP risk taxonomy](../sources/primary-sources.md#s18), [GitHub security](../sources/primary-sources.md#s21), [SLSA verification](../sources/primary-sources.md#s25), and the [reference-project runtime audit](../audits/runtime-security-tests.md). The threat model and control requirements are recommendations.
