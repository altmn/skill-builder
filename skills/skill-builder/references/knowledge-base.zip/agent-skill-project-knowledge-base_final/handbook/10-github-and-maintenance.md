# 10. GitHub presentation, contribution, and maintenance

## README as a user contract

Lead with the concrete task, a short example and the expected output. A visitor should be able to decide whether the skill is useful before reading its architecture. Then show supported hosts with evidence levels, prerequisites, installation, permissions/data flows, limitations, removal and links to deeper documentation.

A useful README sequence is:

1. What the project does and who it helps.
2. One realistic input and output example.
3. Support matrix with tested versions and untested targets.
4. Inspectable quick start and the effects of installation.
5. Main workflows and how to invoke them.
6. Verification, safety and privacy boundaries.
7. Update, rollback and removal.
8. Evaluation results with methodology and caveats.
9. Contribution, security reporting, license and maintenance status.

Do not imply compatibility from a logo alone. Label screenshots with version/context when they could mislead. Keep animated demos short and provide a text equivalent. A static saved fixture does not prove that a live website still matches it.

## Claims and evidence

Distinguish observed data, measured estimates, user reports and aspirations. For benchmarks publish task set, baseline, exact versions, budgets, grading, attempts, exclusions and raw or redacted receipts. Report inconclusive or negative results. reference-project's README includes corrected evaluation claims and cases without a demonstrated improvement; that transparency is worth adopting.

Avoid universal performance ratios, adoption multipliers or statements about developer productivity based only on commit counts, lines changed or anecdotes. Those metrics can describe activity, but they do not establish individual impact, focus, effort or work quality.

## Contributing guide

Explain the source-of-truth files, generated files, local setup, quick checks, relevant expensive checks and PR expectations. Give commands that exist in the current package. Explain how to add a skill, resource, host adapter, test case and release note.

Use a concise PR template: problem, changed behavior, evidence, compatibility/side effects, and known limits. Request screenshots only when visual behavior changed. Avoid making every contributor perform a live website ritual for a nonvisual fix. Project-specific voice or governance rules can exist, but they should be labeled as local policy.

`AGENTS.md` should help an agent contribute safely: identify authoritative docs, build/test commands, source versus generated files, ownership constraints, and completion expectations. It should not silently expand the current user's authorization or instruct an agent to send messages, publish, or incur costs unrelated to the task.

## Security policy

State supported versions, how to report a sensitive issue, expected response process, disclosure expectations and the project's control limits. Do not promise a response time you cannot maintain. Provide an appropriate private route before telling reporters to post sensitive details publicly.

Treat security reports as input to investigate. A repository's own claim of safe operation is not a substitute for reviewing the implementation and evidence.

## CI and repository automation

Use least-privilege workflow permissions, immutable dependency references, protected publication credentials and clear trust boundaries between untrusted pull requests and release jobs. Pin third-party actions to full commit SHAs where supported; update them through a reviewable process. GitHub's newer workflow lockfiles have eligibility and scope limits, so check whether they fit your repository. [S21–S23]

For privileged events such as `pull_request_target`, review what code is checked out and executed, how contributor-controlled strings enter commands, and whether artifacts cross into a trusted job. The event name alone does not establish safety or danger. reference-project's audited workflows provide examples of carefully constrained metadata jobs, with the evidence in the lifecycle report.

Keep secrets out of forks and untrusted test runs. Treat caches and artifacts as possible cross-trust inputs. Protect release credentials and verify the exact artifact after build.

## Licensing and attribution

Choose a license intentionally and include it at repository level. Preserve notices for copied or adapted code, templates and instructions. Track third-party source, revision, license and modifications. Rewriting text does not automatically remove attribution obligations. This bundle retains reference-project's notices and license texts with its source excerpts.

Separate your original guidance from upstream material. Do not imply endorsement by OpenAI, Anthropic, xAI, Agent Skills maintainers or reference-project's author.

## Maintenance loop

Record real failures as small issues with reproduction, expected behavior, affected version and evidence. Fix the owning layer: code before prompt when the fault is deterministic, adapter when host semantics changed, documentation when the contract is inaccurate, and evaluation when the current panel missed a real risk.

Periodically re-check host documentation, dependency updates, dead links, unresolved placeholders, stale snippets, install effects, data flows and untested support claims. Use a risk-based schedule; do not claim that all future changes are covered by one audit.

Sources: [reference-project lifecycle audit](../audits/lifecycle-project.md), [secondary instruction audit](../audits/secondary-instructions.md), and [GitHub primary guidance](../sources/primary-sources.md#s21). README and maintenance structure are recommendations.

## Rebuild views and maintain evidence history

Keep authored handbook text, the canonical rule catalog and explicit manual review decisions as inputs. Generate consolidated readers, profile views, CSV exports, the catalog browser, validation records and release hashes from declared inputs. The [methods guide](../methods/README.md) owns the commands and dependency pins. A fresh checksum proves file identity; it cannot prove that a stale reader agrees with its canonical chapter.

The maintenance gate should validate schemas and local references, run the local regression suites, check source-range bounds, rebuild derived artifacts and compare them with the distributed files, and verify the manifest. Compare two clean builds for stable output. Exercise one controlled canonical edit to show that its expected derivatives change and unrelated ones remain stable. Keep rendered browser interaction as a separate gate and preserve the original blocked result as historical evidence.

For changing documentation retain a bounded supporting excerpt or a known upstream revision, its heading, capture date and a hash of the retained evidence. The [documentation register](../sources/host-documentation-register.json) states precisely what was captured and what remains uncaptured. For source updates record both commits, changed-path coverage, affected contracts and review disposition. A changed file does not establish a fixed finding. Add a resolution event with verification rather than overwriting history or transferring old passing receipts to new bytes.

Before public redistribution, confirm the terms for the knowledge base's own prose, tools and scaffolding separately from retained third-party licenses. An explicit unselected license state is a publication blocker, not an implied open license.
