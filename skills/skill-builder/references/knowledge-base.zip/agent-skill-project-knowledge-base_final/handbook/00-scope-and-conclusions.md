# Scope, conclusions, and how to use this knowledge base

## Main conclusion

Build skill projects around **explicit contracts, evidence, modular ownership and failure handling**. Keep a portable task core, test the required host adapters, and add only the runtime machinery the task needs. The preserved source research supplies detailed examples and counterexamples for these decisions. Copying a large suite's structure, language or policy would also copy unnecessary complexity and its documented inconsistencies.

For a Codex-first project, the recommended design has three parts:

| Part | Owns | Why it matters |
|---|---|---|
| Portable task contract | Trigger, outcome, inputs, workflow, authority, verification and failure behavior. | Keeps the useful expertise independent of a particular agent product. |
| Deterministic resources | Parsing, schemas, exact transformations, state/evidence and safe command interfaces. | Removes fragile mechanics from repeated model reasoning. |
| Host adapters | Discovery, invocation, paths, tools, permissions, hooks, subagents and metadata. | Makes differences explicit and testable instead of assuming compatibility. |

The handbook and templates implement that design. The detailed audits preserve evidence and counterexamples so the guidance can be revised when the benchmark or host products change.

## Snapshot and research sources

The audited reference-project snapshot is version **1.102.2**, commit [`ccd80de8ebdd7ca3384cc54bc138b53cd311a732`](../sources/source-reference.html?ref=reference%3Atree%2Fccd80de8ebdd7ca3384cc54bc138b53cd311a732), committed November 22, 2026, at 5:08:54 p.m. Pacific. The research date is **November 22, 2026, America/Los_Angeles**; execution timestamps can show November 23 UTC.

The comparison uses the public OpenAI skill-creator at commit `49f948faa9258a0c61caceaf225e179651397431` and 27 primary sources: Agent Skills, current OpenAI/Claude Code/xAI documentation, agent-evaluation research, GitHub security guidance, SLSA, OWASP, W3C and Tailscale. See the [source register](../sources/primary-sources.md). This is a snapshot analysis, not a claim about future repository changes.

## Exact coverage

| Scope | Count / evidence |
|---|---:|
| Tracked repository files | 5,375 |
| Tracked bytes, including link-target text | 91,218,525 |
| Decoded text lines | 1,177,821 |
| Skill entry-point templates | 65; all fully read |
| `SKILL.md` and `SKILL.md.tmpl` artifacts | 136 |
| Instruction-bearing files indexed | 380 |
| Instruction blocks indexed | 25,693 |
| Unique instruction-block hashes | 10,517 |
| Complete semantic file reads | 360 |
| Targeted semantic file reads | 112 |
| Additional exact-byte duplicate files covered | 50 |
| Structural-only file indexing | 4,838 |
| Binary metadata-only records | 14 |
| Tracked symlink metadata | 1 |

The depth categories sum to 5,375 unique paths. Each record states the evidence behind its classification. The source checkout was not modified.

**Coverage limitation:** this is a complete file inventory and instruction-block index, with deep semantic review of all canonical skill entry points, assigned conditional instructions, major shared generators, and selected runtime/security/lifecycle owners. It is not a claim that all 1.18 million lines received manual semantic analysis. Most of the 3,093 files under `test/` were structurally indexed, and every possible host/model rendering was not generated or executed. Instruction blocks have contextual review coverage, not fabricated individual approval verdicts.

This distinction matters when using the files for another audit. The ledger is designed to reveal remaining work, rather than hide it behind a percentage. See [catalog interpretation](../catalogs/README.md), [coverage-summary.json](../catalogs/coverage-summary.json), and the per-track records.

## What was executed

Source retrieval, inventory generation, report assembly and checks of these deliverables were executed. The public OpenAI minimal validator was loaded in isolation against temporary fixtures, reproducing three limitations. The original portable-format validator supplied here was tested on **37 cases, with zero skips**, on Linux using Python 3.12.14 and PyYAML 6.0.3. Its exact source hashes and output are in [the test receipt](../tools/test-results.json).

No reference-project setup, installer, upgrade, hooks, test suite, browser daemon, authenticated workflow, production action or paid evaluation was executed. Static findings therefore remain labeled as static. No live Codex, Claude Code or Grok Build compatibility test was performed for this knowledge base.

## The strongest patterns to adopt

### 1. Make evidence part of the workflow

reference-project frequently ties reviews to the actual input snapshot, records separate attempts, preserves incomplete coverage, and distinguishes a finished review from a clean result. It checks external state after consequential operations and separates runtime-tested evidence from target-controlled claims. Adopt this discipline for your skill's actual outputs. A statement that a file was saved is weaker than reading back the file and checking its contract. [Core](../audits/core-instructions.md); [runtime](../audits/runtime-security-tests.md); [lifecycle](../audits/lifecycle-project.md).

### 2. Give each contract one owner

Commands, route authorization, state paths, schemas, redaction and generated instructions have identifiable owners. Shared owners reduce drift when every consumer uses them. The benchmark also exposes what happens when a prompt and installer both own migration logic. Keep exact mechanics in code and make instructions call that owner. [Lifecycle](../audits/lifecycle-project.md); [shared macros](../audits/shared-macros.md).

### 3. Load detail when it is needed

Canonical templates, conditional sections and an instruction diet are useful ways to reduce repeated context. The best placement can be metadata, entry point, reference, command help or an actionable error. Small projects can use direct Markdown without reference-project's full rendering system. [Core](../audits/core-instructions.md); [OpenAI creator comparison](../audits/standards-and-skill-creator.md).

### 4. Test adverse paths and the quality of the tests

The benchmark has substantial work around malformed inputs, denied authority, stale receipts, process isolation, exact candidate evidence, grader independence, fixed panels and meaningful regression tests. The practical lesson is to test the contract and expected effects, rather than maximize test count or mirror implementation text. [Runtime](../audits/runtime-security-tests.md); [secondary instructions](../audits/secondary-instructions.md).

### 5. Preserve user work and distinguish action types

Ownership-aware install/removal, separate report-only modes, snapshot-bound worktrees and explicit persistence states are valuable. Keep audit, repair, commit, push, merge, publication and deployment effects visible while honoring authorization already present in the user's request. [Lifecycle](../audits/lifecycle-project.md); [core](../audits/core-instructions.md).

### 6. Publish limits and negative results

The README's correction of benchmark claims and disclosure of evaluations without demonstrated gains are useful examples. New projects should publish their panel, baseline, versions, attempts and uncertainty, including results that do not support improvement. [GitHub presentation audit](../audits/lifecycle-project.md).

## Concrete counterexamples to turn into audit checks

The following findings illustrate why the benchmark must be evaluated critically. They are not a complete vulnerability assessment. Exact sources and suggested checks appear in the detailed reports and [finding catalog](../catalogs/benchmark-findings.json).

| Observation | Evidence type | General rule to use |
|---|---|---|
| Installer and upgrade instructions both run migrations with different selection/failure rules. | Static source. | Give migrations one deterministic, version-bounded owner. |
| Frozen dependency installation can fall back to refreshing the lockfile. | Static source. | Make reproducibility failure visible; keep development repair separate. |
| Unix links expose a moving checkout; release rollback does not automatically restore already-updated clients. | Source and project documentation. | State activation/rollback semantics precisely; stage immutable runtime releases where needed. |
| A token preview masks only the final six characters, leaving the prefix visible. | Static source, no real token used. | Do not print secret-derived previews; test exact emitted bytes with synthetic canaries. |
| Memory setup can change an existing artifact-sharing setting from off to full. | Static source. | Distinguish unset from an explicit opt-out and preserve the latter. |
| Telemetry-off and outside-model/sync defaults are separate policies. | Static source. | Inventory every data flow; one switch does not describe all egress. |
| Freeze hooks mediate particular edit tools but do not confine shell writes. | Explicit source boundary. | Label accident guards accurately; test the real enforcement layer. |
| The spec execution workflow falls back to the current directory after isolated worktree creation fails. | Instruction source. | Do not silently widen execution scope after isolation failure. |
| A PR-body update is called race-safe while later overwriting a previously fetched body without a version precondition. | Static instruction flow. | Use concurrency control and a fresh preimage check for shared mutable artifacts. |
| A saved browser fixture is described as detecting future live HTML changes. | Instruction claim contradicted by test design. | Separate parser regression tests from live-site monitoring. |
| Generated design guidance uses an incorrect large-text contrast unit. | Source compared with W3C. | Verify domain thresholds against the actual standard and units. |
| Retrospective metrics infer active work, focus or impact from commit gaps, directories and lines changed. | Instruction and metric definitions. | Label activity measures accurately; do not make unsupported personnel conclusions. |

The accessibility example is specific: the source uses `18px+` for a large-text contrast exception; W3C's definition uses **18pt regular or 14pt bold**, not 18px regular. [W3C source](../sources/primary-sources.md#s26); [secondary audit](../audits/secondary-instructions.md).

## What to adapt or leave behind

Adapt multi-agent review, browser daemons, persistent memory, elaborate release controls, model overlays and generated instruction systems only when they solve a real problem. They bring useful capability and maintenance cost together.

Leave unsupported productivity/adoption ratios, promotional rituals, user scoring, arbitrary universal coverage claims and fixed diff-size risk thresholds out of a general skill standard. Numerical confidence and weighted review scores can be local heuristics, but they do not establish calibrated correctness or safety. A short authorization change can deserve more scrutiny than a large documentation diff.

Treat model-specific style assumptions as hypotheses to evaluate. Do not encode requests to reveal hidden reasoning; ask for concise explanations, evidence and conclusions. Keep user-facing output focused on the task and a useful decision.

## Current portability conclusion

The common skill format is a useful foundation. Host semantics still differ. Claude Code's `allowed-tools` pre-approves tools during the invoking turn; Grok Build documents that the same field grants or restricts nothing. Claude's `user-invocable: false` permits model use while hiding direct user invocation; Grok Build hides the skill from both. Codex provides optional OpenAI metadata and current `.agents/skills` discovery conventions. [Portability chapter](04-portability.md); [S03–S05](../sources/primary-sources.md).

Therefore publish evidence tiers: format-compatible, discoverable, functionally exercised, safety exercised and supported. A copied file or successful parse cannot establish all five. Keep Grok Build distinct from Grok Bot and an API/custom host.

## How to apply the bundle

For a **new skill**, start with the task brief and [creation-agent instructions](../templates/CREATE-PROJECT-INSTRUCTIONS.md). Choose the smallest architecture, edit the scaffold, instantiate relevant evaluation cases, and use the rules as a review checklist. Add secondary hosts after the portable contract and Codex path work.

For an **existing skill**, use the [audit-agent instructions](../templates/AUDIT-PROJECT-INSTRUCTIONS.md). Pin the source, inventory it, review unique instructions and sensitive execution owners, then fill evidence for applicable rules. Reuse the report and instruction worksheet formats. Keep repair and external publication within the actual requested scope.

The provided validator adds consistent structural checks, including current `compatibility` support, duplicate YAML rejection, directory/name agreement and constrained direct-resource paths. It reports what it does not check. It is one useful gate in the process, not a substitute for task evaluations or host security testing.

## Maintaining this knowledge base

Update a recommendation when new evidence changes it. Preserve the old source snapshot and its findings; do not silently rewrite a historical audit as if a later fix had existed then. Recheck product documentation when updating host adapters, and rerun relevant behavior panels when instructions, tools, models or runtime dependencies change.

Keep the distinction between standard, product behavior, benchmark observation and recommendation. That distinction lets this knowledge base remain useful beyond reference-project and beyond one generation of agent products.

## Apply the improved kit without losing the research

Use the [application profiles](../catalogs/application-profiles.md) to select proportionate controls from the existing 99-rule catalog. Use the [completed reference project](../examples/README.md) to see the task, resources, fixtures, evidence and audit connected. The original scaffolding remains available for other tasks.

The [approach catalog](../catalogs/approach-catalog.md) and [command catalog](../catalogs/command-catalog.md) join the existing source records, narrative audits, callers and limits. They are retrieval aids; an unreviewed implementation remains unreviewed. The [lifecycle entrypoint matrix](../audits/lifecycle-entrypoints.md) adds the team-initialization counterexamples without applying one helper's positive guarantees to another.

The [review follow-ups](../audits/review-followups.md) preserve the later source observation, outstanding semantic review and evidence limits. The baseline inventory and historical receipts retain their original identities. New local checks, captured documentation evidence and proposed host trials are separate evidence sets.
