# 6. Tests and evaluations that establish useful evidence

## Test three different things

**Structure** asks whether the package is well formed. **Resource tests** ask whether scripts and adapters implement their contracts. **Agent evaluations** ask whether the complete workflow improves task outcomes. Passing one does not imply passing the others.

The public OpenAI `quick_validate.py` examined in this audit accepted empty required values and directory/name mismatch, and rejected the current standard `compatibility` field. Those checks were reproduced locally against a pinned source. This demonstrates why a helper's success message must be interpreted according to its actual checks. See [the validator observations](../audits/skill-creator-validator-observations.json).

## A proportional test stack

| Layer | What to verify | Typical trigger |
|---|---|---|
| Package | YAML types, required fields, name/path relation, supported keys, links, assets, executable presence, secret/build debris exclusion. | Every payload change. |
| Generated artifact | No unresolved variables, stable output, correct host metadata, complete package manifest. | Source/adapter/generator changes. |
| Resource contract | Normal, boundary, malformed, denied and interrupted paths; observable outputs and state. | Relevant code change. |
| Discovery | Positive, negative, paraphrase, ambiguous and explicit opt-out prompts. | Description/scope changes. |
| Task | Actual artifacts or effects meet independent requirements. | Workflow/resource/host/model changes. |
| Safety | Hostile data, denied writes, secret redaction, scope expansion and unavailable controls. | Trust-boundary changes. |
| Lifecycle | Install, repeat install, update, failure recovery, rollback, uninstall, user-data preservation. | Installer/package/state changes. |
| Performance | Context, latency, resource use and paid cost against a baseline. | Relevant instruction/runtime changes. |

Do not make every spelling correction run a costly live-agent panel. Choose tests by changed contracts and risk. Required release gates still apply when their policy is explicit.

## Build cases from real tasks

Start with a small usable panel, then expand from actual failures. Each case should name its task, input fixtures, expected artifact or state, forbidden effects, allowed resources, environment reset and independent checks. Include a realistic user prompt, not only a synthetic one-line command.

Separate cases used during development from held-out cases used to assess generalization. Preserve original incidents as regression cases, with private data removed. Do not let repeated exposure to the panel teach the skill only the panel's wording.

The supplied evaluation templates cover normal tasks, missing prerequisites, prompt injection, interrupted publication, host semantic differences and lifecycle preservation. They are case designs, not recorded passing results.

## Compare against a real baseline

For a new skill compare `no skill` with `candidate skill`. For an edit compare `previous version`, `candidate version`, and, where useful, `no skill`. Use the same tasks, tool availability, model settings and budgets. A no-skill control must not inherit the skill's instructions through `AGENTS.md`, hooks, preloaded memory, copied prompts or a contaminated fixture.

Record baseline and candidate identities before evaluation. Predeclare acceptance conditions and exclusion rules. Changing the grader because the candidate failed is a methodology change, not a successful repair. A valid changed requirement may justify a new panel, but retain the earlier result and explain the change.

## Judge outcomes independently

Prefer deterministic checks for file format, computation, schema, state and security effects. Use model or human judgment for qualities that lack a reliable mechanical oracle. Calibrate subjective graders with examples and disagreements. When feasible, hide which result is the candidate.

Keep the grader outside attacker-controlled repository instructions and runtime. A malicious fixture should not rewrite its own test, evaluator or expected answer. Hashing an output only helps when the expected contract comes from an independent source.

A result that says “saved successfully” is not proof that the file exists. A screenshot can prove a visible state but may not prove backend persistence. A mocked API call can prove the client's request but not the deployed server's authorization. State exactly what each test establishes and what remains outside it.

## Repeated trials and uncertainty

Agent outcomes vary. Use paired comparisons on the same tasks and randomize or interleave execution order when conditions may drift. Report counts and denominators, the number of repetitions, infrastructure exclusions, and the sampling method. Keep variability across tasks distinct from repeated attempts on one task; many repetitions of a tiny fixed panel do not establish broad task coverage. For a binary outcome, a confidence interval can describe sampling uncertainty, but task selection and grader validity remain additional limitations.

Distinguish succeeding at least once across several tries from succeeding consistently across all tries. Do not report the best attempt as ordinary reliability. Do not silently retry failures until a green run appears. Use a predeclared retry policy for infrastructure faults and keep every attempt in the record.

If cost prevents a broad panel, say so and publish the narrower evidence. A few successful tasks are useful development feedback; they do not justify a universal success-rate claim.

## Safety and completeness gates

Track severe failures separately from average task quality. Unauthorized external actions, loss of user files, credential disclosure, bypassed isolation, and fabricated verification should block release when relevant to the supported capability. A low-risk advisory formatting issue should not have the same weight.

Use outcomes such as passed, failed, blocked, not run, inconclusive and not applicable. Do not equate unavailable providers with a clean review. Do not equate zero discovered tests with all tests passing. Bind release evidence to the exact package being released.

## Test quality and maintenance

Each new test should explain the observable contract it protects and a credible regression that would make it fail. Prefer extending an existing case table over copying an entire test. Keep exact-string tests when text is an actual protocol or prompt-byte contract; otherwise favor behavior.

For a regression, demonstrate failure before the fix when practical and retain the evidence. If historical reproduction is impossible, explain the limit instead of inventing a red run. Use integration tests at boundaries where mocks would conceal the defect.

Deletion deserves similar care: identify the test's protected behavior, a stronger replacement or obsolete requirement, callers and relevant history. Do not remove useful negative tests to improve an average or runtime headline.

## Evaluation receipt

Retain case ID, skill/package commit and hash, host/version, model/version or unknown, runtime/OS, input hashes, permissions, budget, attempts, timing, tool calls, usage/cost source, artifacts, grader version, outcome, omissions and redaction. An estimated cost must be labeled as estimated. Failure to capture usage is unknown, not zero.

Sources: [Agent Skills evaluations](../sources/primary-sources.md#s11), [description optimization](../sources/primary-sources.md#s12), [Anthropic agent evaluations](../sources/primary-sources.md#s13), [OpenAI evaluation guidance](../sources/primary-sources.md#s14), [reference-project runtime audit](../audits/runtime-security-tests.md), and [secondary instruction audit](../audits/secondary-instructions.md).

## Executable records and retained negative results

Use the [versioned evidence schemas](../schemas/README.md) and filled records in the [completed example](../examples/README.md) to connect case, fixture, reset procedure, independent checker, candidate/control identity, attempt and result. Validate structure before publishing a receipt. Schema validation does not prove that an outcome is true. Preserve unknown usage as unknown with a reason, and keep failed, blocked and excluded attempts in the accounting.

The [later-source review note](../audits/review-followups.md#observed-source-update) adds a case study in a secondary model judge that failed calibration and remained unscored. The planted-bug primary metric used a separate frozen rule-based scorer. That result applies to its recorded review task, models, exclusions and case set; it is not evidence about whole-pack development productivity. The upstream evaluation has not been independently rerun for this knowledge base.
