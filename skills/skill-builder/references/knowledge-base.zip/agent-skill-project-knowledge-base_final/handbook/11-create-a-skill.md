# 11. Playbook: create a new skill project

Use this procedure with the [creation-agent instructions](../templates/CREATE-PROJECT-INSTRUCTIONS.md) and [new-project checklist](../checklists/new-project.md). Start small; expand only where the task requires it.

## Phase 1 — Define the job from real examples

Collect two or three representative requests, the inputs available, what a good result looks like, and at least one failure or boundary case. If a workflow already succeeds manually, preserve its useful decisions and corrections. Avoid starting from a generic request to “write best practices” without domain evidence.

Write a one-page task brief: user, outcome, inputs, outputs, scope exclusions, effects, required capabilities and independent acceptance checks. Identify unknowns that block a meaningful decision. Proceed with safe defaults for reversible details; ask only for missing context that changes the task or authority.

Deliverable: a reviewable task contract and initial evaluation cases.

## Phase 2 — Choose project size and authority

Choose instruction-only, resource-assisted or suite/runtime. List local writes, network calls, account actions, paid work, background processes and persistent data. Decide which are part of the requested workflow and which need separate explicit invocation or authorization.

Write a small threat model. Identify untrusted inputs and where enforcement belongs. A pure writing skill may need only source/data boundaries and output verification; a deployment skill needs account, artifact and state-change controls.

Deliverable: architecture decision and effects table.

## Phase 3 — Build the portable core

Create one coherent entry point. Put selection terms in metadata, task invariants in the body, details in conditional references, and exact mechanics in scripts where justified. Use the template as a checklist, then remove empty or redundant sections.

For each important instruction identify condition, action, evidence, failure and authority. Make completion observable. Keep missing capability and partial completion explicit. Do not include host-specific tool grants in the portable source.

Deliverable: a draft `skills/<name>/SKILL.md` and only the resources it uses.

## Phase 4 — Implement resources and Codex integration

If resources are necessary, define their arguments, outputs, side effects, errors, timeouts and cleanup before coding. Validate inputs and avoid shell interpolation. Resolve resources relative to the installed skill root.

Add OpenAI metadata only for the features you use. Check current discovery and distribution guidance. Test the artifact from a clean, representative Codex environment rather than relying on privileged authoring context.

Deliverable: deterministic resources, their contract tests, and a documented primary-host integration.

## Phase 5 — Establish evidence

Run format/package checks. Exercise normal, boundary, denied, unavailable and interrupted cases. Verify actual artifacts and state, not the completion narrative. Compare task results with a no-skill baseline. For revisions, also compare the prior version.

Keep grader expectations outside the candidate's control. Record all attempts and infrastructure failures. Fix failures at their owning layer. Re-run the relevant panel after material changes, preserving previous results.

Deliverable: evaluation receipts and an honest support claim.

## Phase 6 — Add secondary hosts

Create a narrow Claude Code adapter and a separate Grok Build adapter. Translate semantics, not just field names. Run the shared interoperability panel, including `allowed-tools`, invocation visibility, resource paths and missing capabilities where applicable.

If live testing is unavailable, publish those targets as untested or format-compatible. Do not hold back the valid primary-host release solely to imply broader compatibility. Grok API/custom hosts need their own loader/executor contract.

Deliverable: host capability matrix with documentation and execution evidence separated.

## Phase 7 — Package and document

Build the smallest runtime package. Exclude caches, local credentials, transcripts, development fixtures and unused assets. Include applicable licenses and notices. If using generation, validate exact outputs and ensure source changes regenerate cleanly.

Write a README with a realistic example, install effects, support matrix, data flows, limits and removal. Provide contribution and security guidance proportionate to the project. Run all documented quick-start commands in a clean disposable environment when authorized and available.

Deliverable: candidate package, manifest, documentation and release notes.

## Phase 8 — Release with exact evidence

Check the [release checklist](../checklists/release.md). Resolve blockers, mark unavailable checks, and bind receipts to the candidate hash. Prepare publication material and execute only actions covered by current authorization. Verify the published artifact's identity after release.

If an external step cannot be completed, deliver the concrete package and exact remaining action. Do not report it published. A knowledge base or scaffold request alone does not authorize installing into the user's live agent directories or publishing a repository.

Deliverable: a versioned, inspectable release and a maintenance issue list.

## A practical first iteration

For a modest instruction skill, the first version can be one entry point, one reference, several meaningful task cases, a structural check, a README and a license. Add an installer only if copying or host packaging cannot meet the deployment need. Add a generator only after duplicated host content creates a real maintenance problem. Add a daemon only after measuring its benefit.

The goal is a useful, supportable contract. File count and process length are not quality targets.

Sources: [S08](../sources/primary-sources.md#s08), [S10](../sources/primary-sources.md#s10), [S11](../sources/primary-sources.md#s11), and all four reference-project audit tracks. This playbook is an original synthesis.

## A completed path through this playbook

Follow the [completed reference project](../examples/README.md) once before adapting the generic scaffold. Select its application profile and review each capability modifier. Run its documented local package, validator and fixture checks, then inspect the filled audit and evidence records. These local results do not establish measured benefit on an agent host. Use the separate host smoke recipes to record the exact activated artifact and preserve unexecuted recipes as untested.

For a no-skill comparison, use a separate clean discovery environment with no candidate entry point, plugin, cached instruction or inherited conversation. Hold the task inputs and outcome checks constant. Retain a neutral or negative comparison; a worked example is useful without a fabricated performance advantage.
