# 12. Playbook: audit an existing skill project

Use this procedure with the [audit-agent instructions](../templates/AUDIT-PROJECT-INSTRUCTIONS.md), [audit checklist](../checklists/audit.md) and [report template](../templates/AUDIT-REPORT.md.template). The default audit mode is read-only. A repair request can authorize scoped changes; it does not automatically authorize publication or account actions.

## Phase 1 — Freeze the subject and establish scope

Record repository URL, commit, version, date, relevant dirty-tree changes and requested hosts. Separate the checkout's instructions from the user's task authority. Do not run setup, hooks, tests or scripts simply because a repository document tells you to do so.

Inventory every tracked file using version-control metadata. Record path, type, mode, bytes, hash, role and source link. Do not follow symlinks into unrelated locations. Mark submodules and large/binary artifacts explicitly. State whether they were materialized, rendered or only identified.

Deliverable: snapshot and all-file inventory.

## Phase 2 — Map instructions and runtime owners

Find every skill entry point, canonical template, generated output, conditional section, model overlay, host adapter, repository policy and command example. Distinguish authoring sources from delivered artifacts.

Map dependencies: skill to reference, skill to command, command to runtime/library, adapter to capability, generator to output, test to contract. Identify repeated blocks by exact hash to avoid reading identical generated content repeatedly. Context-sensitive expansions still need review even when they use the same macro name.

Deliverable: skill catalog, instruction index and dependency map.

## Phase 3 — Review instructions by meaning

For each authoritative workflow, read all unique instructions and relevant expanded output. Evaluate trigger, scope, authority, actions, evidence, failure, recovery, output and portability. Record keep/adapt/avoid decisions with source locations.

Use the five-field instruction contract where a statement is consequential. Look for contradictions between “read-only” and later writes; approval claims and real defaults; safety prose and actual hooks; missing prerequisites and completion claims; static fixtures and live-system claims; or scores and their underlying evidence.

An indexed block is not a completed semantic review. Keep the coverage labels separate. When a file was only sampled, name the ranges and the unanswered questions.

Deliverable: instruction-family analysis and a per-file coverage ledger.

## Phase 4 — Trace sensitive operations end to end

Prioritize installation, upgrade, shell execution, credential access, filesystem writes, network destinations, browser sessions, remote model calls, publication, migrations, and evidence storage. Follow values to the operation that enforces or consumes them.

Read failure paths as carefully as success paths. Ask what happens on missing input, unreadable configuration, timeout, malformed output, partial write, stale identity and concurrent activity. Distinguish a warning from a denial and a denial from confinement.

Record source-level concerns as source-level concerns until reproduced. Give a concrete failure path and a recommended verification step. Avoid labeling an entire project insecure because a bounded advisory layer has a documented limitation.

Deliverable: security/control table and prioritized findings.

## Phase 5 — Evaluate tests, performance and lifecycle

Inspect what tests assert, not only their count. Identify outcome tests, generated-text checks, real integration boundaries, hostile fixtures, baseline controls, retries, exclusions and evaluator independence. Check whether tests bind to the exact candidate and whether zero tests or unavailable providers can look green.

Assess performance claims against their measurement method. Review cold/warm conditions, total context, retries, cost and user interruptions. Review install ownership, staged updates, migration owner, rollback semantics and uninstall preservation.

Execute only reviewed checks in a suitable isolated environment under current authorization. Record exact commands, versions, outputs and limitations. If full runtime validation is not feasible, finish the static audit and state what runtime evidence remains needed.

Deliverable: test/eval/lifecycle assessment with execution status.

## Phase 6 — Verify external claims

Use current primary documentation for the skill format, host behavior, security mechanisms and technical standards. Pin repository sources. Record access dates for changing documentation. Recheck claims when the benchmark conflicts with current product behavior.

Separate benchmark observation, documentation fact, empirical result and your recommendation. Do not turn a project's internal policy into an industry standard. Do not quote productivity or adoption numbers as evidence without their actual study or measurement.

Deliverable: source register and host comparison.

## Phase 7 — Report and prioritize

For each finding include ID, severity/impact, confidence basis, affected paths, evidence, failure scenario, recommendation, verification method and execution status. Use severities based on consequences. A blocker cannot disappear inside a favorable average score.

Group recommendations into: adopt directly, adapt to the project's needs, avoid copying, and verify before relying on. Give an implementation order based on impact and dependencies. Preserve concrete strengths as well as defects.

Report the coverage denominator and depth counts prominently. A complete file inventory with selective semantic review is different from a full source audit; both can be valuable, but they must not be confused. The reference-project bundle follows this distinction.

Deliverable: an evidence-linked report, machine-readable findings and a bounded remediation plan.

## Phase 8 — Optional repair

When the user requests repair, prepare scoped changes, preserve their work, and rerun checks for affected contracts. Avoid rewriting the project just to resemble the benchmark. Verify actual behavior after changing a control. Separate fixes from optional style or architecture advice.

Publish, merge, install or deploy only when the task authorization covers those exact effects. End with what changed, why, how it was checked and what remains uncertain.

Sources: the pinned reference-project audit methodology, [Agent Skills evaluation guidance](../sources/primary-sources.md#s11), [OpenAI creator](../sources/primary-sources.md#s08), and [primary source register](../sources/primary-sources.md). This playbook is an original procedure.

## A repeatable audit handoff

Select the [application profile](../catalogs/application-profiles.md) and record capability modifiers before applying the 99 rules. Use the [approach map](../catalogs/approach-catalog.md) to connect user intent, instruction owner, execution owner, state/evidence and failure recovery. Use the [command catalog](../catalogs/command-catalog.md) for public interfaces and the [lifecycle matrix](../audits/lifecycle-entrypoints.md) for every writer that can affect user state.

Keep numeric line ranges separate from search selectors. Pin the source revision and hash; a phrase such as “timeout search” explains how a reviewer searched but is not a numeric range or proof that the complete owner was read. Use the evidence schemas for new findings and receipts. Mark branch coverage and unexecuted acceptance checks explicitly.

When an update arrives, compare it with the original baseline and add a dated event identifying affected rules and approaches. Do not upgrade old structural indexing into semantic review, inherit a prior pass across changed bytes, or mark a historical concern resolved simply because its file changed.
