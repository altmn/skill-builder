# Validation records and their scope

This revision keeps the original evidence and adds separately identified current checks. The complete acceptance result is [artifact-validation.json](artifact-validation.json); [review-application.md](review-application.md) maps findings to implementation and limits, and [preservation-audit.json](preservation-audit.json) records retention checks.

## Current local evidence

| Evidence | Scope |
| --- | --- |
| [Current validator regression receipt](../tools/revision-test-results.json) | Repaired portable-format validator: 53 tests, zero skips; all original 37 retained. |
| [Markdown differential receipt](../tools/markdown-differential-results.json) | 57 named adversarial/control cases against Pandoc 3.1.11.1 CommonMark; no full-conformance claim. |
| [Immutable indexer receipt](../methods/test-results.json) | 12 Git-object/provenance tests, including dirty, staged and conflicted worktrees; no upstream source execution. |
| [Versioned evidence examples](../schemas/record-index.json) | Ten distributed records and templates; schema shape is distinct from evidentiary truth. |
| [Completed example receipt](../examples/manifest-inspector/local-test-results.json) | Ten local resource/package tests, no host-agent trial or no-skill comparison. |
| [Current artifact receipt](artifact-validation.json) | Record relationships, numeric bounds, local links, exact evidence hashes, generated drift, syntax, manifest hashes and requested local acceptance commands. |
| [Build contract receipt](build-contract-results.json) | Repeat builds, controlled canonical edits, stale-reader rejection, package exclusions and source-locator contracts. |
| [Source-reference script receipt](source-reference-script-results.json) | Eleven Node VM/stub-DOM cases for URL recovery, rejection and literal shell arguments; distinct from rendering. |
| [Browser validation receipt](browser-validation.json) | A separately recorded rendered-layout/interaction attempt; unavailable rendering remains blocked. |

Run [the documented build and checks](../methods/BUILD.md) to produce a new current result. Evidence identities are bound to exact files; code changes do not silently inherit an earlier pass.

## Preserved original evidence

The original artifact-validation result is retained as [history/original-artifact-validation.json](history/original-artifact-validation.json). It recorded unique inventory IDs, valid source line ranges, all 65 canonical entry-point review records, validator source hashes, 731 distinct pinned source references, 148 local Markdown links, HTML anchors, embedded catalog data and JavaScript syntax.

The original portable-format validator had **37 passing regression tests and zero skips**. Its complete receipt remains at [tools/test-results.json](../tools/test-results.json), with a historical copy at [history/original-validator-tests.json](history/original-validator-tests.json). Those results describe the original validator bytes, not the repaired code. They used temporary Linux fixtures and do not establish macOS/Windows behavior, live-host compatibility or reference-source runtime correctness.

### Original rendering limitation

During the original work, Chromium was present but the workspace rejected the process-singleton socket required to start it. The full browser layout/interaction check was therefore **blocked**, not passed. No permission escalation or weaker execution boundary was used to bypass that restriction. Responsive styles were inspected, anchors were checked and scripts were syntax-checked; those were narrower checks. That history remains unchanged even if a new environment can render this revision.

The full reader and catalog use no background network dependencies. Source selectors resolve through a local page, and a public source opens only when the reader selects the link. Complete Markdown and machine-readable alternatives remain available.

## Source and host execution boundaries

No historical reference program, installer, upgrade, hook, daemon, authenticated workflow or test suite was run while applying this review. Static preservation/capture concerns retain their conditional status. The public OpenAI helper probes, original validator tests, repaired tool tests, local sample tests and artifact checks are separate evidence sets.

The four added host cases and exact smoke recipes remain designs. Live Codex, Claude Code and Grok Build behavior, permission lifetime, model-agent benefit and the complete later source delta have not been inferred from local passes. Original-material public open reuse remains an owner license decision documented in [LICENSE.md](../LICENSE.md).
