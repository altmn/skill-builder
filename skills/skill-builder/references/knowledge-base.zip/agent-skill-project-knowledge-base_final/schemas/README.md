# Versioned evidence records

These JSON Schemas use Draft 2020-12 and describe project evidence records, not native host configuration. Version `2.0` replaces ambiguous flattened evidence with explicit identity and outcomes. The schemas validate structure; a conforming record can still contain a mistaken observation. Review the linked evidence before accepting a verdict.

| Record type | Schema | Filled example |
| --- | --- | --- |
| Host capability and independent support claims | [host-capabilities.schema.json](host-capabilities.schema.json) | [host-capabilities.json](../examples/records/host-capabilities.json) |
| Panel, attempts, controls, budgets and measurements | [evaluation-receipt.schema.json](evaluation-receipt.schema.json) | [evaluation-receipt.json](../examples/records/evaluation-receipt.json) |
| Owned files and installation effects | [install-manifest.schema.json](install-manifest.schema.json) | [install-manifest.json](../examples/records/install-manifest.json) |
| Finding, limits and later resolution events | [finding.schema.json](finding.schema.json) | [finding.json](../examples/records/finding.json) |
| Numeric source ranges and separate search selectors | [source-review.schema.json](source-review.schema.json) | [source-review.json](../examples/records/source-review.json) |
| Rule applicability, authority, verification and release effects | [rule-traceability.schema.json](rule-traceability.schema.json) | [rule-traceability.json](../examples/records/rule-traceability.json) |

[common.schema.json](common.schema.json) owns identity, target, evidence, measurement and source-location definitions. Capability names are extensible; a writing skill can declare only file reading and output capabilities. It need not add browser, installer, or secret-storage records. The legacy broad capability list is retained in the editable template so authors can see available dimensions and remove those they do not need.

## Validation

From the knowledge-base root, install the pinned [tool dependencies](../tools/requirements.txt) in an isolated environment, then run:

```sh
python tools/validate_records.py
python tools/validate_records.py --record examples/records/host-capabilities.json
python -m unittest discover -s tools/tests -p test_validate_records.py -v
```

The default command validates the four templates and every distributed filled evidence example named in [record-index.json](record-index.json). The registry is local and never downloads schemas. Inputs are capped at 4 MiB and duplicate JSON keys and nonfinite values are rejected. Unknown outcomes, missing required evidence for a pass, absent package identity for a pass, malformed timestamps, and invalid range types fail. Cross-field checks also reject reversed/out-of-bounds ranges, incomplete rule assessments, and an aggregate pass that hides a failing required check.

A host record separates `target` (product, surface, distribution, version, OS and policy), capability `availability`, the result of an actual `exercise`, five independent `claims`, and `maintenance`. A package may pass format checking while discovery remains `not_run` and safety is `blocked`. Only executed evidence can support an exercise pass. An ordinary capability claim does not enforce host permissions.

A measurement holds `value`, `unit`, `source`, and `missing_reason`. Unknown tokens, calls and cost use `null`, `unknown`, and a reason; they never become zero. A cost value's unit is a currency code. A count's unit is `tokens` or `calls`; elapsed time uses `seconds`. An estimated measurement remains labeled `estimated`. Templates intentionally contain incomplete identities and `not_run` outcomes and are valid records of that incomplete state.

## Migration from the original templates

The templates remain editable scaffolding. No existing field meaning was discarded:

| Earlier field or concept | Version 2.0 location |
| --- | --- |
| `host`, `host_version`, `platform`/`os` | `target.product`, `target.version`, `target.os`; surface, distribution and policy are now explicit. |
| `skill_commit`/`source_commit`, `package_sha256` | `artifact.source_commit`, `artifact.package_sha256`; activated source and its hash distinguish the artifact actually loaded. |
| Capability `status` | `availability` plus `exercise.outcome`; documented ranges and tested versions are separate. |
| One `support_tier` | Independent format/discovery/functional/safety/support outcomes and a maintenance commitment. |
| Free-form `attempts` | Concrete attempt IDs, condition, timestamps, identity, target, model, inputs, permissions, checks, evidence and usage. |
| `elapsed_seconds` | `elapsed.value`, with `unit: seconds` and a measurement source. |
| `usage.input_tokens`, `output_tokens`, `cost`, `currency`, `source` | Each metric has its own value/unit/source/missing reason; cost currency is its unit. |
| Top-level model, version, inputs and permissions | Recorded for each actual attempt so retries and comparison conditions cannot silently inherit the wrong identity. |
| `checks`, `artifacts`, `grader`, `omissions`, `redaction` | Retained with explicit types, evidence and grader identity. |
| Installer ownership, links, config, prior versions, state and rollback limits | Retained; operations and ownership have structured records and an explicit outcome. |
| Finding sources and verification | Source ranges use numeric start/end objects; search descriptions use `selectors`; verification has an explicit outcome/evidence/reason. |

Existing historical ledgers retain their dated source identities and are not rewritten into new verdicts merely to satisfy this format. Use a separate source-review record when adding new semantic review. Preserve an earlier finding when later work resolves it; append a resolution event and its evidence.
