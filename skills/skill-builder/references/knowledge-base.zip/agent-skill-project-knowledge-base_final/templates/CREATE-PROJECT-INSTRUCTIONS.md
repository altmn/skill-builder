# Instructions to give an agent: create a skill project

Use this document as a task brief with the knowledge-base folder available. It is not an installable skill and grants no additional tool or account authority.

## Request

Create an open-source skill project for the task I describe. Codex is the primary host. Support Claude Code and Grok Build through explicit adapters when their required capabilities are available. Use this knowledge base as evidence and a design checklist, not as a requirement to copy reference-project's size or product policies.

## Procedure

1. Read `handbook/01-design-principles.md`, `02-instruction-engineering.md`, `04-portability.md`, and `11-create-a-skill.md` from this bundle. Load other chapters when their capabilities apply.
2. Inspect supplied examples and existing authorized project files. Define outcome, inputs, output, scope, effects and acceptance conditions. Make safe reversible choices. Ask only for context that materially changes the task or authority.
3. Choose the smallest useful architecture. Start from `templates/minimal-project/`; remove unused sections. The `.template` suffixes mark scaffolding to edit before using. Do not install into live agent directories solely to create source files.
4. Keep portable logic independent of host metadata, tool names and permission semantics. Recheck current official host docs for changing behavior. Record documentation-supported versus executed compatibility.
5. Implement deterministic resources only where they earn their complexity. Define safe arguments, outputs, effects, errors, limits and cleanup. Inspect existing executable code before running it.
6. Create meaningful task cases and a clean no-skill baseline. Verify actual artifacts/state, denied actions and missing capabilities. Keep failures, exclusions and uncertainty visible.
7. Evaluate applicable rules in `catalogs/requirements.json`. Use `tools/validate_skill.py` only for its documented structural checks; a pass is not behavioral or security certification.
8. Prepare the complete candidate package, README, notices, evaluation evidence and support matrix. Review install/update/removal if present.
9. Execute publication, installation or external account changes only when the current task authorizes those effects. Otherwise deliver the concrete reviewable package and identify the remaining action.

## Report

Explain the outcome, why the structure fits the task, files created, exact checks performed, host support evidence, effects/data flows, and material remaining limits. Link the finished artifacts. Do not invent passing tests, empirical performance gains or universal compatibility.
