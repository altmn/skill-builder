# Template guide

These files are editable scaffolding. They are not installed skills, finished policies or native configuration unless explicitly described.

## Task instructions

- [CREATE-PROJECT-INSTRUCTIONS.md](CREATE-PROJECT-INSTRUCTIONS.md): give this to an agent with your task examples and this bundle.
- [AUDIT-PROJECT-INSTRUCTIONS.md](AUDIT-PROJECT-INSTRUCTIONS.md): give this to an agent with a repository URL or authorized checkout.

Both briefs preserve the current user's authority and require evidence. They do not authorize installation, publication, account changes or messages to others by themselves.

## Scaffolding

`minimal-project/` contains README, contribution instructions, repository `AGENTS.md`, security policy, changelog, notice, a portable `SKILL.md.template`, and optional `agents/openai.yaml.template`. Copy only what your project needs. Replace bracketed guidance, remove unused sections, choose an actual license, and remove `.template` only after editing. Keep the skill directory and its `name` consistent.

No full Claude/Grok permissions configuration is supplied because the correct grants and restrictions depend on the task. Use the host capability template and current official documentation to build that adapter explicitly.

## Records

- `AUDIT-REPORT.md.template`: evidence-linked audit with scope/depth and remediation.
- `INSTRUCTION-WORKSHEET.md.template`: condition, action, evidence, failure and authority review.
- `host-capabilities.json.template`: project-specific capability record, not a native host config.
- `evaluation-receipt.json.template`: actual attempt identity, outcomes, usage and limits.
- `install-manifest.json.template`: owned paths, configuration and recovery identity.
- `finding.json.template`: individual issue with evidence type and verification method.

The templates intentionally contain placeholders. The knowledge-base narrative does not depend on those placeholders being filled. The validator checks actual skill directories containing `SKILL.md`; it does not install or auto-convert this scaffolding.

## Validated evidence and a finished example

The four JSON templates now use schema version `2.0`. They are valid records of incomplete work with `not_run` outcomes, unknown usage and missing-identity explanations. Placeholder timestamps and labels are instructions to fill the record, not evidence that a trial occurred. Read [the schema guide](../schemas/README.md) for the complete field migration; all original concepts remain represented.

Separate format, discovery, functional, safety and support outcomes in the host record. Preserve target surface, distribution, OS, policy, documented capability ranges and tested versions. A shared format does not create shared permission semantics. Evaluation records bind attempts to a package, panel, actual inputs, budgets, control identity, checks, evidence and the reason for any missing measurement.

Run `python tools/validate_records.py` from the knowledge-base root to validate distributed templates and filled examples. Validation rejects structurally unsupported passes and malformed ranges; it cannot establish whether an observation is true.

The [completed manifest-inspector example](../examples/manifest-inspector/README.md) supplements this generic scaffolding with a harmless local task, actual skill, deterministic checker, fixtures, package build, local tests, filled audit and explicitly unrun host recipes. Select an [application profile](../catalogs/application-profiles.md) and record overrides with reasons before adapting it.
