# Approach catalog

This is a joining layer over the preserved research. The [machine-readable catalog](approach-catalog.json) retains owner commits, blobs, file hashes, ranges, callers, tests, adoption decisions and limits. The original per-file review depth is not upgraded by catalog membership. Source-relative aliases identify research examples; they are not instructions to install a particular framework.

## Read by task

| Slice | Approaches | End-to-end relationship | Unresolved boundary |
|---|---|---|---|
| Browser interaction | APP-001–APP-003 | Task instruction → command registry → dispatch/runtime → snapshot or subprocess → result and cleanup. | Snapshot freshness implementation, capture quota and descendant behavior need named checks. |
| Review and publication | APP-004–APP-006 | Review → frozen candidate → local/remote evidence → carry/refusal → publication receipt. | CI-evidence helpers and shard runner retain structural-only baseline coverage. |
| Installation and removal | APP-007–APP-009 | Selected target → ownership → initialization/settings → activation → retention-aware removal. | Team migration/settings negative preservation cases remain unexecuted. |
| Shared generation | APP-010 | Canonical inputs → temporary render → conformance/drift checks → activation. | Add generation only for real consumers; host behavior still needs execution. |

## Approach decisions

| ID | Approach | Adoption decision | Rules |
|---|---|---|
| APP-001 | Single command contract owner | adopt pattern | INS-008, CMD-001, ARC-004 |
| APP-002 | Fresh element references and actionable recovery | review implementation before copying | CMD-007, CMD-010, SEC-005 |
| APP-003 | Separate subprocess resource budgets | adopt contract with explicit limits | CMD-002, CMD-006, CMD-008, PERF-001 |
| APP-004 | Bind review and publication to a frozen candidate | adopt pattern | EVAL-011, CMD-010, LIFE-009, LIFE-012 |
| APP-005 | Explicit evidence equivalence and refusal | review implementation before copying | CMD-010, EVAL-011, LIFE-009 |
| APP-006 | Count executed cases and exclusions honestly | review implementation before copying | EVAL-006, EVAL-010, EVAL-014 |
| APP-007 | Per-entrypoint ownership-aware migration | adopt preservation contract not unsafe branch | LIFE-002, LIFE-006, CMD-004 |
| APP-008 | Shared settings editor with refusal and recovery | adopt pattern | INS-008, CMD-009, LIFE-002 |
| APP-009 | Ownership-based removal with explicit retention | adopt pattern | LIFE-008, CMD-004, CMD-008 |
| APP-010 | Canonical authored inputs and checked derivatives | adopt when multiple consumers need generation | ARC-004, OSS-003, LIFE-009 |

## APP-001: Single command contract owner

Keep dispatch and documented command names synchronized.

**Owners:** `browse/src/commands.ts` (full_semantic; 1–303).

**Evidence:** [audits/runtime-security-tests.md](../audits/runtime-security-tests.md); [audits/lifecycle-project.md](../audits/lifecycle-project.md); [catalogs/file-review.json](../catalogs/file-review.json).

**Callers and outputs:** browse/src/server.ts: dispatch consumes command metadata. Outputs: generated browser command reference.

**Tests:** `browse/test/commands.test.ts`. These are source leads, not executed results.

**Limits:** Generated tables do not validate every handwritten example. READ/WRITE/META labels do not by themselves establish authority.

## APP-002: Fresh element references and actionable recovery

Bind element handles to browser state and recover from stale references without replaying unsafe actions.

**Owners:** `browse/src/snapshot.ts` (structural_index; no additional numeric read range); `ARCHITECTURE.md` (targeted_semantic; 247–295, 445–457).

**Evidence:** supplied review F08/G10; [catalogs/file-review.json](../catalogs/file-review.json).

**Callers and outputs:** browse/src/cli.ts: snapshot and subsequent element commands share browser state. Outputs: snapshot and element reference identifiers.

**Tests:** `browse/test/snapshot.test.ts`. These are source leads, not executed results.

**Limits:** Snapshot implementation remains structurally indexed. Navigation invalidation and recovery prose are not verified control flow. A mutating action requires outcome reconciliation before retry.

## APP-003: Separate subprocess resource budgets

Make response, capture, deadline, cleanup and retention independently observable.

**Owners:** `browse/src/browser-skill-commands.ts` (targeted_semantic; 249–305, 342–380).

**Evidence:** [audits/runtime-security-tests.md#capture-storage-clarification](../audits/runtime-security-tests.md#capture-storage-clarification); [audits/review-followups.md#capture-and-process-evidence](../audits/review-followups.md#capture-and-process-evidence).

**Callers and outputs:** browse/src/browser-skill-commands.ts: skill run/test dispatch reaches file capture. Outputs: stdout/stderr responses, temporary capture files, timeout and truncation status.

**Tests:** `browse/test/browser-skill-commands.test.ts`. These are source leads, not executed results.

**Limits:** Post-exit read cap is not a capture-storage quota. Existing summary flag may omit stderr truncation. No controlled noisy-child or descendant experiment was run.

## APP-004: Bind review and publication to a frozen candidate

Preserve identity across review, tests, final mutation and publication.

**Owners:** `review/SKILL.md.tmpl` (full_semantic; 386–468); `ship/SKILL.md.tmpl` (full_semantic; 374–503).

**Evidence:** [audits/core-instructions.md](../audits/core-instructions.md); [audits/lifecycle-project.md](../audits/lifecycle-project.md).

**Callers and outputs:** ship/SKILL.md.tmpl: review/evidence gates precede push and publication. Outputs: review records, frozen candidate, publication receipt.

**Tests:** `test/ship-publication-gates.test.ts`, `test/ship-reentry-gates.test.ts`. These are source leads, not executed results.

**Limits:** Complete template reads do not prove all imported helper behavior. No network publication was executed.

## APP-005: Explicit evidence equivalence and refusal

Define when external CI evidence remains relevant and when fresh evidence is required.

**Owners:** `lib/run-evidence.ts` (structural_index; no additional numeric read range); `lib/ci-carry.ts` (structural_index; no additional numeric read range).

**Evidence:** [audits/review-followups.md#scoped-ci-evidence-equivalence](../audits/review-followups.md#scoped-ci-evidence-equivalence).

**Callers and outputs:** lib/pregate/run-check.ts: run evidence and carry decisions feed pre-publication gate. Outputs: verified run identity, carry/refusal result, compact receipt.

**Tests:** `test/run-evidence.test.ts`, `test/ci-carry.test.ts`. These are source leads, not executed results.

**Limits:** Baseline helpers remain structurally indexed. Later source has narrower reported parentage/own-diff conditions; old receipts cannot be inherited. Deployment merge-tree gate remains independent.

## APP-006: Count executed cases and exclusions honestly

Preserve attempts, exclusions, retries and missing summaries in test verdicts.

**Owners:** `scripts/test-free-shards.ts` (structural_index; no additional numeric read range).

**Evidence:** [audits/review-followups.md#three-traceable-slices](../audits/review-followups.md#three-traceable-slices).

**Callers and outputs:** package.json and CI workflows: test orchestration invokes shard runner. Outputs: shard plans, attempt logs, summary verdicts.

**Tests:** `test/test-free-shards.test.ts`, `test/test-free-shards-capture.test.ts`. These are source leads, not executed results.

**Limits:** Runner has 2,317 lines and remains structurally indexed. Test names are leads, not proof that selection/retry behavior is sound.

## APP-007: Per-entrypoint ownership-aware migration

Preserve local and foreign material wherever initialization, repair or migration changes state.

**Owners:** `setup` (targeted_semantic; 883–952); `bin/reference-project-team-init` (structural_index; 43–59, 196–232).

**Evidence:** [audits/lifecycle-entrypoints.md](../audits/lifecycle-entrypoints.md); [audits/lifecycle-project.md](../audits/lifecycle-project.md).

**Callers and outputs:** bin/reference-project-team-init: independent team bootstrap writes instructions, migration state and hook settings. Outputs: installed links/copies, project policy snippets, hook settings, ownership evidence.

**Tests:** `test/team-mode.test.ts`, `test/setup-link-ownership.test.ts`. These are source leads, not executed results.

**Limits:** Main setup protections do not cover the independent team writer. Generic VERSION/.git markers do not establish permission to discard local work. Negative preservation tests remain proposed.

## APP-008: Shared settings editor with refusal and recovery

Give settings parsing, identity checks and replacement one preservation-aware owner.

**Owners:** `bin/reference-project-settings-hook` (structural_index; 492–553).

**Evidence:** [audits/lifecycle-entrypoints.md](../audits/lifecycle-entrypoints.md).

**Callers and outputs:** setup and lifecycle settings callers: reuse dedicated writer instead of parsing/replacing independently. Outputs: updated settings, predecessor backup, change identity.

**Tests:** `test/team-mode.test.ts`. These are source leads, not executed results.

**Limits:** Reported targeted read does not verify all 1,329 lines. Atomic rename alone does not preserve malformed predecessor configuration.

## APP-009: Ownership-based removal with explicit retention

Remove owned integration while preserving unrelated work and declared user state.

**Owners:** `bin/reference-project-uninstall` (targeted_semantic; 1–30); `docs/uninstall.md` (targeted_semantic; no additional numeric read range).

**Evidence:** [audits/lifecycle-project.md](../audits/lifecycle-project.md); [audits/lifecycle-entrypoints.md](../audits/lifecycle-entrypoints.md).

**Callers and outputs:** documented uninstall command: human or authorized agent invokes removal for a declared install. Outputs: removed owned integrations, retained state, removal summary.

**Tests:** `test/uninstall.test.ts`, `test/uninstall-windows-copies.test.ts`. These are source leads, not executed results.

**Limits:** Force options change effects and require precise scope. Native platform execution was not performed. Project instruction cleanup is separate.

## APP-010: Canonical authored inputs and checked derivatives

Keep generated host artifacts and readers synchronized without overwriting reviewer decisions.

**Owners:** `scripts/gen-skill-docs.ts` (targeted_semantic; no additional numeric read range); `scripts/skill-check.ts` (full_semantic; 1–202).

**Evidence:** [audits/lifecycle-project.md](../audits/lifecycle-project.md); [methods/README.md](../methods/README.md).

**Callers and outputs:** contribution and release workflow: temporary render and conformance checks precede activation. Outputs: host skill files, generated command references, drift diagnostics.

**Tests:** `test/skill-check-driver.test.ts`. These are source leads, not executed results.

**Limits:** Generation is optional for a small instruction skill. A structural conformance pass is not a live host pass.

## Source changes remain historical events

The [update record](approach-catalog.json) preserves baseline and later commit identities, reported delta counts, named affected approaches/rules and an explicit incomplete changed-path inventory. Read the [update narrative](../audits/review-followups.md#observed-source-update) for the CI-carry and failed-calibration examples. No old pass transfers to the new source.
