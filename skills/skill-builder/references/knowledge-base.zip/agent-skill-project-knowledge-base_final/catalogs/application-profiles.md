# Apply the rule catalog in proportion to the project

The [99-rule catalog](requirements.json) remains the only owner of rule statements, authority labels, strengths and verification descriptions. [application-profiles.json](application-profiles.json) selects its IDs. A profile is a proposed local policy, not an industry certification. Selecting a project-policy rule does not turn it into a format-specification requirement.

| Profile ID | Starting scope | Additional controls |
| --- | --- | --- |
| `instruction` | Instructions and optional prose references | Format, task boundaries, authority, honest evidence and proportional task/discovery checks; no bundled executable, daemon or migration gate is assumed. |
| `resource_assisted` | Instructions plus scripts or structured resources | Input/output contracts, command errors and limits, safe argument handling, resource-path behavior and deterministic resource tests. |
| `suite_runtime` | Coordinated components or a persistent runtime | Generation, handoffs, worker ownership, caches, process lifecycle and broader runtime evidence. |

Select capability modifiers `network`, `publication`, `persistent_state`, `authenticated_browser`, and `installer` whenever those effects exist. They add controls; they do not silently relax the base profile. A local writing skill is not assigned daemon or migration gates. A script-bearing skill receives command and execution controls. Selecting `publication` adopts `LIFE-012`, the rule requiring current authority for publication.

## Generate a view

From the knowledge-base root:

```sh
python tools/profile_view.py --profile instruction
python tools/profile_view.py --profile resource_assisted --modifier publication
python tools/profile_view.py --profile suite_runtime --modifier network --modifier installer
```

The command reads both canonical files, joins each of the 99 rules exactly once, and writes a reviewable JSON view to stdout. It does not write to the source catalog. Re-run it after a rule edit; copying its output into a second manually maintained rule list would introduce drift.

A selection is not verification. `adopted` means the rule belongs in the project's assessment. `not_applicable` means the selected declared scope lacks that capability. Confirm the scope is accurate before accepting that decision. `not_assessed` keeps specialized mechanisms such as subjective graders or worker handoffs visible until reviewed. This is different from an explicit reasoned exclusion.

Override a default through a JSON file whose keys are rule IDs, each holding `decision` and a concrete `reason`. Use `--overrides path/to/overrides.json`. The generator requires at least 20 characters for an override explanation; length is a structural check, not evidence that the explanation is sound. A reviewer still decides whether the claimed absence or alternative control is credible.

## Record the assessment

The [traceability schema](../schemas/rule-traceability.schema.json) requires a decision for every canonical rule. Each adopted rule records a failure scenario, source IDs, the canonical authority basis, automated/manual verification, evidence and a release consequence. The [completed example](../examples/records/rule-traceability.json) assesses the manifest-inspector scope and keeps unavailable host outcomes unrun.

Keep a failing mandatory gate separate from a recommendation. A local policy may choose a different release consequence with an explicit reason. A publishing project cannot hide publication authorization behind a default nonapplicable label: the validator requires an explicit reviewable override. A schema can enforce that the explanation exists; it cannot approve the underlying action.

Sources: [design principles](../handbook/01-design-principles.md), [audit checklist](../checklists/audit.md), and the canonical `basis`, `strength`, `applicability`, and `verification` fields in [requirements.json](requirements.json).
