# Command catalog

The [machine-readable command map](command-catalog.json) records owners, argument/output contracts, effects, authority, errors, retry/timeouts, cleanup, platforms, callers and tests. It distinguishes public executable families, host skill invocations, internal maintenance helpers and the local validator. Unknown fields remain review gaps. Source aliases in research examples are not runnable installed names.

This is a selected map for three audit slices, not a complete command reference. The pinned source has 210 `bin/` files, 58 package scripts and two package executable entries. Those categories overlap and are not a public-API count.

| ID | Interface | Classification | Owner |
|---|---|---|---|
| CMDMAP-001 | `browse <command> [arguments]` | public command family | `browse/src/cli.ts`, `browse/src/commands.ts` |
| CMDMAP-002 | `browse snapshot [options]` | public subcommand | `browse/src/snapshot.ts` |
| CMDMAP-003 | `browse skill run / skill test` | public subcommand family | `browse/src/browser-skill-commands.ts` |
| CMDMAP-004 | `review` | public skill invocation | `review/SKILL.md.tmpl` |
| CMDMAP-005 | `ship` | public skill invocation | `ship/SKILL.md.tmpl` |
| CMDMAP-006 | `setup --status` | public read only mode | `setup` |
| CMDMAP-007 | `setup [host/scope options]` | public command | `setup` |
| CMDMAP-008 | `reference-project-team-init optional\|required` | public command | `bin/reference-project-team-init` |
| CMDMAP-009 | `reference-project-settings-hook <verb> [options]` | internal maintenance helper | `bin/reference-project-settings-hook` |
| CMDMAP-010 | `reference-project-uninstall [options]` | public command | `bin/reference-project-uninstall`, `docs/uninstall.md` |
| CMDMAP-011 | `python3 -B tools/validate_skill.py SKILL_DIR [SKILL_DIR ...]` | public local knowledge base tool | `tools/validate_skill.py` |

## CMDMAP-001: browse <command> [arguments]

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Command names/aliases are centralized in commands.ts; command-specific arguments must be checked against that pinned registry and handler. |
| Outputs | Command result or actionable command/argument error; each command has its own payload. This record does not invent a unified schema. |
| Authority | Classify actual operation and session scope; READ/WRITE/META grouping is not an authorization boundary. |
| Errors | Unknown command and invalid arguments have registry/handler diagnostics; source names are indexed. |
| Retry | Do not retry a mutation after ambiguous completion without inspecting state. |
| Timeout | Startup readiness and command deadlines are distinct; exact per-command values require pinned source inspection. |
| Cleanup | Daemon ownership, health and teardown require their own lifecycle policy. |
| Platforms | No native platform was exercised for this source map. |

**Effects:** browser process/session; page reads and browser mutations according to subcommand; possible external network traffic.

**Callers:** browse skill and browser-using workflows; exact caller list is non-exhaustive.

**Tests:** `browse/test/commands.test.ts`, `browse/test/command-timeout-report.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-001, APP-002.

A command-family record is not a count of public subcommands.

## CMDMAP-002: browse snapshot [options]

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Snapshot options are parsed by parseSnapshotArgs; exact option grammar remains a structural review lead. |
| Outputs | Snapshot with element-reference identifiers, as described in architecture. |
| Authority | Use the declared browser/profile authority; content does not supply task authorization. |
| Errors | Architecture describes stale-reference recovery; complete handler/error semantics not verified. |
| Retry | Refresh state before using a stale reference; reconcile prior mutation before retrying it. |
| Timeout | Per-command deadline is not established by the snapshot inventory. |
| Cleanup | Reference invalidation and retention implementation still require semantic review. |
| Platforms | No platform trial. |

**Effects:** reads active browser state; creates/replaces reference mapping.

**Callers:** browse CLI/dispatch; downstream element commands consume references.

**Tests:** `browse/test/snapshot.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-002.

Baseline snapshot owner remains structural; no recommendation to copy its implementation as verified.

## CMDMAP-003: browse skill run / skill test

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Skill-run options reach parseSkillRunArgs/spawnSkill; use the pinned parser for exact executable and argument syntax. |
| Outputs | Exit/timeout result plus stdout/stderr capped after file capture; truncation interpretation has a separate reported defect. |
| Authority | Environment filtering and per-run token scopes do not establish an OS sandbox. |
| Errors | Startup/timeout/child failure and truncated output must remain distinguishable; exact schema not revalidated. |
| Retry | No blind retry of child work that could have external effects. |
| Timeout | Execution deadline is separate from read cap; capture byte quota is not established by this code path. |
| Cleanup | Temporary capture cleanup is inspected statically; descendant termination requires separate execution evidence. |
| Platforms | No native platform trial. |

**Effects:** spawns subprocess; temporary stdout/stderr capture; per-run token/environment construction; child effects within actual host authority.

**Callers:** browser-skill command dispatch.

**Tests:** `browse/test/browser-skill-commands.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-003.

## CMDMAP-004: review

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Host-specific skill invocation against a selected branch/diff; exact host syntax belongs to the adapter. |
| Outputs | Prioritized findings, permitted fixes and a final review record tied to the resulting input. |
| Authority | Review and fixing authority are separate; current user authorization governs allowed changes. |
| Errors | Missing evidence and unresolved findings remain visible; edits require renewed review. |
| Retry | Re-review after content changes rather than reusing an old clean result. |
| Timeout | No single workflow deadline was established. |
| Cleanup | Preserve evidence of attempted/finished work; no generic cleanup guarantee inferred. |
| Platforms | Canonical template read does not establish generated-host execution. |

**Effects:** reads repository; may edit according to existing authorization and classification; writes review evidence.

**Callers:** explicit host invocation; ship review stages.

**Tests:** `test/ship-rereview-triggers.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-004.

## CMDMAP-005: ship

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Host-specific workflow invocation against repository and candidate state; task/host arguments follow the canonical template. |
| Outputs | Frozen candidate, test/review gate state and publication receipt with incomplete paths visible. |
| Authority | Publication must remain within current user authorization; a prior review pass is not publication authority. |
| Errors | Unmet gates and incomplete checks cannot become a successful release receipt. |
| Retry | Reconcile remote state and preserve invocation identity before retrying publication. |
| Timeout | No workflow-wide deadline verified; individual helper deadlines remain separate. |
| Cleanup | Finish writers before freezing candidate; record pending effects. |
| Platforms | No live host or remote publication executed. |

**Effects:** local repository changes; possible remote push/PR publication; persistent evidence.

**Callers:** explicit host invocation; release workflow.

**Tests:** `test/ship-publication-gates.test.ts`, `test/ship-reentry-gates.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-004, APP-005, APP-006.

## CMDMAP-006: setup --status

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | --status inspects registered installs; help/status paths are documented separately from mutation. |
| Outputs | Read-only installation/discovery diagnostics; do not infer a completed installation. |
| Authority | Read-only inspection within available filesystem access. |
| Errors | Exact diagnostic schema/exit matrix not revalidated. |
| Retry | Repeat reads only; no mutation retry implied. |
| Timeout | No overall status deadline established. |
| Cleanup | No build or installation writes are intended on this mode. |
| Platforms | Native behavior untested. |

**Effects:** reads registration and installation state.

**Callers:** user status checks; installation diagnostics.

**Tests:** `test/setup-install-registry.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-007.

## CMDMAP-007: setup [host/scope options]

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Declared host, user/project scope and install settings. Exact option grammar is owned by setup, not this abbreviated map. |
| Outputs | Rendered/installed artifacts, registry entries and installation summary. |
| Authority | Install only selected target/scope and preserve unowned material; dependency repair is a separate effect. |
| Errors | Frozen dependency fallback and nontransactional Unix activation are documented concerns. |
| Retry | Full repeat/concurrent repair behavior requires owner-specific tests. |
| Timeout | A global installation deadline is not established. |
| Cleanup | Owned-copy backups and staged Windows replacement are observed; full Unix transaction rollback is not. |
| Platforms | No OS execution claims made. |

**Effects:** dependency/build processes; host skill files and links; configuration and installation state.

**Callers:** installer instructions; registered refresh/repair.

**Tests:** `test/setup-link-ownership.test.ts`, `test/setup-install-registry.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-007, APP-008, APP-010.

## CMDMAP-008: reference-project-team-init optional|required

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | One mode: optional suggestion or required integration; run from team repository root. |
| Outputs | Project instruction/bootstrap changes and, for required mode, enforcement-hook settings. |
| Authority | Generic VERSION/.git detection does not prove owned disposable contents; explicit migration scope is needed. |
| Errors | Malformed/unreadable existing settings can take empty-object fallback; preservation concern recorded. |
| Retry | Idempotence is not established for local-edit/foreign-folder adverse cases. |
| Timeout | No bounded overall runtime verified. |
| Cleanup | No verified predecessor preservation in reported vendored/settings branches. |
| Platforms | No platform execution performed. |

**Effects:** may remove detected vendored folder; changes Git index/ignore state; writes project instructions/settings.

**Callers:** team-mode setup instructions.

**Tests:** `test/team-mode.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-007, APP-008.

See F03-A/F03-B in lifecycle-entrypoints.md; source inspection only.

## CMDMAP-009: reference-project-settings-hook <verb> [options]

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Documented verbs include add/remove, add-event, ensure-event, remove-source, diff-event, rollback, list-sources, list-items and prune-stale; host format changes accepted verbs. |
| Outputs | Settings changes or read-only inspection according to verb; list-items is documented as one JSON string literal per matching command. |
| Authority | Use a single settings owner; read-only and mutating verbs have different authority. |
| Errors | Targeted reader refuses malformed/unreadable settings and preserves identity/modes; full branch graph not reviewed. |
| Retry | Full per-verb retry/idempotence contract remains unverified. |
| Timeout | Per-verb timeout flags do not establish helper-wide bounded completion. |
| Cleanup | Backup/change identity and modes are preserved in reported writer path. |
| Platforms | Host-format differences documented; no native trials. |

**Effects:** may read/write settings; may create/restore backups; may remove owned hook entries.

**Callers:** setup and maintenance callers; complete caller inventory unverified.

**Tests:** `test/team-mode.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-008.

Internal helper classification is for this research map; do not infer every listed verb is a stable external API.

## CMDMAP-010: reference-project-uninstall [options]

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | Default interactive removal; --force, --keep-state and --force-worktrees change behavior and must not be conflated. |
| Outputs | Removal/retention summary; source header documents exit 2 on unsafe-worktree/state-root refusals. |
| Authority | Preserve unrelated and modified work according to the selected options; destructive overrides require covered authority. |
| Errors | Unreadable ownership/worktree state or locked worktrees can stop before removal; complete branch coverage remains targeted. |
| Retry | Full repeated removal behavior not executed. |
| Timeout | No overall deadline verified. |
| Cleanup | Ownership and explicit retained-state categories guide removal; project policy text cleanup is separate. |
| Platforms | Native Windows/macOS trials not run. |

**Effects:** removes owned host integrations; may remove selected state; may stop owned browser daemons.

**Callers:** documented removal workflow.

**Tests:** `test/uninstall.test.ts`, `test/uninstall-windows-copies.test.ts`. Source test leads do not imply execution.

**Approaches:** APP-009.

## CMDMAP-011: python3 -B tools/validate_skill.py SKILL_DIR [SKILL_DIR ...]

| Contract | Recorded behavior / limit |
|---|---|
| Arguments | One or more explicit directories containing SKILL.md; --compact and --help are documented. |
| Outputs | JSON report on stdout with checks, warnings and not_checked; no helper execution or URL fetching. |
| Authority | Inspection only; a pass does not authorize skill execution. |
| Errors | Exit 0 all selected directories pass implemented checks; 1 any validation failure; 2 misuse, missing dependency or unexpected failure. |
| Retry | Repeat after an intended file fix; preserve report identity. |
| Timeout | Size/depth/link bounds are documented; no process deadline claimed. |
| Cleanup | Validator creates no payload state; temporary test fixtures are removed by test harness. |
| Platforms | Python 3.10+; tested platforms and skipped symlinks must be read from the current receipt. |

**Effects:** reads selected local metadata/resources; no payload writes.

**Callers:** package authors; local structural gate.

**Tests:** `tools/tests/test_validate_skill.py`. Source test leads do not imply execution.

**Approaches:** APP-001, APP-010.

Current implementation/Markdown limits are owned by tools/README.md; this entry does not widen them.

## Internal and retired interfaces

The settings helper is separately classified because a maintenance entrypoint need not be a supported public API. Retired names are owned by the pinned `scripts/discover-skills.ts` registry, with `test/retired-commands.test.ts` as a source lead; the complete retired list has not been semantically enumerated here. Resolve it before defining aliases. Do not infer API status from directory placement.

See the [approach map](approach-catalog.md), [lifecycle entrypoint matrix](../audits/lifecycle-entrypoints.md), [runtime audit](../audits/runtime-security-tests.md) and [tool guide](../tools/README.md).
