# Catalogs, coverage, and interpretation

## Files

`file-review.json` and `file-review.csv` contain one record for every one of the **5,375 tracked paths** in the pinned reference-project snapshot. Fields include role, mode, bytes, line count, SHA-256, source permalink, coverage, observations, structural signals and review evidence. The JSON retains details that are compressed into cells in the CSV.

Coverage labels mean:

| Label | Meaning |
|---|---|
| `full_semantic` | The complete text was read and considered in context. This is not proof of all runtime paths. |
| `targeted_semantic` | Specified ranges or a specific owner contract were read. The remainder is not credited as a full read. |
| `same_content_reviewed` | Exact file bytes match a fully read source. This avoids claiming an additional independent read. |
| `structural_index` | Full text was hashed/classified and scanned for headings, symbols, tests and topics; it was not all interpreted line by line. |
| `binary_metadata_only` | Identified and hashed; content was not rendered or otherwise validated. |
| `symlink_metadata` | The tracked link target was recorded without following it. |

The repository has one tracked symlink alias, `connect-chrome`, pointing to `open-reference-project-browser`. It is not a submodule. Runtime dependencies outside the tracked snapshot are not included in these counts.

## Instructions

`instruction-review.jsonl` and `.csv` index **25,693 Markdown blocks** across **380 instruction-bearing files**, with **10,517 unique block hashes**. The parser groups paragraphs, list items, tables and fenced code; headings provide context. Frontmatter is separately represented in the skill catalog. A block is an indexing unit, not a claim that every natural-language sentence has been formally verified.

`canonical` distinguishes template/standalone sources from their paired generated files. `file_coverage` and `context_coverage` show semantic review of the containing text. `individual_verdict` is deliberately `not_individually_annotated`: machine-generated topics, rule groups and adoption questions are review aids, not 25,693 independent human-style judgments. Detailed adopt/adapt/avoid analysis is in the narrative reports and per-family records.

This index does not claim to enumerate every instruction-like comment in all runtime source or every prose document in the repository. It covers skill entry points, section files, repository agent policies, model overlays, specialist checklists and selected canonical references as defined in the supplied inventory script. Other docs and code remain in the complete file ledger.

Canonical template review alone does not establish all generated host/model variants. Shared resolver review, explicit generated ranges and exact-byte duplicate coverage are retained separately. Personalized renders were not generated or executed.

## Practical policy and findings

- `requirements.json`: 99 proposed review rules, each with a stable ID, basis, strength, verification and source links. Only explicitly marked entries describe specification requirements; the others are proposed project policy.
- `benchmark-findings.json`: prioritized concrete findings with evidence type, affected source and suggested validation.
- `skill-catalog.json` / [skill-catalog.md](skill-catalog.md): all 136 `SKILL.md`/template artifacts, metadata and size information. Byte-based token figures are estimates.
- `coverage-summary.json`: merged unique counts, execution limits and unreviewed-semantic paths.
- [catalog-browser.html](catalog-browser.html): offline searchable file and instruction tables. It loads embedded data and makes no background network requests; source links open only when selected.

## How to continue the audit

Filter the file ledger by `structural_index` to find unreviewed implementation/tests. Filter instructions by `structural_only` for remaining generated text. Select a bounded topic, read complete owners and relevant callers/tests, record exact ranges and evidence, then update the ledger without changing earlier executed-result claims.

To audit your own project, use the report and instruction worksheet templates. The reference-project inventory is evidence about one pinned project; it should not become a required file list for yours.


## Application and retrieval maps

[Application profiles](application-profiles.md) join the 99 canonical rules to instruction, resource-assisted and suite/runtime projects, with explicit effect modifiers and overrides. [Approaches](approach-catalog.md) and [command contracts](command-catalog.md) connect the existing research into browser, review/publication and lifecycle slices without claiming exhaustive semantic coverage.

Historical source locations use neutral identifiers as documented in [PROVENANCE.md](../sources/PROVENANCE.md). Hashes and numeric source positions still identify original source bytes. The offline catalog links to the local resolver, which recovers exact source URLs using the one project link in the consolidated Markdown introduction. Textual search descriptions are separate from numeric `ranges`; this does not add new semantic credit.

The file/instruction JSON ledgers are canonical review inputs. CSVs, coverage counts, the skill-artifact Markdown table and embedded browser data are deterministic views generated by [the build process](../methods/BUILD.md). New static findings GST-025 and GST-026 are appended to the original 24, with their supplied-review origin recorded explicitly.
