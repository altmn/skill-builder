# Completed examples and filled evidence

The [manifest-inspector project](manifest-inspector/README.md) is a finished, harmless example of a resource-assisted skill. It inspects declared local files, produces structured discrepancies, and leaves the inputs unchanged. It includes an actual skill payload, a short reference, deterministic checker, valid and discrepant fixtures, local tests, deterministic packaging, concrete agent cases, host recipes and a filled audit.

The original [minimal project scaffolding](../templates/README.md) remains available for unrelated tasks. The completed sample demonstrates decisions that a generic placeholder template cannot settle for you.

## Filled records

| Record | What it demonstrates |
| --- | --- |
| [Host capabilities](records/host-capabilities.json) | Independent format/discovery/functional/safety/support claims, documented and tested versions, and an explicit maintenance scope. |
| [Evaluation receipt](records/evaluation-receipt.json) | Exact package and input identities, local attempt, panel, no-skill limitation, budget, checks and unknown model usage. |
| [Install manifest](records/install-manifest.json) | Owned payload paths with hashes and no invented installation or user-configuration changes. |
| [Finding](records/finding.json) | A reproduced discrepancy with conditions, impact, evidence, limits and an explicit verification result. |
| [Source review](records/source-review.json) | Numeric source ranges kept separate from search selectors. |
| [Rule traceability](records/rule-traceability.json) | A decision for each of the 99 canonical rules, authority basis, failure scenario, verification, evidence and release consequence. |

All filled records and the four editable JSON templates validate against the [versioned schemas](../schemas/README.md). Schema conformity establishes record shape, not the truth of a claim. Local checker tests were executed; host-agent evaluations and comparative benefit remain unrun.
