#!/usr/bin/env python3
"""Execute the frozen local panel; reject missing, changed, zero or skipped tests.

Writes one evidence object to stdout. Tests may rebuild only the example's dist/
package and use their own temporary directories. No host trial is executed.
"""
from datetime import datetime,timezone
import hashlib
import io
import json
from pathlib import Path
import platform
import time
import unittest
ROOT=Path(__file__).resolve().parent

def main():
    panel=json.loads((ROOT/'panel.json').read_text())
    contract=panel['local_resource_contract'];test_file=ROOT/contract['test_file']
    if hashlib.sha256(test_file.read_bytes()).hexdigest()!=contract['sha256']:
        print(json.dumps({'outcome':'blocked','reason':'The test source changed after panel freeze; review and version the panel before execution.'}));return 2
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    def identifiers(test):
        if isinstance(test,unittest.TestSuite):
            return [item for child in test for item in identifiers(child)]
        return [test.id().split('.')[-1]]
    actual=identifiers(suite);expected=contract['expected_test_ids']
    if not expected or sorted(actual)!=sorted(expected):
        print(json.dumps({'outcome':'blocked','reason':'Discovered test IDs do not match the frozen nonempty panel.','expected':expected,'actual':actual}));return 2
    started=datetime.now(timezone.utc).isoformat();tick=time.monotonic();stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    outcome='passed' if result.wasSuccessful() and not result.skipped and result.testsRun==len(expected) else 'failed'
    print(json.dumps({'schema_version':'1.0','evidence_kind':'local_resource_tests','outcome':outcome,'started_at':started,'ended_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'python':platform.python_version(),'panel_sha256':hashlib.sha256((ROOT/'panel.json').read_bytes()).hexdigest(),'test_sha256':contract['sha256'],'package_identity':json.loads((ROOT/'dist/package-identity.json').read_text()),'output':stream.getvalue(),'limits':['No live agent, host discovery, permission enforcement, no-skill comparison or provider usage was measured.']},indent=2))
    return 0 if outcome=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
