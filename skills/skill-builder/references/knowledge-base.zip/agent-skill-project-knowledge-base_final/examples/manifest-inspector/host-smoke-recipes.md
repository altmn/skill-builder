# Host smoke recipes — not executed

These recipes instantiate documented host surfaces from the dated [portability chapter](../../handbook/04-portability.md). They are not tested support claims. Recheck the exact product documentation and policy before a real trial. The sample needs reading selected files and running its local Python checker; it needs no network grant or broad write permission.

## Prepare the same exact payload

Run `python examples/manifest-inspector/build.py` from the knowledge-base root. Retain `dist/package-identity.json`, the package digest, the panel hash, OS/Python versions and the host's exact version/surface/distribution. Use a disposable project whose configuration and discovery roots you can inspect. Extract the ZIP only into that project's authorized skill root.

| Target surface | Project payload layout after extraction | Explicit smoke invocation |
| --- | --- | --- |
| Codex CLI or IDE with project skill discovery | `.agents/skills/manifest-inspector/SKILL.md` and its `references/` and `scripts/` siblings | `$manifest-inspector` followed by the full selected manifest and root paths; use the host's current skill picker if its syntax differs. |
| Claude Code CLI project skills | `.claude/skills/manifest-inspector/SKILL.md` and its siblings | `/manifest-inspector` with the selected manifest/root paths. |
| Grok Build project skills | `.grok/skills/manifest-inspector/SKILL.md` and its siblings | The host's exposed `manifest-inspector` slash command, after confirming discovery in that exact version. |

No native permission configuration is supplied. Record the actual host execution policy separately. A field accepted by one host does not create a grant or restriction in another. For ChatGPT, plugins, account-synced distributions, custom API hosts or other surfaces, use native artifact IDs and that surface's packaging contract; these file-layout recipes do not assert equivalence.

## Execute and record

Run each case in [panel.json](panel.json) in a new or explicitly reset task environment. Preserve the actual activated artifact path or native ID and its hash where available. If the host cannot expose that identity, record the identity claim as inconclusive. Capture the transcript, raw checker JSON, exit status, output artifacts, policy and any unavailable tool. Compare a result against the panel's independent assertions, not the assistant's claim of completion.

Repeat relevant [HOST-03 through HOST-06 designs](../../evaluations/case-designs.json) for second turns, real compaction, source replacement, removal, same-name collisions, namespaces and resource identity. Distinguish actual host events from simulated context loss. A denied or missing local Python tool must produce a blocked checker outcome; it cannot be turned into a structural pass by a prose-only guess.

## Isolate the no-skill control

Use a separate clean disposable project and a fresh conversation. Do not copy the sample skill, knowledge-base instructions, `AGENTS.md`, hooks, memory, prior transcripts or skill-discovery roots into it. Inspect relevant user and plugin roots for accidental discovery; if a clean control cannot be established, mark the comparison blocked. Supply the same task input, runtime/tools and a neutral copy of the standalone checker only if that tool access was predeclared for both arms. This measures the added instruction skill rather than unequal access to an executable.

Freeze budgets, grader, retry and exclusion policy before the first run. Use the same held-out task panel for paired conditions and keep all attempts, including failures. Do not claim measured benefit from the local test suite. Cleanup removes only the disposable trial's own payload and output paths.
