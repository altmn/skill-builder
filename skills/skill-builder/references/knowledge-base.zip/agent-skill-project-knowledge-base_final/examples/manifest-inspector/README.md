# Completed reference project: manifest inspector

This small project connects a concrete task, an actual portable skill, a deterministic read-only resource, two fixtures, exact package bytes, local tests and honest evidence. It is an example to inspect or copy; it is not installed in the current host.

Start with [the task brief](task-brief.md), [SKILL.md](skills/manifest-inspector/SKILL.md), [the input/output contract](skills/manifest-inspector/references/contract.md), and [the filled audit](audit-report.md).

## Run from a clean knowledge-base checkout

Use Python 3.10 or later for the sample checker and build. The knowledge-base validators additionally require the pinned [tool dependencies](../../tools/requirements.txt). From the knowledge-base root:

```sh
python examples/manifest-inspector/build.py
python tools/validate_skill.py examples/manifest-inspector/skills/manifest-inspector
python examples/manifest-inspector/run_local_checks.py
python -m unittest discover -s examples/manifest-inspector/tests -v
python examples/manifest-inspector/skills/manifest-inspector/scripts/check_manifest.py --manifest examples/manifest-inspector/fixtures/valid/manifest.json --root examples/manifest-inspector/fixtures/valid
python examples/manifest-inspector/skills/manifest-inspector/scripts/check_manifest.py --manifest examples/manifest-inspector/fixtures/discrepancy/manifest.json --root examples/manifest-inspector/fixtures/discrepancy
python tools/validate_records.py
```

`run_local_checks.py` verifies that discovered test IDs and test-source identity match the frozen nonempty panel, then rejects skips or failures. It prints a new local evidence object to stdout. The lower-level unittest command is also shown for direct debugging. The existing receipts remain historical records rather than being overwritten.

The valid fixture exits 0. The discrepancy fixture intentionally exits 1 with a complete report of missing, size-mismatched and hash-mismatched files; that expected nonzero status is not a broken example. Invalid input exits 2 and reports `blocked`. The checker writes JSON to stdout only. Capture it to a file only when that destination is part of the requested task.

The build creates [dist/manifest-inspector.zip](dist/manifest-inspector.zip) and [its identity record](dist/package-identity.json). It includes exactly `manifest-inspector/SKILL.md`, `manifest-inspector/references/contract.md`, and `manifest-inspector/scripts/check_manifest.py`. Fixed ZIP metadata and sorted members make two clean builds byte-identical within the pinned build environment. Fixtures, tests, contribution guidance, receipts and the rest of this knowledge base are source-repository material and stay outside the installable payload.

## Local evidence and limits

The [local test receipt](local-test-results.json) records executed tests and environment identity. The [evaluation receipt](../records/evaluation-receipt.json) binds those resource tests to the package digest. The [host record](../records/host-capabilities.json) deliberately combines a local format pass with discovery/functional outcomes of `not_run` and a blocked host-safety claim. The [ownership record](../records/install-manifest.json) describes the built payload only; it records no host installation, link creation or configuration change.

No live agent trial, host compatibility trial, or no-skill comparison was run. Local resource correctness does not measure whether a skill improves outcomes over a model simply using the checker. The [frozen local/host panel](panel.json) and [host recipes](host-smoke-recipes.md) supply exact cases, fixtures, reset steps and acceptance criteria for a later comparison. Keep a zero or negative measured benefit if that is what the experiment finds.

## Scope decisions

The sample uses the `resource_assisted` profile without network, publication, persistent-state, authenticated-browser or installer modifiers. A Python script is justified by deterministic digest and path operations. The checker has explicit data-volume limits and no subprocesses. A hostile concurrently changing filesystem is outside its stable-input contract; the host must supply a trusted snapshot or actual confinement before making a stronger claim.

The project copies no package-manager dependencies into its payload. Terms for reuse of the sample are those stated for original code and templates in the knowledge base's [reuse notice](../../NOTICE.md).
