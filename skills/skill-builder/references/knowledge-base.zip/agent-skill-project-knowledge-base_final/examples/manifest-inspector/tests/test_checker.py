import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'skills/manifest-inspector/scripts/check_manifest.py'
spec=importlib.util.spec_from_file_location('checker',SCRIPT); checker=importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)

class CheckerContracts(unittest.TestCase):
    def test_valid_fixture(self):
        r=checker.inspect(ROOT/'fixtures/valid/manifest.json',ROOT/'fixtures/valid')
        self.assertEqual('passed',r['outcome']); self.assertEqual(1,r['checked_files']); self.assertEqual([],r['discrepancies'])
    def test_complete_discrepancy_fixture(self):
        r=checker.inspect(ROOT/'fixtures/discrepancy/manifest.json',ROOT/'fixtures/discrepancy')
        self.assertEqual('failed',r['outcome'])
        self.assertEqual({'missing','size_mismatch','hash_mismatch'},{x['kind'] for x in r['discrepancies']})
    def test_cli_works_from_unrelated_directory(self):
        with tempfile.TemporaryDirectory() as d:
            p=subprocess.run([sys.executable,str(SCRIPT.resolve()),'--manifest',str((ROOT/'fixtures/valid/manifest.json').resolve()),'--root',str((ROOT/'fixtures/valid').resolve())],cwd=d,text=True,capture_output=True,timeout=5)
        self.assertEqual(0,p.returncode); self.assertEqual('passed',json.loads(p.stdout)['outcome'])
    def fixture(self,root,row):
        m=root/'manifest.json'; m.write_text(json.dumps({'schema_version':'1.0','files':[row]})); return m
    def row(self,path='note.txt'): return {'path':path,'bytes':1,'sha256':hashlib.sha256(b'x').hexdigest()}
    def test_path_escape_and_absolute_and_windows(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for path in ['../outside','/tmp/outside','C:/outside','assets\\outside','./note.txt']:
                with self.subTest(path=path): self.assertEqual('blocked',checker.inspect(self.fixture(root,self.row(path)),root)['outcome'])
    def test_symlink_preserves_external_file(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'outside').write_text('private'); (root/'link').symlink_to(root/'outside')
            self.assertEqual('blocked',checker.inspect(self.fixture(root,self.row('link')),root)['outcome'])
            self.assertEqual('private',(root/'outside').read_text())
    def test_no_zero_file_pass(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); m=root/'manifest.json'; m.write_text('{"schema_version":"1.0","files":[]}')
            self.assertEqual('blocked',checker.inspect(m,root)['outcome'])
    def test_duplicate_keys_and_nonfinite_numbers(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); m=root/'manifest.json'
            for content in ['{"schema_version":"1.0","files":[],"files":[]}','{"schema_version":"1.0","files":NaN}']:
                m.write_text(content); self.assertEqual('blocked',checker.inspect(m,root)['outcome'])
    def test_captured_bytes_bounded(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'note.txt').write_bytes(b'x'*9)
            old=checker.LIMITS.copy()
            try:
                checker.LIMITS['file_bytes']=8
                self.assertEqual('blocked',checker.inspect(self.fixture(root,self.row()),root)['outcome'])
            finally: checker.LIMITS.update(old)
    def test_readonly_contract(self):
        root=ROOT/'fixtures/valid'; before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
        checker.inspect(root/'manifest.json',root)
        after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}; self.assertEqual(before,after)
    def test_payload_build_reproducible(self):
        spec=importlib.util.spec_from_file_location('build_example',ROOT/'build.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        self.assertEqual(m.build()['sha256'],m.build()['sha256'])
if __name__=='__main__': unittest.main()
