# Filled audit: manifest-inspector

**Scope:** the three-file portable payload built by [build.py](build.py), its two local fixture trees, checker tests, declared read-only workflow and packaging/evidence contracts. **Assessment date:** November 22, 2026, America/Los_Angeles. Exact UTC execution timestamps are in [the local receipt](local-test-results.json).

**Disposition:** the local package and deterministic resource are usable as a completed reference example. Live host discovery, permissions, agent task outcomes and comparative skill benefit remain unverified. Do not describe the sample as functionally or safely supported on a named host until the relevant panel runs.

## Identity and coverage

The authoritative package digest and per-file hashes are in [dist/package-identity.json](dist/package-identity.json). The [versioned evaluation receipt](../records/evaluation-receipt.json) binds the recorded local run to that package, the test source, both manifest fixtures, the panel and the Python runtime. No source Git commit is invented for this bundled example.

| Component | Review or execution | Result |
| --- | --- | --- |
| Actual `SKILL.md` and its two direct resources | Portable format validator 1.1.0 | Passed; exact validator identity and declared limits retained in [format-check-results.json](format-check-results.json). |
| Checker source and task contract | Complete source reading, bounded fixture execution | Scope and failure behavior are explicit; [source-review.json](../records/source-review.json) records numeric line coverage separately from selectors. |
| Local resource/package panel | 10 unittest cases, no skips | Passed: valid result, complete discrepancy reporting, unrelated working directory, traversal/absolute paths, symlinks, zero-file rejection, malformed JSON, capture limit, unchanged inputs and reproducible ZIP bytes. |
| Owned payload inventory | Package-only manifest | Three files, no created links, no settings writes, no host installation. |
| Host activation, continuation, permission lifetime and namespace identity | Recipes and concrete cases only | Not run. |
| Agent trigger, near miss, missing capability and no-skill comparison | Concrete panel with frozen local acceptance and separate host budget requirements | Not run; no benefit claim. |

## Findings and decisions

### EX-DIFF-001 — intentional fixture discrepancy

**Evidence type:** reproduced local behavior. **Severity:** informational fixture result. The discrepancy fixture contains an edited file and an absent file. The checker returns `failed`, exit 1, and all three expected discrepancy kinds: missing, size mismatch and digest mismatch. [discrepancy-report.json](discrepancy-report.json) and [finding.json](../records/finding.json) preserve the observation and its conditions.

This is the expected test outcome. The skill must report it without repairing inputs or treating the negative result as an infrastructure error. The fixture remains inconsistent so future changes can be checked against the same contract.

### EX-LIMIT-001 — concurrent filesystem mutation is outside the claim

**Evidence type:** source inspection and an explicit design limit. Path checks reject traversal and symlink components; file reads use the platform's final-component no-follow option where available. Parent directories can still change between checks and opening a file. The test suite does not establish a security boundary against an adversarial concurrent writer.

The task contract therefore requires a stable selected directory. If stronger confinement is needed, the adapter must supply a trusted read-only snapshot or real filesystem sandbox and test that boundary. An instruction to be careful does not satisfy that requirement. The sample does not read outside its selected paths in the tested fixtures and does not claim stronger isolation.

### EX-EVID-001 — host and comparative evidence are unavailable

**Evidence type:** explicit absence of executed trials. The sample includes a [near-miss prompt and missing-capability case](panel.json), [exact host packaging recipes](host-smoke-recipes.md), and links to temporal/name-collision designs. No live host or model participated in the local suite, and no clean no-skill control ran.

The [host capability record](../records/host-capabilities.json) keeps format passed, discovery/functional/support not run, and host safety blocked. The evaluation receipt keeps tokens, provider calls and cost unknown with reasons. These results cannot justify a “universal” compatibility badge or a productivity percentage.

## Applicability and release consequences

The [filled traceability record](../records/rule-traceability.json) contains exactly one decision for every original rule and retains each rule's specification/project basis. The selected profile is `resource_assisted`, with no network, publication, persistent-state, authenticated-browser or installer modifiers. The source's small ZIP builder is an explicit additional generation control; the profile's optional worker, subjective-grader and privileged-CI rules are evaluated rather than silently ignored.

An invalid payload, a missing declared resource, an incorrect discrepancy result, an input mutation, an unsafe path acceptance or a nonreproducible package blocks this local reference package. Unrun host gates block host support claims. No installer or external publication is part of the skill's operation, so those capabilities are explicitly outside the assessed scope and must be reconsidered if added.

## Reproduce the evidence

Use the exact commands in [README.md](README.md). The test suite is deterministic with respect to outcomes; timing and receipt timestamps naturally vary. Rebuilding the ZIP twice from the same payload and fixed build environment produces the same bytes. Preserve earlier receipts when code or fixtures change, and issue a new one for the new identity. A new passing run does not rewrite the historical observation.
