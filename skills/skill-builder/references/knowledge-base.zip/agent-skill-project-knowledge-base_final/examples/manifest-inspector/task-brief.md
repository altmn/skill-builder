# Task brief: inspect a supplied JSON manifest

**User task:** “Compare this manifest with the files in this folder and tell me exactly what differs. Leave the inputs unchanged.”

**Chosen scope:** one selected JSON manifest, one selected root directory, and only its declared relative regular files. The result lists missing files and size/digest discrepancies. It neither repairs inputs nor judges whether the manifest author is trustworthy.

**Architecture decision:** a single portable instruction skill plus a deterministic Python checker. Numeric limits, duplicate-key parsing, digest computation and exit codes belong to the checker. Input selection, authorization, explaining missing capabilities and reporting the result belong to instructions. There is no need for a daemon, installer, browser, network service, subskill or persistent state.

**Acceptance conditions:** the valid fixture yields `passed`; the discrepancy fixture reports all three discrepancy kinds; malformed/traversing/symlink inputs yield `blocked`; inspection leaves all fixtures unchanged; running from an unrelated working directory still finds the checker and resources. A pass must check at least one file.

**Evidence:** local tests and a package identity establish the bounded checker contract. Host discovery, model behavior, permissions and comparative skill benefit require separate agent trials and remain unrun. The [panel](panel.json) includes concrete positive, near-miss, missing-capability and no-skill conditions.

**Applicability:** `resource_assisted` profile with no effect modifiers. Rule-by-rule decisions, their authority, failure scenario, verification and release consequence appear in the [filled traceability record](../records/rule-traceability.json). Controls for publication, installers and persistent daemons are excluded because those effects are outside this task; host integration remains unassessed until trials run.
