# Manifest and result contract

Input is a UTF-8 JSON object containing exactly `schema_version: "1.0"` and `files`, an array of objects with exactly `path`, `bytes`, and `sha256`. Paths use forward slashes and are relative to the selected root. The byte count is a nonnegative integer; the digest is 64 lowercase hexadecimal characters. Duplicate JSON keys and duplicate file paths are invalid. Empty inventories are rejected to prevent zero-file success.

Limits are 1 MiB of manifest text, 1,000 declarations, 8 MiB per declared or actual file, and 32 MiB of actual content read in total. The checker reads at most one extra byte to detect a limit breach. It performs no network calls and creates no files. It does not interpret a file's content as code. A caller may capture stdout to an explicitly selected report path; that write belongs to the caller.

Absolute paths, Windows drive syntax, backslashes, `.`/`..` segments, control characters, symlink components, directories masquerading as files, and files resolving outside the root are blocked. The root must be a real directory with no symlink components. The manifest itself must be a regular file with no symlink components. This is a conservative local checker, not an operating-system sandbox; hostile concurrent filesystem mutation requires a trusted snapshot or separate confinement.

Output is one JSON object with `schema_version`, `outcome`, `manifest_sha256`, `checked_files`, `discrepancies`, `limits`, and `reason`. Each discrepancy includes a path, kind, expected value, and actual value. Kinds are `missing`, `size_mismatch`, and `hash_mismatch`. A blocked result may include partial discrepancies; those are not a complete inspection.

| Exit | Outcome | Meaning |
| --- | --- | --- |
| 0 | `passed` | At least one declared file was checked and all declarations matched. |
| 1 | `failed` | Inspection completed and at least one declared file did not match. |
| 2 | `blocked` | A malformed input, access boundary, unsupported file, or resource limit prevented complete checking. |

An invocation with missing or unrecognized command-line arguments exits 2 with usage on stderr and produces no inspection JSON. This is an invocation error, distinct from a validated call that produces a `blocked` report.

Unknown extra files are outside this contract. A digest match establishes equality with the manifest's declared bytes, not that the manifest is trustworthy. Repeated runs read the selected inputs again and do not cache earlier results.
