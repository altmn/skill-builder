#!/usr/bin/env python3
"""Read-only, bounded manifest inspection; Python standard library only."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

LIMITS={'manifest_bytes':1048576,'files':1000,'file_bytes':8388608,'total_capture_bytes':33554432}
class Blocked(ValueError): pass

def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise Blocked('Duplicate JSON key: '+key)
        result[key]=value
    return result

def plain_path(path, directory=False):
    """Reject symlink components before resolution; still requires a stable tree."""
    path=Path(os.path.abspath(path))
    for part in [*reversed(path.parents),path]:
        if part.is_symlink(): raise Blocked('Symlink path components are unsupported.')
    mode=path.stat().st_mode
    if directory and not stat.S_ISDIR(mode): raise Blocked('Selected root is not a directory.')
    if not directory and not stat.S_ISREG(mode): raise Blocked('Input is not a regular file.')
    return path.resolve(strict=True)

def bounded_read(path,cap):
    # O_NOFOLLOW narrows the final-component race where supported. Parent path races
    # remain outside the stable-tree contract and must be constrained by the host.
    flags=os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)
    fd=os.open(path,flags)
    with os.fdopen(fd,'rb') as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode): raise Blocked('Input is not a regular file.')
        data=f.read(cap+1)
    if len(data)>cap: raise Blocked('Content exceeds the declared capture limit.')
    return data

def inspect(manifest,root):
    result={'schema_version':'1.0','outcome':'blocked','manifest_sha256':None,'checked_files':0,'discrepancies':[],'limits':dict(LIMITS),'reason':None}
    try:
        root=plain_path(root,directory=True)
        data=bounded_read(plain_path(manifest),LIMITS['manifest_bytes'])
        result['manifest_sha256']=hashlib.sha256(data).hexdigest()
        value=json.loads(data.decode('utf-8'),object_pairs_hook=unique_object,parse_constant=lambda x: (_ for _ in ()).throw(Blocked('Nonfinite JSON number: '+x)))
        if not isinstance(value,dict) or set(value)!={'schema_version','files'} or value['schema_version']!='1.0': raise Blocked('Expected exactly schema_version 1.0 and files.')
        entries=value['files']
        if not isinstance(entries,list) or not 1<=len(entries)<=LIMITS['files']: raise Blocked('Declare between 1 and 1000 files.')
        seen=set(); parsed=[]
        for row in entries:
            if not isinstance(row,dict) or set(row)!={'path','bytes','sha256'}: raise Blocked('File declaration has unknown or missing fields.')
            path=row['path']
            if not isinstance(path,str) or not path or '\\' in path or ':' in path or any(ord(c)<32 for c in path): raise Blocked('Invalid relative file path.')
            parts=path.split('/')
            if any(p in {'','.', '..'} for p in parts) or PurePosixPath(path).is_absolute(): raise Blocked('Path must stay inside the selected root.')
            if path in seen: raise Blocked('Duplicate file path: '+path)
            seen.add(path)
            if type(row['bytes']) is not int or not 0<=row['bytes']<=LIMITS['file_bytes']: raise Blocked('Invalid or excessive declared file size.')
            if not isinstance(row['sha256'],str) or re.fullmatch('[0-9a-f]{64}',row['sha256']) is None: raise Blocked('Invalid SHA-256 value.')
            parsed.append(row)
        total=0
        for row in parsed:
            candidate=root.joinpath(*row['path'].split('/'))
            try:
                safe=plain_path(candidate)
            except FileNotFoundError:
                # A dangling symlink is already caught by plain_path's component scan.
                result['discrepancies'].append({'path':row['path'],'kind':'missing','expected':'regular file','actual':None})
                continue
            try: safe.relative_to(root)
            except ValueError: raise Blocked('Resolved file escaped the selected root.')
            actual=bounded_read(safe,min(LIMITS['file_bytes'],LIMITS['total_capture_bytes']-total))
            total+=len(actual); result['checked_files']+=1
            digest=hashlib.sha256(actual).hexdigest()
            if len(actual)!=row['bytes']: result['discrepancies'].append({'path':row['path'],'kind':'size_mismatch','expected':row['bytes'],'actual':len(actual)})
            if digest!=row['sha256']: result['discrepancies'].append({'path':row['path'],'kind':'hash_mismatch','expected':row['sha256'],'actual':digest})
        result['outcome']='failed' if result['discrepancies'] else 'passed'
    except (Blocked,OSError,UnicodeError,json.JSONDecodeError,RecursionError) as exc:
        result['reason']=str(exc)
    return result

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',required=True,type=Path); p.add_argument('--root',required=True,type=Path)
    a=p.parse_args(argv); result=inspect(a.manifest,a.root)
    print(json.dumps(result,sort_keys=True,indent=2))
    return {'passed':0,'failed':1,'blocked':2}[result['outcome']]
if __name__=='__main__': raise SystemExit(main())
