#!/usr/bin/env python3
"""Build only the installable skill payload, reproducibly; no host installation."""
from pathlib import Path
import hashlib
import json
import zipfile
ROOT=Path(__file__).resolve().parent
PAYLOAD=ROOT/'skills/manifest-inspector'
FILES=['SKILL.md','references/contract.md','scripts/check_manifest.py']
def build():
    output=ROOT/'dist'; output.mkdir(exist_ok=True)
    archive=output/'manifest-inspector.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(FILES):
            entry=zipfile.ZipInfo('manifest-inspector/'+name,date_time=(2026,11,22,0,0,0))
            entry.create_system=3; entry.external_attr=(0o100644<<16); entry.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(entry,(PAYLOAD/name).read_bytes())
    record={'schema_version':'1.0','archive':'dist/manifest-inspector.zip','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':[{'path':'manifest-inspector/'+n,'bytes':(PAYLOAD/n).stat().st_size,'sha256':hashlib.sha256((PAYLOAD/n).read_bytes()).hexdigest()} for n in FILES],'effects':'Creates only dist/manifest-inspector.zip and dist/package-identity.json; does not install.'}
    (output/'package-identity.json').write_text(json.dumps(record,indent=2)+'\n')
    return record
if __name__=='__main__': print(json.dumps(build(),indent=2))
