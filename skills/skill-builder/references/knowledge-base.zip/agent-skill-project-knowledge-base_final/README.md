# Agent Skill Project Knowledge Base

**Portable task contracts, practical tools, explicit evidence.** A research-backed handbook, reusable project scaffolding, audit rules and complete evidence catalogs for creating and maintaining agent skills. The existing Codex-first guidance and explicit adapters for other hosts remain available.

Research date: **November 22, 2026, America/Los_Angeles**. Historical source snapshot: package `1.102.2`, runtime `1.102.2.0`, commit `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`.

## Start here

| Your task | Read / use |
|---|---|
| Understand the conclusions and coverage | [Scope and conclusions](handbook/00-scope-and-conclusions.md) |
| Build a new project | [Creation playbook](handbook/11-create-a-skill.md) and [agent instructions](templates/CREATE-PROJECT-INSTRUCTIONS.md) |
| Audit an existing project | [Audit playbook](handbook/12-audit-an-existing-project.md), [agent instructions](templates/AUDIT-PROJECT-INSTRUCTIONS.md), and [99-rule checklist](checklists/audit.md) |
| Start from a scaffold | [Template guide](templates/README.md) |
| Follow a finished, runnable example | [Completed examples](examples/README.md) and [manifest-inspector](examples/manifest-inspector/README.md) |
| Select proportionate requirements | [Application profiles](catalogs/application-profiles.md), backed by the original 99 rules |
| Create consistent evidence | [Versioned schemas](schemas/README.md) and [filled records](examples/README.md#filled-records) |
| Trace an approach to owners, commands and limits | [Approach map](catalogs/approach-catalog.md) and [command map](catalogs/command-catalog.md) |
| Rebuild or check the complete bundle | [Build and verification guide](methods/BUILD.md) |
| Inspect how the review was applied | [Change record](CHANGELOG.md) and [finding-by-finding implementation record](validation/review-application.md) |
| Validate portable metadata and direct resources | [Validator documentation](tools/README.md) |
| Inspect any benchmark file or instruction | [Catalog guide](catalogs/README.md) and [offline catalog browser](catalogs/catalog-browser.html) |
| Read the detailed source analysis | [Audit guide](audits/README.md) |
| Verify a fact or recommendation | [Primary sources](sources/primary-sources.md) and the pinned links in each audit |

The root HTML reader and consolidated Markdown contain the handbook, audit narratives, checklists and source register. The ZIP is the complete deliverable, including machine-readable catalogs, templates, validator code and its test receipt.

## The recommended architecture

Keep the task contract portable. Add deterministic resources where exact behavior matters. Put discovery paths, tool names, permission semantics, native hooks and product metadata in explicit host adapters. Test what the distributed artifact does on each claimed host. Start with a small instruction skill and add runtime machinery only when the task warrants it.

The detailed research supplies both useful mechanisms and concrete counterexamples for evidence, failure states, modular instruction ownership and regression testing. Choose mechanisms for the task and its effects; the full runtime, house style and approval rituals of a source project are not universal requirements.

## Handbook

1. [Design principles and project size](handbook/01-design-principles.md)
2. [Instruction engineering](handbook/02-instruction-engineering.md)
3. [Architecture, sub-skills and generation](handbook/03-architecture-and-subskills.md)
4. [Codex, Claude Code and Grok portability](handbook/04-portability.md)
5. [Commands, resources and state](handbook/05-commands-and-resources.md)
6. [Testing and evaluations](handbook/06-testing-and-evaluation.md)
7. [Security and privacy](handbook/07-security-and-privacy.md)
8. [Performance and cost](handbook/08-performance-and-cost.md)
9. [Installation and releases](handbook/09-installation-and-releases.md)
10. [GitHub presentation and maintenance](handbook/10-github-and-maintenance.md)
11. [Create a new skill](handbook/11-create-a-skill.md)
12. [Audit an existing skill](handbook/12-audit-an-existing-project.md)

## Evidence boundary

The audit inventories all 5,375 tracked files and indexes 25,693 instruction blocks. It includes full semantic reading of all 65 canonical skill entry-point templates, other authoritative instructions and selected runtime owners. It does **not** claim that every line of the roughly 1.18-million-line repository was manually analyzed or that all generated host variants were executed. Every file has an explicit depth label; exact totals are in [coverage-summary.json](catalogs/coverage-summary.json).

No reference source setup, upgrade, hooks, test suite, daemon, authenticated flow or paid evaluation was run. The pinned public OpenAI validator received isolated probes. The original validator delivered here has its own passing regression receipt. These are distinct evidence sets.

## Reuse

The guidance, rule catalog, task briefs, templates and validator are new materials prepared for this knowledge base. Source excerpts and adapted research observations are attributed. See [NOTICE.md](NOTICE.md) and retained upstream licenses before redistributing source-derived material. No affiliation or endorsement by the referenced projects or vendors is implied.

## A short working path

From the extracted package root, with the pinned local dependencies available:

```sh
python3 -B tools/validate_skill.py examples/manifest-inspector/skills/manifest-inspector
python3 -B tools/validate_records.py
python3 -B examples/manifest-inspector/run_local_checks.py
python3 -B tools/profile_view.py --profile resource_assisted
```

The example inspects an explicitly supplied local JSON manifest and reports discrepancies without repairing the inputs. Its valid and deliberately discrepant fixtures have explicit expected outcomes. The generic templates remain intact for other tasks. Local checker tests establish local resource behavior; the host recipes and no-skill comparison remain unexecuted.

Run `python3 -B methods/build_bundle.py --check` to detect a stale reader, catalog view, example package or manifest. Run `python3 -B methods/check_bundle.py --run-tests` for the local acceptance gates. Exact prerequisites, canonical ownership, update order and CI commands are in [methods/BUILD.md](methods/BUILD.md).

## Preservation and source traceability

All 93 substantive original artifact positions are retained or replaced by explicitly renamed/updated counterparts. The complete file and instruction ledgers, all 99 rules, all 136 skill-artifact records, all 24 original findings and all 18 original evaluation designs remain available; two findings and four host designs were added. The detailed research was not replaced by a condensed account. [The preservation receipt](validation/preservation-audit.json) records checked invariants and original artifact identities.

Historical paths and excerpts use a neutral namespace so readers can focus on reusable practices. Source commits, blob identities, hashes, byte and line counts retain their original meanings. Source links resolve through [the local source reference page](sources/source-reference.html); [PROVENANCE.md](sources/PROVENANCE.md) explains exact path recovery and the difference between adapted display excerpts and source bytes. The linked inspiration statement is in the introduction of [skill-project-knowledge-base.md](skill-project-knowledge-base.md).

## License status

[LICENSE.md](LICENSE.md) explicitly records which materials have retained upstream terms and which original components still need the rights holder's license selection before public open reuse. This revision does not assign a new license on the owner's behalf. [NOTICE.md](NOTICE.md) and all existing third-party license texts remain included.
