#!/usr/bin/env python3
"""Validate local evidence records without fetching schemas or trusting verdicts.

Default: every record named in schemas/record-index.json. --record may be repeated.
Exit 0: all supplied records conform; 1: invalid records; 2: invocation/dependency error.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path
try:
    from jsonschema import Draft202012Validator, FormatChecker
    from referencing import Registry, Resource
    from referencing.exceptions import NoSuchResource
except ImportError as exc:
    print(json.dumps({'outcome':'blocked','error':str(exc),'remedy':'Install tools/requirements.txt into an isolated environment.'}))
    raise SystemExit(2)
ROOT=Path(__file__).resolve().parents[1]
MAX_RECORD_BYTES=4*1024*1024

def reject_duplicates(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError(f'duplicate JSON key: {k}')
        out[k]=v
    return out

def read_json(path):
    with Path(path).open('rb') as f: data=f.read(MAX_RECORD_BYTES+1)
    if len(data)>MAX_RECORD_BYTES: raise ValueError('record exceeds 4 MiB limit')
    return json.loads(data.decode('utf-8'),object_pairs_hook=reject_duplicates,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f'nonfinite JSON number: {x}')))

def deny_remote(uri):
    raise NoSuchResource(ref=uri)

def validators(root=ROOT):
    documents={p.name:read_json(p) for p in sorted((root/'schemas').glob('*.schema.json'))}
    registry=Registry(retrieve=deny_remote).with_resources((name,Resource.from_contents(s)) for name,s in documents.items())
    out={}
    for name,schema in documents.items():
        Draft202012Validator.check_schema(schema)
        if name!='common.schema.json':
            out[name.removesuffix('.schema.json')]=Draft202012Validator(schema,registry=registry,format_checker=FormatChecker())
    return out

def semantic_errors(record,root=ROOT):
    """Cross-field relations JSON Schema does not express are explicit here."""
    errors=[]
    def walk(value,path='$'):
        if isinstance(value,dict):
            if {'start','end'}<=value.keys() and type(value['start']) is int and type(value['end']) is int and value['end']<value['start']:
                errors.append(path+': source range end precedes start')
            if 'ranges' in value and 'line_count' in value and isinstance(value.get('line_count'),int) and isinstance(value['ranges'],list):
                for interval in value['ranges']:
                    if isinstance(interval,dict) and type(interval.get('end')) is int and interval['end']>value['line_count']:
                        errors.append(path+': source range exceeds recorded line count')
            if value.get('outcome')=='passed' and isinstance(value.get('checks'),list):
                if any(x.get('outcome') in {'failed','blocked','not_run','inconclusive'} for x in value['checks'] if isinstance(x,dict)):
                    errors.append(path+': aggregate pass includes a nonpassing required check')
            if 'started_at' in value and 'ended_at' in value:
                from datetime import datetime
                try:
                    if datetime.fromisoformat(value['ended_at'].replace('Z','+00:00'))<datetime.fromisoformat(value['started_at'].replace('Z','+00:00')):
                        errors.append(path+': attempt end precedes start')
                except (ValueError,TypeError,AttributeError): pass
            for k,v in value.items(): walk(v,path+'.'+k)
        elif isinstance(value,list):
            for n,v in enumerate(value): walk(v,path+f'[{n}]')
    walk(record)
    if record.get('record_type')=='host-capabilities':
        exercised=any(c.get('exercise',{}).get('outcome')=='passed' for c in record.get('capabilities',{}).values() if isinstance(c,dict))
        if exercised and not record.get('artifact',{}).get('package_sha256'):
            errors.append('artifact: exercised capability pass requires package identity')
        for name,c in record.get('capabilities',{}).items():
            if isinstance(c,dict) and c.get('exercise',{}).get('outcome')=='passed' and not c.get('tested_versions'):
                errors.append(f'capabilities.{name}: a passed exercise requires tested_versions')
    if record.get('record_type')=='rule-traceability':
        catalog=read_json(root/'catalogs/requirements.json')['rules']
        expected={r['id']:r for r in catalog}
        rows=record.get('records',[])
        ids=[r.get('rule_id') for r in rows if isinstance(r,dict)]
        if len(ids)!=len(set(ids)): errors.append('records: duplicate rule ID')
        if set(ids)!=set(expected): errors.append('records: must assess every canonical rule exactly once; missing='+str(sorted(set(expected)-set(ids)))+'; unknown='+str(sorted(set(ids)-set(expected))))
        for row in rows:
            if not isinstance(row,dict): continue
            rule=expected.get(row.get('rule_id'))
            if rule and row.get('local_policy')!=(rule['basis']=='project'):
                errors.append(str(row.get('rule_id'))+': local_policy must preserve the canonical authority basis')
            if row.get('decision')=='adopted' and row.get('verification',{}).get('outcome')=='passed' and not row.get('evidence'):
                errors.append(str(row.get('rule_id'))+': adopted passed rule requires evidence')
            if row.get('rule_id')=='LIFE-012' and 'publication' in record.get('modifiers',[]) and row.get('decision')=='not_applicable':
                if not row.get('override') or len(row.get('reason','').strip())<20:
                    errors.append('LIFE-012: publication authorization exclusion requires an explicit, reviewable override reason')
    return errors

def validate_record(record,known=None,root=ROOT):
    if not isinstance(record,dict): return ['record must be a JSON object']
    known=known or validators(root)
    kind=record.get('record_type')
    if kind not in known: return ['unknown or missing record_type']
    errors=[]
    try:
        for err in sorted(known[kind].iter_errors(record),key=lambda e:str(list(e.absolute_path))):
            errors.append('.'.join(str(x) for x in err.absolute_path)+': '+err.message)
    except Exception as exc:
        errors.append('schema resolution failed without network access: '+str(exc))
    # Avoid further traversal of a grossly invalid root structure.
    if not errors: errors.extend(semantic_errors(record,root))
    return errors

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--record',action='append',type=Path,help='local record to validate; repeat for multiple records')
    args=parser.parse_args(argv)
    try:
        paths=args.record or [ROOT/p for p in read_json(ROOT/'schemas/record-index.json')['records']]
        known=validators()
    except Exception as exc:
        print(json.dumps({'outcome':'blocked','error':str(exc)})); return 2
    results=[]
    for path in paths:
        try: errors=validate_record(read_json(path),known)
        except Exception as exc: errors=[str(exc)]
        results.append({'path':str(path),'outcome':'failed' if errors else 'passed','errors':errors})
    if not results:
        print(json.dumps({'outcome':'blocked','reason':'No records selected.'})); return 2
    failed=sum(r['outcome']=='failed' for r in results)
    print(json.dumps({'schema_version':'1.0','outcome':'failed' if failed else 'passed','checked':len(results),'failed':failed,'records':results},indent=2))
    return 1 if failed else 0
if __name__=='__main__': raise SystemExit(main())
