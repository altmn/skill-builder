#!/usr/bin/env python3
"""Read-only checks for a deliberately narrow portable Agent Skills profile.

This is a format and direct-resource-link validator, not a skill executor,
security auditor, host compatibility test, or complete Markdown parser.
"""

from __future__ import annotations

import argparse
from bisect import bisect_left
import html
import json
from pathlib import Path
import re
import sys
from typing import Any
from urllib.parse import unquote, urlsplit

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore[assignment]


VERSION = "1.1.0"
PROFILE = "portable-conservative-v1"
OBSERVED_PYYAML_VERSION = "6.0.3"
MAX_SKILL_BYTES = 1024 * 1024
MAX_FRONTMATTER_BYTES = 64 * 1024
MAX_YAML_DEPTH = 32
MAX_LINK_DEPTH = 32
MAX_DIRECT_LINKS = 2048
NAME = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z", re.ASCII)
FIELDS = {"name", "description", "license", "compatibility", "metadata", "allowed-tools"}
PUNCTUATION = r"!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"
MARKDOWN_ESCAPE = re.compile(r"\\([" + re.escape(PUNCTUATION) + r"])")
NOT_CHECKED = [
    "Instruction quality, task success, model behavior, triggering, or evaluation quality.",
    "Host discovery, installation, permission enforcement, tool availability, or adapter metadata.",
    "Script execution, executable safety, dependency provenance, or malicious instructions/content.",
    "Resource contents, recursively linked documents, or files mentioned only in prose/code.",
    "Reference-style Markdown links, raw HTML links, autolinks, dynamic paths, or complete CommonMark conformance.",
    "External URL availability/content, query semantics, or fragment/heading targets.",
    "Filesystem race resistance: this is a point-in-time check, not a sandbox for later execution.",
]


if yaml is not None:
    class StrictSafeLoader(yaml.SafeLoader):
        """Safe constructors with bounded depth, no aliases/merges, unique string keys."""

        def compose_node(self, parent: Any, index: Any) -> Any:
            if self.check_event(yaml.AliasEvent):
                event = self.peek_event()
                raise yaml.constructor.ConstructorError(
                    None, None, "profile_alias_rejected", event.start_mark
                )
            depth = getattr(self, "_profile_depth", 0) + 1
            if depth > MAX_YAML_DEPTH:
                event = self.peek_event()
                raise yaml.constructor.ConstructorError(
                    None, None, "profile_depth_exceeded", event.start_mark
                )
            self._profile_depth = depth
            try:
                return super().compose_node(parent, index)
            finally:
                self._profile_depth -= 1

        def construct_mapping(self, node: Any, deep: bool = False) -> dict[str, Any]:
            if not isinstance(node, yaml.MappingNode):
                raise yaml.constructor.ConstructorError(
                    None, None, "profile_mapping_required", node.start_mark
                )
            result: dict[str, Any] = {}
            for key_node, value_node in node.value:
                if key_node.tag == "tag:yaml.org,2002:merge":
                    raise yaml.constructor.ConstructorError(
                        None, None, "profile_merge_rejected", key_node.start_mark
                    )
                key = self.construct_object(key_node, deep=True)
                if not isinstance(key, str):
                    raise yaml.constructor.ConstructorError(
                        None, None, "profile_string_key_required", key_node.start_mark
                    )
                if key in result:
                    raise yaml.constructor.ConstructorError(
                        None, None, "profile_duplicate_key", key_node.start_mark
                    )
                result[key] = self.construct_object(value_node, deep=deep)
            return result


def check(report: dict[str, Any], identifier: str, ok: bool | None, message: str,
          **details: Any) -> None:
    report["checks"].append({
        "id": identifier,
        "status": "not_checked" if ok is None else "passed" if ok else "failed",
        "message": message,
        **details,
    })


def finish(report: dict[str, Any]) -> dict[str, Any]:
    report["status"] = "failed" if any(c["status"] == "failed" for c in report["checks"]) else "passed"
    return report


# The raw-tag grammar is used only to keep literal delimiters in attributes
# from being interpreted as Markdown code/comment boundaries. HTML links and
# tag contents are never loaded or treated as checked resources.
HTML_TAG = re.compile(
    r"</[A-Za-z][A-Za-z0-9-]*[ \t\r\n]*>"
    r"|<[A-Za-z][A-Za-z0-9-]*(?:[ \t\r\n]+[A-Za-z_:][A-Za-z0-9_.:-]*"
    r"(?:[ \t\r\n]*=[ \t\r\n]*(?:[^ \t\r\n\"'=<>`]+|'[^']*'|\"[^\"]*\"))?)*"
    r"[ \t\r\n]*/?>"
)
HTML_BLOCK_TAGS = (
    "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|"
    "dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|"
    "h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|"
    "ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|"
    "title|tr|track|ul"
)
HTML_BLOCK_START = re.compile(r"^ {0,3}</?(?:" + HTML_BLOCK_TAGS + r")(?:[ \t]|/?>|$)", re.I)
AUTOLINK = re.compile(r"<(?:[A-Za-z][A-Za-z0-9+.-]{1,31}:[^<>\x00-\x20]*|"
                      r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+)>")


def mask_code_and_comments(text: str, errors: list[dict[str, Any]] | None = None,
                           first_line: int = 1) -> str:
    """Mask supported code/comments without pairing delimiters across blocks.

    This is deliberately a conservative recognizer, not a CommonMark renderer.
    Block fences and block comments take precedence; inline code and comments
    are scanned left to right within one paragraph/heading/list item. Constructs
    whose container/HTML interpretation is ambiguous fail the coverage gate.
    Newlines and offsets are preserved for useful resource diagnostics.
    """
    errors = errors if errors is not None else []
    blank = lambda value: "".join("\n" if char == "\n" else " " for char in value)

    def inline(value: str) -> str:
        chars = list(value)
        # Index runs once. Searching every remaining suffix for an unmatched
        # delimiter otherwise has quadratic cost on adversarial backtick runs.
        runs: dict[int, list[tuple[int, int]]] = {}
        for match in re.finditer(r"`+", value):
            runs.setdefault(len(match[0]), []).append(match.span())
        comment_ends = [match.start() for match in re.finditer("-->", value)]
        i = 0
        while i < len(value):
            if value[i] == "\\" and i + 1 < len(value):
                i += 2
                continue
            if value.startswith("](", i):
                # Link destinations/titles are literal syntax: '<name>' is
                # not an HTML tag and backticks here cannot mask later links.
                try:
                    _, stop = inline_destination(value, i + 2)
                except LinkSyntaxError:
                    pass  # The direct-link syntax gate diagnoses this later.
                else:
                    i = stop
                    continue
            if value.startswith("<!--", i):
                if value.startswith("<!-->", i):
                    stop = i + 2
                elif value.startswith("<!--->", i):
                    stop = i + 3
                else:
                    position = bisect_left(comment_ends, i + 4)
                    stop = comment_ends[position] if position < len(comment_ends) else -1
                # An unterminated inline opener is literal, unlike a block
                # comment opener at the beginning of a line.
                if stop >= 0:
                    stop += 3
                    chars[i:stop] = blank(value[i:stop])
                    i = stop
                    continue
            if value[i] == "<":
                matched = HTML_TAG.match(value, i) or AUTOLINK.match(value, i)
                stop = matched.end() if matched else -1
                if stop < 0:
                    for opener, closer in (("<?", "?>"), ("<![CDATA[", "]]>")):
                        if value.startswith(opener, i):
                            found = value.find(closer, i + len(opener))
                            stop = found + len(closer) if found >= 0 else -1
                            break
                    if stop < 0 and re.match(r"<![A-Za-z]", value[i:i+3]):
                        found = value.find(">", i + 3)
                        stop = found + 1 if found >= 0 else -1
                if stop >= 0:
                    chars[i:stop] = blank(value[i:stop])
                    i = stop
                    continue
            if value[i] == "`":
                end = i + 1
                while end < len(value) and value[end] == "`":
                    end += 1
                candidates = runs[end - i]
                index = bisect_left(candidates, (end, end))
                if index < len(candidates):
                    stop = candidates[index][1]
                    chars[i:stop] = blank(value[i:stop])
                    i = stop
                    continue
                i = end
                continue
            i += 1
        return "".join(chars)

    output: list[str] = []
    paragraph: list[str] = []
    fence: tuple[str, int] | None = None
    comment = False
    raw_html = False
    raw_html_end: re.Pattern[str] | None = None
    indented_code = False
    container = False
    reference_followup = False

    def flush() -> None:
        if paragraph:
            output.append(inline("".join(paragraph)))
            paragraph.clear()

    for number, line in enumerate(text.splitlines(keepends=True), first_line):
        bare = line.rstrip("\r\n")
        match = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", bare)
        if fence:
            output.append(blank(line))
            if (match and match[1][0] == fence[0] and len(match[1]) >= fence[1]
                    and not match[2].strip()):
                fence = None
            continue
        if raw_html:
            if raw_html_end is None and not bare.strip():
                raw_html = False
                output.append(line)
            else:
                output.append(blank(line))
                if raw_html_end is not None and raw_html_end.search(line):
                    raw_html = False
            continue
        if comment:
            output.append(blank(line))
            comment = "-->" not in line
            continue
        if re.match(r"^ {0,3}<!--", bare):
            flush()
            output.append(blank(line))
            comment = "-->" not in line
            continue
        html_end: re.Pattern[str] | None = None
        html_start = False
        special_tag = re.match(r"^ {0,3}<(script|pre|style|textarea)(?:[ \t]|>|$)", bare, re.I)
        if special_tag:
            html_start = True
            html_end = re.compile(r"</" + special_tag[1] + r">", re.I)
        elif re.match(r"^ {0,3}<\?", bare):
            html_start, html_end = True, re.compile(r"\?>")
        elif re.match(r"^ {0,3}<![A-Za-z]", bare):
            html_start, html_end = True, re.compile(">")
        elif re.match(r"^ {0,3}<!\[CDATA\[", bare):
            html_start, html_end = True, re.compile(r"\]\]>")
        elif HTML_BLOCK_START.match(bare):
            html_start = True
        elif not paragraph and len(bare) - len(bare.lstrip(" ")) <= 3:
            tag = HTML_TAG.match(bare.lstrip(" "))
            html_start = bool(tag and not bare.lstrip(" ")[tag.end():].strip())
        if html_start:
            flush()
            if container:
                errors.append({"line": number, "message":
                    "HTML block adjacent to a list/quote needs a full-parser check; link coverage is incomplete."})
            output.append(blank(line))
            raw_html = not (html_end and html_end.search(line))
            raw_html_end = html_end
            continue
        if match and not (match[1][0] == "`" and "`" in match[2]):
            flush()
            if container:
                errors.append({"line": number, "message":
                    "Fence adjacent to a list/quote has ambiguous container scope; link coverage is incomplete. Use an unambiguous top-level block or a full-parser gate."})
            fence = (match[1][0], len(match[1]))
            output.append(blank(line))
            continue
        if not bare.strip():
            flush()
            output.append(line)
            # Keep container context through blanks: an indented fence could
            # still belong to the preceding list item.
            continue
        if reference_followup:
            reference_followup = False
            if re.match(r"^ {0,3}[\"'(]", bare):
                candidate = "<> " + bare.strip() + ")"
                try:
                    _, stop = inline_destination(candidate, 0)
                    valid_title = stop == len(candidate)
                except LinkSyntaxError:
                    valid_title = False
                if valid_title:
                    output.append(blank(line))
                    continue
                errors.append({"line": number, "message":
                    "Multiline reference-definition title has unsupported scope; required link coverage is incomplete."})
                output.append(line)
                continue
        definition = re.match(r"^( {0,3}\[[^\]\n]+\]:)(.*)$", bare)
        if definition and not paragraph:
            candidate = definition[2] + ")"
            try:
                _, stop = inline_destination(candidate, 0)
                valid_definition = stop == len(candidate)
            except LinkSyntaxError:
                valid_definition = False
            if valid_definition:
                # Keep the definition marker for the explicit not_checked
                # count, while its literal URL/title cannot mask later links.
                output.append(definition[1] + blank(line[len(definition[1]):]))
                reference_followup = True
                continue
            errors.append({"line": number, "message":
                "Reference-definition syntax is incomplete or unsupported; required link coverage is incomplete."})
            output.append(line)
            continue
        is_container = bool(re.match(r"^ {0,3}(?:>|[-+*]\s|[0-9]{1,9}[.)]\s)", bare))
        if is_container:
            flush()
            container = True
            indented_code = False
            # Container blocks are checked one line at a time. We do not let
            # apparent delimiters consume another item or a following heading.
            if re.search(r"(?:^|\s)(?:`{3,}|~{3,})|<!--|<(?:/?[A-Za-z]|[!?])", bare):
                errors.append({"line": number, "message":
                    "Nested fence/comment scope is outside this recognizer; required link coverage is incomplete."})
            output.append(inline(line))
            continue
        if re.match(r"^(?: {4}|\t)", line):
            if container:
                if "`" in line or "<!--" in line or "](" in line:
                    errors.append({"line": number, "message":
                        "Indented container continuation needs a full-parser check; required link coverage is incomplete."})
                flush()
                output.append(inline(line))
            elif not paragraph or indented_code:
                flush()
                indented_code = True
                output.append(blank(line))
            else:
                paragraph.append(line)
            continue
        indented_code = False
        container = False
        is_heading = bool(re.match(r"^ {0,3}#{1,6}(?:[ \t]|$)", bare))
        is_separator = bool(re.match(r"^ {0,3}(?:=+|-+)[ \t]*$", bare)
                            or re.match(r"^ {0,3}(?:\*[ \t]*){3,}$", bare)
                            or re.match(r"^ {0,3}(?:_[ \t]*){3,}$", bare)
                            or re.match(r"^ {0,3}(?:-[ \t]*){3,}$", bare))
        if is_heading or is_separator:
            flush()
            output.append(inline(line))
            continue
        paragraph.append(line)
    flush()
    return "".join(output)


class LinkSyntaxError(ValueError):
    pass


def inline_destination(text: str, start: int) -> tuple[str, int]:
    """Parse the supported destination/title after ']('; return destination, next offset."""
    i = start
    while i < len(text) and text[i].isspace():
        i += 1
    begin = i
    if i < len(text) and text[i] == "<":
        i += 1
        begin = i
        while i < len(text):
            if text[i] in "\r\n" or text[i] == "<":
                raise LinkSyntaxError("Angle-bracket destination has a newline or nested '<'.")
            if text[i] == "\\" and i + 1 < len(text):
                i += 2
            elif text[i] == ">":
                break
            else:
                i += 1
        if i >= len(text):
            raise LinkSyntaxError("Unclosed angle-bracket destination.")
        destination = text[begin:i]
        i += 1
    else:
        depth = 0
        while i < len(text):
            char = text[i]
            if char == "\\" and i + 1 < len(text):
                i += 2
                continue
            if char == "(":
                depth += 1
                if depth > MAX_LINK_DEPTH:
                    raise LinkSyntaxError("Destination parentheses exceed the profile depth limit.")
            elif char == ")":
                if depth == 0:
                    return text[begin:i], i + 1
                depth -= 1
            elif char.isspace():
                if depth:
                    raise LinkSyntaxError("Bare destination contains unescaped whitespace.")
                break
            i += 1
        if depth:
            raise LinkSyntaxError("Unbalanced destination parentheses.")
        destination = text[begin:i]
    gap_start = i
    while i < len(text) and text[i].isspace():
        i += 1
    if i < len(text) and text[i] == ")":
        return destination, i + 1
    # An optional quoted or parenthesized title requires separating whitespace.
    if i == gap_start or i >= len(text) or text[i] not in "\"'(":
        raise LinkSyntaxError("Unsupported or incomplete inline-link destination/title syntax.")
    closer = ")" if text[i] == "(" else text[i]
    i += 1
    while i < len(text):
        if text[i] == "\\" and i + 1 < len(text):
            i += 2
        elif text[i] == closer:
            break
        elif closer == ")" and text[i] == "(":
            raise LinkSyntaxError("Nested parentheses in titles are outside this profile.")
        else:
            i += 1
    if i >= len(text):
        raise LinkSyntaxError("Unclosed inline-link title.")
    i += 1
    while i < len(text) and text[i].isspace():
        i += 1
    if i >= len(text) or text[i] != ")":
        raise LinkSyntaxError("Inline link has no closing ')'.")
    return destination, i + 1


def direct_links(body: str, first_line: int) -> tuple[list[tuple[str, int]], list[dict[str, Any]], int]:
    errors: list[dict[str, Any]] = []
    text = mask_code_and_comments(body, errors, first_line)
    links: list[tuple[str, int]] = []
    brackets: list[int] = []
    newlines = [index for index, char in enumerate(text) if char == "\n"]
    i = 0
    while i < len(text):
        if text[i] == "\\" and i + 1 < len(text):
            i += 2
            continue
        if text[i] == "[":
            brackets.append(i)
        elif text[i] == "]" and brackets:
            opened = brackets.pop()
            if i + 1 < len(text) and text[i + 1] == "(":
                line = first_line + bisect_left(newlines, opened)
                if len(links) >= MAX_DIRECT_LINKS:
                    errors.append({"line": line, "message": "Direct links exceed this profile's 2,048-link limit; remaining links were not checked."})
                    break
                try:
                    destination, stop = inline_destination(text, i + 2)
                    links.append((destination, line))
                    i = stop
                    continue
                except LinkSyntaxError as exc:
                    errors.append({"line": line, "message": str(exc)})
        i += 1
    definitions = len(re.findall(r"^ {0,3}\[[^\]\n]+\]:", text, re.MULTILINE))
    return links, errors, definitions


def resource_check(root: Path, raw: str, line: int) -> dict[str, Any]:
    base: dict[str, Any] = {"line": line}
    destination = html.unescape(MARKDOWN_ESCAPE.sub(r"\1", raw))

    def result(status: str, code: str, message: str, **extra: Any) -> dict[str, Any]:
        return {**base, "status": status, "code": code, "message": message, **extra}

    if any(ord(c) < 32 or ord(c) == 127 for c in destination):
        return result("failed", "resource.control_character", "Destination contains a control character.")
    if "\\" in destination or re.match(r"^[A-Za-z]:", destination):
        return result("failed", "resource.nonportable_path", "Backslashes and drive-letter paths are outside the portable profile.")
    try:
        parsed = urlsplit(destination)
    except ValueError:
        return result("failed", "resource.invalid_uri", "Destination cannot be parsed as a URI reference.")
    if parsed.scheme.lower() == "file":
        return result("failed", "resource.file_uri", "file: URIs are not relative skill resources.")
    if parsed.scheme or parsed.netloc or destination.startswith("//"):
        return result("not_checked", "resource.external", "External URI was not fetched or validated.")
    if not parsed.path:
        return result("not_checked", "resource.fragment_or_empty", "Empty/fragment/query-only link has no resource path to check.")
    if re.search(r"%(?![0-9A-Fa-f]{2})", parsed.path):
        return result("failed", "resource.invalid_encoding", "Resource path has an invalid percent escape.")
    try:
        decoded = unquote(parsed.path, encoding="utf-8", errors="strict")
    except UnicodeDecodeError:
        return result("failed", "resource.invalid_encoding", "Percent-encoded resource path is not UTF-8.")
    if re.search(r"%[0-9A-Fa-f]{2}", decoded):
        return result("failed", "resource.nested_encoding", "Nested percent encoding is outside this conservative profile.")
    if any(ord(c) < 32 or ord(c) == 127 for c in decoded) or "\\" in decoded:
        return result("failed", "resource.nonportable_path", "Decoded resource path has a control character or backslash.")
    if decoded.startswith("/") or re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", decoded):
        return result("failed", "resource.absolute_path", "Absolute paths and encoded URI schemes are not relative skill resources.")
    # Report no query/fragment or file contents. Do not expand shell variables or '~'.
    display = decoded[:240] + ("…" if len(decoded) > 240 else "")
    try:
        target = (root / decoded).resolve(strict=True)
        if not target.is_relative_to(root):
            return result("failed", "resource.escape", "Resource resolves outside the selected skill root.", path=display)
        if not target.is_file():
            return result("failed", "resource.not_file", "Resource target is not a regular file.", path=display)
    except (OSError, RuntimeError, ValueError):
        return result("failed", "resource.unresolved", "Resource is missing, unreadable, or has an unresolvable symlink.", path=display)
    return result("passed", "resource.contained_file", "Relative resource exists as a file within the selected root.", path=display)


def validate_skill(directory: str | Path) -> dict[str, Any]:
    report: dict[str, Any] = {"input": str(directory), "checks": [], "resources": [], "warnings": []}
    requested = Path(directory).expanduser().absolute()
    try:
        root = requested.resolve(strict=True)
        if not root.is_dir():
            raise NotADirectoryError
    except (OSError, RuntimeError, ValueError):
        check(report, "directory", False, "Explicit skill directory is missing, inaccessible, or not a directory.")
        return finish(report)
    report["root"] = str(root)
    check(report, "directory", True, "Selected directory resolves; this resolved path is the resource boundary.")
    try:
        source = (root / "SKILL.md").resolve(strict=True)
        if not source.is_relative_to(root) or not source.is_file():
            check(report, "skill_file", False, "SKILL.md must resolve to a regular file inside this skill root.")
            return finish(report)
        # Bounded read; do not trust a preceding stat size or read linked resource bodies.
        with source.open("rb") as stream:
            data = stream.read(MAX_SKILL_BYTES + 1)
    except (OSError, RuntimeError, ValueError):
        check(report, "skill_file", False, "SKILL.md is missing, inaccessible, or has an unresolvable symlink.")
        return finish(report)
    if len(data) > MAX_SKILL_BYTES:
        check(report, "skill_file", False, "SKILL.md exceeds this validator's 1 MiB input limit.")
        return finish(report)
    try:
        text = data.decode("utf-8-sig", errors="strict")
    except UnicodeDecodeError:
        check(report, "skill_file", False, "SKILL.md must be UTF-8 text; a UTF-8 BOM is accepted.")
        return finish(report)
    if "\0" in text:
        check(report, "skill_file", False, "SKILL.md must not contain NUL bytes.")
        return finish(report)
    check(report, "skill_file", True, "SKILL.md is bounded UTF-8 text within the selected root.", bytes=len(data))
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].rstrip("\r\n") != "---":
        check(report, "frontmatter.delimiters", False, "The first line must be exactly '---'.")
        return finish(report)
    closing = next((i for i in range(1, len(lines)) if lines[i].rstrip("\r\n") == "---"), None)
    if closing is None:
        check(report, "frontmatter.delimiters", False, "Frontmatter requires a closing line exactly '---'.")
        return finish(report)
    check(report, "frontmatter.delimiters", True, "Opening and closing frontmatter delimiters are present.")
    front = "".join(lines[1:closing])
    body = "".join(lines[closing + 1:])
    check(report, "body.nonempty", bool(body.strip()), "Markdown body must contain non-whitespace text.")
    if len(front.encode("utf-8")) > MAX_FRONTMATTER_BYTES:
        check(report, "frontmatter.yaml", False, "Frontmatter exceeds this validator's 64 KiB limit.")
        return finish(report)
    if yaml is None:
        raise RuntimeError("PyYAML is unavailable")
    try:
        fields = yaml.load(front, Loader=StrictSafeLoader)
    except yaml.YAMLError as exc:
        # Do not echo YAML values, source excerpts, unsafe tag arguments, or parser snippets.
        problem = getattr(exc, "problem", "") or ""
        code = problem if problem.startswith("profile_") else "safe_yaml_rejected"
        mark = getattr(exc, "problem_mark", None)
        check(report, "frontmatter.yaml", False,
              "Safe YAML parsing rejected malformed/unsafe or unsupported YAML.",
              reason=code, **({"line": mark.line + 2} if mark is not None else {}))
        return finish(report)
    except (ValueError, OverflowError, RecursionError):
        check(report, "frontmatter.yaml", False,
              "YAML scalar or structure exceeded the parser's safe processing limits.",
              reason="parser_processing_limit")
        return finish(report)
    check(report, "frontmatter.yaml", True, "Safe YAML parsed with unique string keys and bounded depth; aliases/merges are disallowed.")
    if not isinstance(fields, dict):
        check(report, "frontmatter.mapping", False, "Frontmatter must be a YAML mapping.")
        return finish(report)
    check(report, "frontmatter.mapping", True, "Frontmatter is a mapping.")
    unknown = sorted(set(fields) - FIELDS)
    check(report, "frontmatter.fields", not unknown,
          "Only current standard fields are accepted; host extensions require a separate adapter check.",
          **({"unknown_fields": unknown} if unknown else {}))
    name = fields.get("name")
    valid_name = isinstance(name, str) and 1 <= len(name) <= 64 and NAME.fullmatch(name) is not None
    check(report, "name.format", valid_name,
          "name must be 1–64 ASCII lowercase letters/digits with single interior hyphens.")
    check(report, "name.directory", isinstance(name, str) and name == requested.name,
          "name must equal the explicitly selected directory's final component.")
    description = fields.get("description")
    check(report, "description", isinstance(description, str) and bool(description.strip()) and len(description) <= 1024,
          "description must be a nonblank string of at most 1,024 characters.")
    for field in ("license", "compatibility", "allowed-tools"):
        if field not in fields:
            continue
        value = fields[field]
        ok = isinstance(value, str) and (field != "compatibility" or 1 <= len(value) <= 500)
        check(report, f"field.{field}", ok,
              f"{field} must be a string" + (" of 1–500 characters when provided." if field == "compatibility" else "."))
        if isinstance(value, str) and not value.strip():
            report["warnings"].append(f"Optional field '{field}' is empty; omitting it is clearer.")
    if "allowed-tools" in fields:
        report["warnings"].append("allowed-tools is experimental standard metadata; no tool names, host syntax, or permission semantics were verified.")
    if "metadata" in fields:
        metadata = fields["metadata"]
        check(report, "field.metadata", isinstance(metadata, dict) and all(
            isinstance(k, str) and isinstance(v, str) for k, v in metadata.items()),
            "metadata must be a mapping from strings to strings; quote numeric/Boolean/date-like values.")
    links, syntax_errors, reference_definitions = direct_links(body, closing + 2)
    check(report, "links.supported_syntax", not syntax_errors,
          "Block/inline coverage and direct Markdown destination/title syntax fit the supported subset; unsupported ambiguous masking fails this gate.",
          **({"errors": syntax_errors} if syntax_errors else {}))
    for destination, line in links:
        report["resources"].append(resource_check(root, destination, line))
    failed_resources = sum(r["status"] == "failed" for r in report["resources"])
    check(report, "links.relative_resources", failed_resources == 0,
          "Recognized direct relative links must resolve to files within this skill root; external URIs are not fetched.",
          recognized=len(links), failed=failed_resources,
          passed=sum(r["status"] == "passed" for r in report["resources"]),
          not_checked=sum(r["status"] == "not_checked" for r in report["resources"]))
    if reference_definitions:
        check(report, "links.reference_style", None,
              "Reference-style definitions were detected and are outside this validator's direct-link scope.",
              definitions=reference_definitions)
    return finish(report)


class UsageError(ValueError):
    pass


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise UsageError(message)


def main(argv: list[str] | None = None) -> int:
    parser = JsonArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", help="Explicit skill directory paths; no recursive discovery or installation.")
    parser.add_argument("--compact", action="store_true", help="Emit compact JSON instead of indented JSON.")
    base: dict[str, Any] = {
        "schema_version": 1,
        "validator": {"name": "portable-agent-skill-format-validator", "version": VERSION, "profile": PROFILE,
                      "python": sys.version.split()[0], "PyYAML": getattr(yaml, "__version__", None)},
        "not_checked": NOT_CHECKED,
    }
    compact = False
    try:
        args = parser.parse_args(argv)
        compact = args.compact
        if yaml is None:
            raise UsageError("PyYAML is required. See tools/requirements.txt and tools/README.md; nothing was installed automatically.")
        reports = [validate_skill(directory) for directory in args.directories]
        failures = sum(report["status"] == "failed" for report in reports)
        output = {**base, "status": "failed" if failures else "passed", "summary": {
            "skills": len(reports), "passed": len(reports) - failures, "failed": failures}, "skills": reports}
        if yaml.__version__ != OBSERVED_PYYAML_VERSION:
            output["warnings"] = [f"This validator was tested with PyYAML {OBSERVED_PYYAML_VERSION}; the current dependency version differs."]
        code = 1 if failures else 0
    except UsageError as exc:
        output = {**base, "status": "error", "error": {"code": "usage_or_dependency", "message": str(exc)}, "skills": []}
        code = 2
    except Exception as exc:
        output = {**base, "status": "error", "error": {
            "code": "validator_error", "type": type(exc).__name__,
            "message": "The validator could not complete; no format or security assurance is implied."}, "skills": []}
        code = 2
    print(json.dumps(output, ensure_ascii=False, indent=None if compact else 2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
