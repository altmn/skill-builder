"""Offline regression tests; fixtures exist only in TemporaryDirectory roots."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


SCRIPT = Path(__file__).resolve().parents[1] / "validate_skill.py"
spec = importlib.util.spec_from_file_location("portable_skill_validator", SCRIPT)
assert spec is not None and spec.loader is not None
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)


class PortableSkillValidation(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="skill-format-validator-")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / "example-skill"
        self.root.mkdir()

    def write(self, front: str | None = None, body: str = "# Task\n\nPerform the requested task.\n") -> Path:
        front = front if front is not None else "name: example-skill\ndescription: Do a clearly defined task.\n"
        file = self.root / "SKILL.md"
        file.write_text("---\n" + front + "---\n" + body, encoding="utf-8")
        return file

    def validate(self) -> dict:
        return validator.validate_skill(self.root)

    def failure(self, identifier: str, report: dict | None = None) -> dict:
        report = report if report is not None else self.validate()
        self.assertEqual(report["status"], "failed", report)
        matches = [c for c in report["checks"] if c["id"] == identifier and c["status"] == "failed"]
        self.assertTrue(matches, report)
        return matches[0]

    def resource_failure(self, destination: str, expected_code: str | None = None) -> dict:
        self.write(body=f"Read [the resource]({destination}).\n")
        report = self.validate()
        self.failure("links.relative_resources", report)
        failures = [r for r in report["resources"] if r["status"] == "failed"]
        self.assertEqual(len(failures), 1, report)
        if expected_code:
            self.assertEqual(failures[0]["code"], expected_code, report)
        return report

    def symlink(self, source: Path, target: Path) -> None:
        try:
            source.symlink_to(target, target_is_directory=target.is_dir())
        except (OSError, NotImplementedError) as exc:
            self.skipTest(f"Symlink creation is unavailable on this test platform: {type(exc).__name__}")

    def test_standard_optional_fields_including_compatibility_pass(self) -> None:
        self.write("name: example-skill\ndescription: Do a task.\nlicense: MIT\n"
                   "compatibility: Python 3.10 or newer.\nmetadata:\n  version: '1.0'\n"
                   "  reviewed: 'true'\nallowed-tools: Read Bash\n")
        result = self.validate()
        self.assertEqual(result["status"], "passed", result)
        self.assertTrue(any("experimental" in warning for warning in result["warnings"]))

    def test_public_helper_gap_empty_required_strings_fail(self) -> None:
        self.write("name: ''\ndescription: ''\n")
        result = self.validate()
        self.failure("name.format", result)
        self.failure("description", result)

    def test_whitespace_description_is_not_content(self) -> None:
        self.write("name: example-skill\ndescription: '   '\n")
        self.failure("description")

    def test_public_helper_gap_directory_name_mismatch_fails(self) -> None:
        self.write("name: another-skill\ndescription: Do a task.\n")
        self.failure("name.directory")

    def test_missing_and_nonstring_required_values_fail(self) -> None:
        for front in ("description: A task\n", "name: example-skill\n",
                      "name: null\ndescription: A task\n", "name: example-skill\ndescription: true\n",
                      "name: example-skill\ndescription: [one, two]\n"):
            with self.subTest(front=front):
                self.write(front)
                self.assertEqual(self.validate()["status"], "failed")

    def test_conservative_ascii_name_policy(self) -> None:
        for name in ("Uppercase", "a--b", "-leading", "trailing-", "snake_case", "naïve", "a" * 65):
            with self.subTest(name=name):
                self.write(f"name: {name}\ndescription: A task\n")
                self.failure("name.format")

    def test_name_and_description_limits_count_characters(self) -> None:
        long_root = self.base / ("a" * 64)
        self.root.rename(long_root)
        self.root = long_root
        self.write("name: " + "a" * 64 + "\ndescription: '" + "é" * 1024 + "'\n")
        self.assertEqual(self.validate()["status"], "passed")
        self.write("name: " + "a" * 64 + "\ndescription: '" + "é" * 1025 + "'\n")
        self.failure("description")

    def test_compatibility_500_characters_passes_501_fails(self) -> None:
        self.write("name: example-skill\ndescription: Task\ncompatibility: '" + "x" * 500 + "'\n")
        self.assertEqual(self.validate()["status"], "passed")
        self.write("name: example-skill\ndescription: Task\ncompatibility: '" + "x" * 501 + "'\n")
        self.failure("field.compatibility")

    def test_compatibility_requires_at_least_one_character_if_provided(self) -> None:
        self.write("name: example-skill\ndescription: Task\ncompatibility: ''\n")
        self.failure("field.compatibility")
        self.write("name: example-skill\ndescription: Task\ncompatibility: x\n")
        self.assertEqual(self.validate()["status"], "passed")
        self.write("name: example-skill\ndescription: Task\ncompatibility: ' '\n")
        result = self.validate()
        self.assertEqual(result["status"], "passed")
        self.assertTrue(any("compatibility" in warning for warning in result["warnings"]))

    def test_optional_types_and_metadata_are_enforced(self) -> None:
        for field in ("license", "compatibility", "allowed-tools"):
            with self.subTest(field=field):
                self.write(f"name: example-skill\ndescription: Task\n{field}: [one, two]\n")
                self.failure(f"field.{field}")
        for metadata in ("false", "[]", "{version: 1}", "{enabled: true}", "{nested: {a: b}}"):
            with self.subTest(metadata=metadata):
                self.write(f"name: example-skill\ndescription: Task\nmetadata: {metadata}\n")
                self.failure("field.metadata")

    def test_unknown_host_extensions_are_not_silently_accepted(self) -> None:
        for field in ("hooks", "model", "user-invocable", "disable-model-invocation", "argument-hint"):
            with self.subTest(field=field):
                self.write(f"name: example-skill\ndescription: Task\n{field}: value\n")
                failed = self.failure("frontmatter.fields")
                self.assertEqual(failed["unknown_fields"], [field])

    def test_yaml_duplicate_top_level_and_metadata_keys_fail(self) -> None:
        for extra in ("name: example-skill\n", "metadata:\n  key: first\n  key: second\n"):
            with self.subTest(extra=extra):
                self.write("name: example-skill\ndescription: Task\n" + extra)
                failed = self.failure("frontmatter.yaml")
                self.assertEqual(failed["reason"], "profile_duplicate_key")

    def test_unsafe_yaml_tag_is_rejected_without_constructing_objects(self) -> None:
        self.write("name: example-skill\ndescription: !!python/name:builtins.str ''\n")
        self.failure("frontmatter.yaml")

    def test_aliases_merges_and_excessive_depth_are_rejected(self) -> None:
        cases = [
            ("name: &n example-skill\ndescription: *n\n", "profile_alias_rejected"),
            ("name: example-skill\ndescription: Task\nmetadata:\n  <<: {a: b}\n", "profile_merge_rejected"),
            ("name: example-skill\ndescription: " + "[" * 40 + "x" + "]" * 40 + "\n", "profile_depth_exceeded"),
        ]
        for front, reason in cases:
            with self.subTest(reason=reason):
                self.write(front)
                self.assertEqual(self.failure("frontmatter.yaml")["reason"], reason)

    def test_nonstring_mapping_keys_and_nonmapping_frontmatter_fail(self) -> None:
        self.write("name: example-skill\ndescription: Task\nmetadata:\n  1: one\n")
        self.assertEqual(self.failure("frontmatter.yaml")["reason"], "profile_string_key_required")
        self.write("- one\n- two\n")
        self.failure("frontmatter.mapping")

    def test_parse_errors_do_not_echo_source_values(self) -> None:
        self.write("name: example-skill\ndescription: [SENSITIVE_TEST_SENTINEL\n")
        result = self.validate()
        self.failure("frontmatter.yaml", result)
        self.assertNotIn("SENSITIVE_TEST_SENTINEL", json.dumps(result))

    def test_extreme_yaml_integer_is_a_failed_check_not_an_unhandled_error(self) -> None:
        self.write("name: example-skill\ndescription: " + "9" * 6000 + "\n")
        result = self.validate()
        self.assertEqual(result["status"], "failed", result)
        # Python versions with an integer-conversion bound reject at YAML parsing;
        # other versions parse an integer, which still fails the string field type.
        self.assertTrue(any(c["status"] == "failed" and c["id"] in {"frontmatter.yaml", "description"}
                            for c in result["checks"]))

    def test_empty_body_fails(self) -> None:
        self.write(body=" \n\t\n")
        self.failure("body.nonempty")

    def test_missing_delimiters_invalid_encoding_and_nul_fail(self) -> None:
        for raw in (b"name: example-skill\n", b"---\nname: example-skill\n",
                    b"---\nname: example-skill\n---\n\xff", b"---\nname: example-skill\n---\n\0"):
            with self.subTest(raw=raw):
                (self.root / "SKILL.md").write_bytes(raw)
                self.assertEqual(self.validate()["status"], "failed")

    def test_crlf_and_utf8_bom_are_accepted(self) -> None:
        (self.root / "SKILL.md").write_bytes(b"\xef\xbb\xbf---\r\nname: example-skill\r\ndescription: Task\r\n---\r\n# Task\r\n")
        self.assertEqual(self.validate()["status"], "passed")

    def test_document_and_frontmatter_input_limits_are_bounded(self) -> None:
        (self.root / "SKILL.md").write_bytes(b"x" * (validator.MAX_SKILL_BYTES + 1))
        self.failure("skill_file")
        self.write("name: example-skill\ndescription: Task\n#" + "x" * validator.MAX_FRONTMATTER_BYTES + "\n")
        self.failure("frontmatter.yaml")

    def test_direct_resources_titles_fragments_percent_spaces_and_images(self) -> None:
        refs = self.root / "references"
        refs.mkdir()
        for name in ("guide.md", "with space.md", "a(b).md", "has#hash.md", "café.md"):
            (refs / name).write_text("# Resource\n")
        self.write(body="\n".join([
            '[Guide](references/guide.md "A title")',
            '![Image](<references/with space.md>)',
            '[Encoded](references/with%20space.md#heading)',
            '[Nested](references/a(b).md)',
            r'[Escaped](references/a\(b\).md)',
            '[Hash](references/has%23hash.md)',
            '[Unicode](references/caf%C3%A9.md)',
        ]))
        result = self.validate()
        self.assertEqual(result["status"], "passed", result)
        self.assertEqual(len(result["resources"]), 7)
        self.assertTrue(all(r["status"] == "passed" for r in result["resources"]))

    def test_missing_target_and_directory_target_fail(self) -> None:
        self.resource_failure("references/missing.md", "resource.unresolved")
        (self.root / "references").mkdir()
        self.resource_failure("references", "resource.not_file")

    def test_parent_traversal_and_percent_encoded_traversal_fail(self) -> None:
        (self.base / "outside.md").write_text("private fixture\n")
        for destination in ("../outside.md", "%2e%2e/outside.md", "%2e%2e%2foutside.md"):
            with self.subTest(destination=destination):
                self.resource_failure(destination, "resource.escape")

    def test_absolute_file_uris_windows_and_encoded_absolute_paths_fail(self) -> None:
        outside = self.base / "outside.md"
        outside.write_text("private fixture\n")
        for destination in (outside.as_posix(), outside.as_uri(), "C:/outside.md", r"..\outside.md",
                            "%2Ftmp/outside.md", "file%3Aout.md", "%5Coutside.md"):
            with self.subTest(destination=destination):
                self.resource_failure(destination)

    def test_invalid_nested_and_control_character_encodings_fail(self) -> None:
        for destination in ("bad%escape.md", "%252e%252e/outside.md", "bad%00.md", "bad%0a.md", "bad%FF.md"):
            with self.subTest(destination=destination):
                self.resource_failure(destination)

    def test_file_symlink_escape_fails(self) -> None:
        outside = self.base / "outside.md"
        outside.write_text("private fixture\n")
        self.symlink(self.root / "link.md", outside)
        self.resource_failure("link.md", "resource.escape")

    def test_directory_symlink_escape_fails(self) -> None:
        elsewhere = self.base / "elsewhere"
        elsewhere.mkdir()
        (elsewhere / "guide.md").write_text("private fixture\n")
        self.symlink(self.root / "references", elsewhere)
        self.resource_failure("references/guide.md", "resource.escape")

    def test_contained_symlink_is_allowed(self) -> None:
        target = self.root / "guide.md"
        target.write_text("# Guide\n")
        self.symlink(self.root / "link.md", target)
        self.write(body="Read [guide](link.md).\n")
        self.assertEqual(self.validate()["status"], "passed")

    def test_skill_file_symlink_escape_fails_before_reading_content(self) -> None:
        outside = self.base / "outside.md"
        outside.write_text("SENSITIVE_TEST_SENTINEL\n")
        self.symlink(self.root / "SKILL.md", outside)
        result = self.validate()
        self.failure("skill_file", result)
        self.assertNotIn("SENSITIVE_TEST_SENTINEL", json.dumps(result))

    def test_external_and_anchor_links_are_explicitly_not_checked(self) -> None:
        self.write(body="[Remote](https://invalid.example/never-fetch?q=SECRET_QUERY)\n"
                        "[Email](mailto:example@example.invalid)\n[Here](#heading)\n")
        with patch("socket.create_connection", side_effect=AssertionError("No network is allowed")):
            result = self.validate()
        self.assertEqual(result["status"], "passed", result)
        self.assertEqual([r["status"] for r in result["resources"]], ["not_checked"] * 3)
        self.assertNotIn("SECRET_QUERY", json.dumps(result))

    def test_code_comments_and_reference_links_are_not_claimed_as_resource_checks(self) -> None:
        self.write(body="```markdown\n[example](../outside.md)\n```\n"
                        "`[example](../outside.md)`\n<!-- [example](../outside.md) -->\n"
                        "[reference][ref]\n[ref]: ../outside.md\n")
        result = self.validate()
        self.assertEqual(result["status"], "passed", result)
        self.assertEqual(result["resources"], [])
        self.assertTrue(any(c["id"] == "links.reference_style" and c["status"] == "not_checked"
                            for c in result["checks"]))

    def test_escaped_backticks_do_not_hide_an_actual_resource_link(self) -> None:
        (self.base / "outside.md").write_text("private fixture\n")
        self.write(body=r"\`[guide](../outside.md)\`" + "\n")
        self.failure("links.relative_resources")

    def test_literal_comment_opener_inside_code_does_not_hide_following_link(self) -> None:
        self.write(body="Use `<!--` to start an HTML comment.\n\n"
                        "Read [the guide](references/missing.md).\n")
        result = self.validate()
        self.failure("links.relative_resources", result)
        self.assertEqual(len(result["resources"]), 1, result)
        self.assertEqual(result["resources"][0]["line"], 7)
        cli = subprocess.run([sys.executable, "-B", str(SCRIPT), str(self.root)],
                             capture_output=True, text=True, timeout=10)
        self.assertEqual(cli.returncode, 1, cli.stderr)
        self.assertEqual(json.loads(cli.stdout)["status"], "failed")

    def test_literal_backticks_in_distinct_paragraphs_do_not_form_code(self) -> None:
        self.write(body="Literal ` delimiter.\n\n"
                        "Read [guide](references/missing.md).\n\nAnother ` delimiter.\n")
        result = self.validate()
        self.failure("links.relative_resources", result)
        self.assertEqual(len(result["resources"]), 1, result)

    def test_literal_backticks_across_heading_do_not_form_code(self) -> None:
        self.write(body="Literal ` delimiter.\n# Separate block\n"
                        "Read [guide](references/missing.md).\nAnother ` delimiter.\n")
        result = self.validate()
        self.failure("links.relative_resources", result)
        self.assertEqual(len(result["resources"]), 1, result)

    def test_real_multiline_inline_code_remains_excluded(self) -> None:
        self.write(body="Example `this code spans\n"
                        "[guide](references/missing.md) and <!--` within one paragraph.\n")
        result = self.validate()
        self.assertEqual(result["status"], "passed", result)
        self.assertEqual(result["resources"], [])

    def test_real_comments_win_over_backticks_inside_them(self) -> None:
        self.write(body="Text <!-- ` [example](references/missing.md) --> after.\n\n"
                        "<!-- a block comment\n\n[example](references/missing.md) `\n-->\n")
        result = self.validate()
        self.assertEqual(result["status"], "passed", result)
        self.assertEqual(result["resources"], [])

    def test_unterminated_inline_comment_is_literal(self) -> None:
        self.write(body="Literal <!-- followed by [guide](references/missing.md).\n")
        self.failure("links.relative_resources")

    def test_short_inline_comment_does_not_hide_later_link(self) -> None:
        for opener in ("<!-->", "<!--->"):
            with self.subTest(opener=opener):
                self.write(body=f"Text {opener} [guide](references/missing.md) -->\n")
                self.failure("links.relative_resources")

    def test_nested_fence_ambiguity_fails_required_coverage_gate(self) -> None:
        self.write(body="> ```markdown\n> [guide](references/missing.md)\n> ```\n")
        failed = self.failure("links.supported_syntax")
        self.assertTrue(any("coverage is incomplete" in item["message"]
                            for item in failed["errors"]))

    def test_html_attribute_delimiter_does_not_hide_a_later_link(self) -> None:
        self.write(body='Text <span title="`"> [guide](references/missing.md) ` after.\n')
        self.failure("links.relative_resources")

    def test_fence_and_indented_code_are_excluded_then_following_link_is_checked(self) -> None:
        self.write(body="```markdown\nUse `<!--`\n[example](references/absent.md)\n```\n\n"
                        "    [example](references/also-absent.md)\n\n"
                        "[guide](references/missing.md)\n")
        result = self.validate()
        self.failure("links.relative_resources", result)
        self.assertEqual(len(result["resources"]), 1, result)

    def test_angle_destination_cannot_be_masked_as_html(self) -> None:
        for destination in ("<missing>", "<missing.md>", "<missing with spaces>"):
            with self.subTest(destination=destination):
                self.resource_failure(destination, "resource.unresolved")

    def test_literal_destination_delimiters_cannot_hide_following_resource(self) -> None:
        self.write(body='[Remote](https://example.invalid/`literal) '
                        '[guide](references/missing.md) `after\n')
        result = self.validate()
        self.failure("links.relative_resources", result)
        self.assertEqual(len(result["resources"]), 2)

    def test_raw_html_block_end_cannot_extend_code_or_comment_masking(self) -> None:
        for opener in ("Text `", "<!--"):
            with self.subTest(opener=opener):
                self.write(body=f"<pre>\n{opener}\n</pre>\n"
                                "[guide](references/missing.md)\nend ` -->\n")
                self.failure("links.relative_resources")

    def test_inline_html_cdata_and_processing_instructions_protect_their_delimiters(self) -> None:
        for html in ('<span title="\n`">', '<![CDATA[`]]>', '<?xml `?>',
                     '<https://example.invalid/`>'):
            with self.subTest(html=html):
                self.write(body=f'Text {html} [guide](references/missing.md) `after\n')
                self.failure("links.relative_resources")

    def test_list_quote_and_heading_boundaries_do_not_create_cross_block_code(self) -> None:
        for body in (
                "- First `\n- Second [guide](references/missing.md)\n- End `\n",
                "> First `\n> # Heading\n> [guide](references/missing.md)\n> End `\n",
                "> First `\n>\n> [guide](references/missing.md)\n>\n> End `\n",
                "Text `\n<!DOCTYPE html>\n[guide](references/missing.md)\n`\n"):
            with self.subTest(body=body):
                self.write(body=body)
                result = self.validate()
                self.assertEqual(result["status"], "failed", result)
                cli = subprocess.run([sys.executable, "-B", str(SCRIPT), str(self.root)],
                                     capture_output=True, text=True, timeout=10)
                self.assertEqual(cli.returncode, 1, cli.stderr)

    def test_reference_definition_delimiters_cannot_mask_later_direct_links(self) -> None:
        for definition in ("[ref]: https://example.invalid/`\n",
                           '[ref]: url\n "Title `"\n'):
            with self.subTest(definition=definition):
                self.write(body=definition+'[guide](references/missing.md)\n`\n')
                self.failure("links.relative_resources")

    def test_recognized_but_incomplete_direct_link_fails_conservatively(self) -> None:
        self.write(body="Read [guide](<references/guide.md\n")
        self.failure("links.supported_syntax")

    def test_link_limit_fails_instead_of_silently_ignoring_tail(self) -> None:
        self.write(body="[anchor](#here)\n" * (validator.MAX_DIRECT_LINKS + 1))
        result = self.validate()
        self.failure("links.supported_syntax", result)
        self.assertEqual(len(result["resources"]), validator.MAX_DIRECT_LINKS)

    def test_validation_does_not_change_payload(self) -> None:
        self.write()
        before = {p.relative_to(self.root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(self.validate()["status"], "passed")
        after = {p.relative_to(self.root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)

    def test_cli_aggregate_exit_codes_and_json_scope(self) -> None:
        self.write()
        good = subprocess.run([sys.executable, "-B", str(SCRIPT), str(self.root)], capture_output=True, text=True, timeout=10)
        self.assertEqual(good.returncode, 0, good.stderr)
        result = json.loads(good.stdout)
        self.assertEqual(result["status"], "passed")
        self.assertTrue(result["not_checked"])
        mixed = subprocess.run([sys.executable, "-B", str(SCRIPT), str(self.root), str(self.base / "missing")],
                               capture_output=True, text=True, timeout=10)
        self.assertEqual(mixed.returncode, 1, mixed.stderr)
        self.assertEqual(json.loads(mixed.stdout)["summary"], {"skills": 2, "passed": 1, "failed": 1})
        misuse = subprocess.run([sys.executable, "-B", str(SCRIPT)], capture_output=True, text=True, timeout=10)
        self.assertEqual(misuse.returncode, 2, misuse.stderr)
        self.assertEqual(json.loads(misuse.stdout)["status"], "error")


if __name__ == "__main__":
    unittest.main()
