import importlib.util
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('profile_view',ROOT/'tools/profile_view.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Profiles(unittest.TestCase):
    def rows(self,p,*mods):return {r['rule_id']:r for r in m.select(p,mods)['rules']}
    def test_every_rule_has_one_decision(self):
        for p in ['instruction','resource_assisted','suite_runtime']:
            rows=m.select(p)['rules'];self.assertEqual(99,len(rows));self.assertEqual(99,len({r['rule_id'] for r in rows}))
    def test_writing_skill_has_no_daemon_or_migration_gate(self):
        rows=self.rows('instruction')
        self.assertEqual('not_applicable',rows['PERF-005']['decision']);self.assertEqual('not_applicable',rows['LIFE-006']['decision'])
    def test_script_skill_adopts_command_contracts(self):
        rows=self.rows('resource_assisted')
        for rid in ['CMD-001','CMD-002','CMD-003','CMD-005','CMD-006','HOST-005']:
            self.assertEqual('adopted',rows[rid]['decision'])
    def test_publication_requires_authorization(self):
        self.assertEqual('adopted',self.rows('instruction','publication')['LIFE-012']['decision'])
    def test_override_is_explicit(self):
        with self.assertRaises(ValueError): m.select('instruction',['publication'],{'LIFE-012':{'decision':'not_applicable','reason':'No'}})
        rows=m.select('instruction',['publication'],{'LIFE-012':{'decision':'not_applicable','reason':'The selected work produces a local draft only; external publication is outside this release.'}})['rules']
        self.assertTrue(next(r for r in rows if r['rule_id']=='LIFE-012')['override'])
    def test_specification_basis_preserved(self):
        self.assertEqual(5,sum(r['basis']=='specification' for r in m.select('instruction')['rules']))
if __name__=='__main__':unittest.main()
