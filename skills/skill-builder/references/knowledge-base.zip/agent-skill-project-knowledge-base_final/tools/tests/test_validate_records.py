import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('validate_records',ROOT/'tools/validate_records.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class RecordContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.known=m.validators()
    def read(self,name): return m.read_json(ROOT/'examples/records'/name)
    def errors(self,r): return m.validate_record(r,self.known)
    def test_all_distributed_records(self):
        paths=m.read_json(ROOT/'schemas/record-index.json')['records']
        self.assertGreaterEqual(len(paths),10)
        for p in paths:
            with self.subTest(path=p): self.assertEqual([],self.errors(m.read_json(ROOT/p)))
    def test_pass_requires_package_identity(self):
        r=self.read('evaluation-receipt.json'); r['artifact']['package_sha256']=None
        r['artifact']['missing_identity_reason']='Not built'
        self.assertTrue(self.errors(r))
    def test_pass_requires_evidence(self):
        r=self.read('host-capabilities.json'); r['claims']['format']['evidence']=[]
        self.assertTrue(self.errors(r))
    def test_mixed_axes_are_valid(self):
        r=self.read('host-capabilities.json')
        self.assertEqual(r['claims']['format']['outcome'],'passed')
        self.assertEqual(r['claims']['discovery']['outcome'],'not_run')
        self.assertEqual(r['claims']['safety']['outcome'],'blocked')
        self.assertEqual([],self.errors(r))
    def test_unknown_outcome_rejected(self):
        r=self.read('host-capabilities.json'); r['claims']['safety']['outcome']='looks_good'
        self.assertTrue(self.errors(r))
    def test_unknown_usage_not_zero(self):
        r=self.read('evaluation-receipt.json'); self.assertIsNone(r['usage']['input_tokens']['value'])
        r['usage']['input_tokens']['missing_reason']=None
        self.assertTrue(self.errors(r))
    def test_ranges_numeric_and_ordered(self):
        for interval in ({'start':1,'end':0},{'start':3,'end':2},'search for settings',{'start':1,'end':100000}):
            r=self.read('source-review.json'); r['sources'][0]['ranges']=[interval]
            with self.subTest(interval=interval): self.assertTrue(self.errors(r))
    def test_selectors_are_separate(self):
        r=self.read('source-review.json'); r['sources'][0]['selectors']=['public checker function']
        self.assertEqual([],self.errors(r))
    def test_attempt_identity_required(self):
        r=self.read('evaluation-receipt.json'); r['attempts'][0]['artifact']['package_sha256']=None
        self.assertTrue(self.errors(r))
    def test_schema_does_not_fetch_external_refs(self):
        with self.assertRaises(Exception): m.deny_remote('https://example.invalid/schema.json')
    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(ValueError): json.loads('{"outcome":"failed","outcome":"passed"}',object_pairs_hook=m.reject_duplicates)
    def test_traceability_complete(self):
        r=self.read('rule-traceability.json'); r['records'].pop()
        self.assertTrue(self.errors(r))
    def test_publishing_exclusion_requires_reason(self):
        r=self.read('rule-traceability.json'); r['modifiers'].append('publication')
        row=next(x for x in r['records'] if x['rule_id']=='LIFE-012')
        row.update(decision='not_applicable',override=False,reason='Not applicable')
        self.assertTrue(self.errors(r))
    def test_pass_cannot_hide_failed_check(self):
        r=self.read('evaluation-receipt.json'); r['checks'][0]['outcome']='failed'
        self.assertTrue(self.errors(r))

if __name__=='__main__': unittest.main()
