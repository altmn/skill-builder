# Portable skill format validator

`validate_skill.py` is an original, read-only utility supplied with this knowledge base. It checks explicitly selected skill directories against **`portable-conservative-v1`** and emits JSON. It does not discover or install skills, execute helper scripts, fetch URLs, or modify skill payloads.

**A passing result means the implemented format and recognized direct-resource checks passed. It does not establish task quality, host compatibility, permission enforcement, or security compliance.** The JSON includes the checks performed and an explicit `not_checked` list.

## Requirements and reproducibility

- Python 3.10 or newer. The supplied tests were run with Python 3.12.14.
- PyYAML 6.0.3, pinned in [requirements.txt](requirements.txt). This was already installed in the research environment; no dependency installation was performed there.
- The portable validator has no other nonstandard dependency; its tests use `unittest` and temporary directories. The same requirements file also pins `jsonschema` 4.26.0 and `referencing` 0.37.0 for the separate evidence-record checker.
- The optional Markdown differential check uses Pandoc 3.1.11.1 as an independent parser; Pandoc is not needed to run the validator or its main regression suite.

Check your environment first:

```sh
python3 --version
python3 -c 'import yaml; print(yaml.__version__)'
```

If you need a separate environment, installation is an explicit step that can contact your configured package index:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r tools/requirements.txt
```

On Windows, use `.venv\Scripts\python.exe` instead. Installing dependencies is not part of the validator. For offline use, provision the pinned dependency from your own reviewed local package source. No packages are vendored in this download.

## Run it

From the knowledge-base directory, supply one or more **actual skill directories**, each containing its own `SKILL.md`:

```sh
python3 -B tools/validate_skill.py /path/to/example-skill
python3 -B tools/validate_skill.py /path/to/first-skill /path/to/second-skill > validation-report.json
```

Use your virtual-environment Python in these commands if applicable. `--compact` emits JSON without indentation. `--help` prints ordinary command help. The utility does not recursively scan a repository and does not treat `.template` files as installed skills. All validation fixtures in the tests are temporary and removed afterward.

| Exit | Meaning |
|---|---|
| `0` | Every selected directory passed all applicable implemented checks. Inspect warnings and `not_checked` before drawing conclusions. |
| `1` | At least one selected skill failed a validation check, including missing/inaccessible directories or resources. Other selected skills are still reported. |
| `2` | CLI misuse, missing dependency, or unexpected validator failure. No completed assurance is implied. |

Do not use a pipeline that discards the validator's exit code as a release gate. Reports are JSON on stdout, including ordinary invocation/dependency errors. The validator does not print document bodies, YAML parser excerpts, resource contents, or external query strings. Local paths and unknown frontmatter field names may appear in diagnostics.

## Implemented portable checks

The profile follows the published [Agent Skills format](https://agentskills.io/specification) as inspected for this knowledge base on 2026-11-22 (Los Angeles date). These are project checks against that documented format, not a claim of endorsement by the specification's maintainers.

| Area | Check |
|---|---|
| File | `SKILL.md` exists as a regular file within the selected resolved root; UTF-8 text, optional UTF-8 BOM, no NUL. |
| Frontmatter | Exact opening/closing `---` lines; mapping parsed with PyYAML's safe constructors. Duplicate keys are rejected at every mapping level. |
| Required metadata | `name` and `description` are strings and nonempty; whitespace-only descriptions fail. |
| Name | 1–64 characters; conservative ASCII pattern `^[a-z0-9]+(?:-[a-z0-9]+)*$`; matches the explicitly supplied directory's final component. |
| Description | At most 1,024 characters, including whitespace in the scalar. Character counts use Python Unicode code points, not UTF-8 bytes. |
| Optional standard fields | `license`, `compatibility`, and experimental `allowed-tools` must be strings; `compatibility` must contain 1–500 characters when provided. `metadata` must map strings to strings. |
| Unknown metadata | Host extensions such as `hooks`, `model`, and `user-invocable` fail this portable profile; validate generated host artifacts with a separate host-specific checker. |
| Body | At least one non-whitespace character after the frontmatter. This does not assess instruction usefulness. |
| Direct resource links | Recognized inline Markdown links and images must resolve to regular files within the selected root. Relative file/directory symlink escapes, parent traversal escapes, absolute paths, file URIs, and nonportable path forms fail. |

An empty `compatibility` string fails because the specification requires 1–500 characters when that field is provided. A whitespace-only value of 1–500 characters passes its length check but produces a project warning; omitting an uninformative optional field is clearer. Empty `license` and `allowed-tools` strings also produce warnings. `license` is not checked against the SPDX registry. `allowed-tools` is accepted because it is an experimental standard field, but no tool names, host syntax, or permission semantics are verified. YAML may infer numbers, dates, Booleans, and nulls; quote intended string values in `metadata`.

### Additional conservative profile choices

These are this utility's limits, not claimed specification mandates:

- Maximum `SKILL.md` size: 1 MiB; maximum frontmatter: 64 KiB; maximum YAML nesting depth: 32; maximum recognized direct links: 2,048. Exceeding a limit fails; skipped tail content is not treated as checked.
- YAML aliases and merge keys are rejected for predictable interpretation and bounded processing. Safe scalar/sequence/mapping constructors remain available, subject to the field types above. Unsafe/custom tags are not enabled.
- The explicitly supplied root may itself be a symlink. Its resolved directory becomes the boundary; name matching uses the supplied directory component. A `SKILL.md` or resource symlink may resolve inside that boundary, but may not escape it.
- Resource links use forward slashes. Drive-letter paths and backslashes fail. Percent escapes are decoded once as UTF-8; malformed, control-character, and nested percent encodings fail rather than being guessed.
- A resource destination must be a file. Directory links fail. The utility checks current path resolution, not resource readability/contents or adversarial path replacement during/later than validation.

## Markdown scope and limitations

The link recognizer deliberately has a smaller scope than a complete CommonMark parser. It supports direct `[label](relative/path.md)` and `![label](assets/file.png)` links; optional titles; angle-bracket paths with spaces; percent-encoded paths; escaped punctuation; and balanced parentheses in destinations. Nested title parentheses and excessive destination nesting are rejected. A recognized but incomplete/unsupported direct-link form fails conservatively.

The revised recognizer applies block boundaries before inline masking. Backticks cannot pair across paragraphs, headings, list items, or quote lines; code spans can span ordinary lines within one paragraph. Inline code protects literal comment openers. Real comments, supported fenced/indented code blocks, raw HTML blocks, inline tags, and autolinks are masked according to their syntax so delimiters in them cannot hide a later resource link. Direct-link destinations and titles are protected from this masking. Reference-style definitions and their supported title continuation are counted as `not_checked`; they are not followed.

This is still a conservative subset rather than a general renderer. Nested container fences/comments, ambiguous indented container continuation, and unsupported reference-definition continuation fail `links.supported_syntax` with **incomplete coverage**. Such a failure cannot be reported as a passed required link gate. A valid complex document can therefore require a separately reviewed full-parser check. Ordinary list/quote links, headings, one-paragraph code spans, and top-level code/comment examples remain usable.

Raw HTML links, autolinks, dynamic paths, shell/prose/code file mentions, included documents, and all resources' own outbound links are outside the resource-checking scope. Masking an HTML region does not validate that region or its links. A full CommonMark renderer can interpret further edge cases differently; the finite regression and differential panels are not a conformance certificate. The reference for precedence and inline syntax is [CommonMark 0.31.2](https://spec.commonmark.org/0.31.2/).

External schemes and protocol-relative URIs are reported as `not_checked`; no network request is made. Empty/fragment/query-only destinations have no resource path to check. For a local link with a query or fragment, the file is checked but the query and anchor are not. HTML entities and Markdown punctuation escapes are decoded before destination classification.

The utility is a point-in-time local check, not a filesystem sandbox or protection against concurrent file changes. It does not prove that later script execution stays inside the directory. The profile's acceptance of an instruction file is not approval of its instructions.

## Run the regression tests

From the knowledge-base directory:

```sh
python3 -B -m unittest discover -s tools/tests -p 'test_*.py' -v
```

The suite covers the gaps reproduced in the pinned public `skill-creator` helper—empty required values, directory/name mismatch, and `compatibility` support—plus duplicate/nested YAML keys, unsafe tags, alias/merge/depth limits, metadata types, Unicode length boundaries, unknown host extensions, malformed input, missing resources, percent encoding, parent traversal, symlink escapes, direct-link syntax, external-link nonfetching, payload preservation, and aggregate CLI exit codes. Symlink tests report skips on platforms that cannot create symlinks; a skipped test is not platform validation.

The [historical test receipt](test-results.json) retains **37 passing tests, zero skips** for the original validator snapshot. The [revision test receipt](revision-test-results.json) records **53 passing tests, zero skips** for validator 1.1.0, on Linux with Python 3.12.14 and PyYAML 6.0.3, with current source hashes and complete output. The original 37 tests remain in the suite. New cases cover the report's comment/paragraph/heading false passes, genuine code/comment controls, nested-container coverage failures, HTML and reference-definition delimiters, angle destinations, and the CLI's nonzero failure status.

An additional [differential receipt](markdown-differential-results.json) compares 57 named Markdown fixtures with Pandoc's CommonMark parser and records whether any live missing direct link escaped the required gate. Run this optional check separately:

```sh
python3 -B tools/check_markdown_differential.py
```

It is evidence for that bounded panel, not an assertion about all CommonMark inputs. Neither receipt executes the reference implementation's test suites or establishes Windows/macOS or live agent-host compatibility.

For the public-helper comparison, see [the research observations](../audits/skill-creator-validator-observations.json) when included in the complete knowledge-base package. Those observations concern a pinned helper snapshot, not every version of OpenAI tooling.

## Output contract

Reports have `schema_version: 1`, a validator/profile/version/dependency identity, overall status, a per-skill summary, and individual checks. Check and resource statuses are `passed`, `failed`, or `not_checked`; overall status is `passed`, `failed`, or `error`. Warnings do not change the exit status. An example shape is:

```json
{
  "schema_version": 1,
  "validator": {
    "name": "portable-agent-skill-format-validator",
    "version": "1.1.0",
    "profile": "portable-conservative-v1",
    "python": "3.12.14",
    "PyYAML": "6.0.3"
  },
  "status": "passed",
  "summary": {"skills": 1, "passed": 1, "failed": 0},
  "not_checked": ["Host permissions, execution safety, and other explicit limits are listed here."],
  "skills": [{"input": "/path/to/example-skill", "status": "passed", "checks": [], "resources": [], "warnings": []}]
}
```

The example abbreviates the actual check arrays; real output enumerates the checks performed. Preserve the profile and dependency versions with CI artifacts when comparing results across releases.
