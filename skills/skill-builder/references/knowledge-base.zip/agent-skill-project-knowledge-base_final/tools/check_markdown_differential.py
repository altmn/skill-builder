#!/usr/bin/env python3
"""Optional finite differential panel against Pandoc's CommonMark parser.

No source project, agent host, package installer, or network request is run.
Pandoc is optional and absent/failed comparator execution is an error, not pass.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import validate_skill

ROOT = Path(__file__).resolve().parent
CASES = ROOT / 'tests' / 'fixtures' / 'markdown-differential-cases.json'


def destinations(node):
    if isinstance(node, dict):
        if node.get('t') == 'Link':
            yield node['c'][-1][0]
        for child in node.values():
            yield from destinations(child)
    elif isinstance(node, list):
        for child in node:
            yield from destinations(child)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Optional JSON receipt path; default stdout only.')
    args = parser.parse_args(argv)
    executable = shutil.which('pandoc')
    if not executable:
        print(json.dumps({'status':'error','reason':'Pandoc is unavailable; differential panel was not run.'}))
        return 2
    try:
        version = subprocess.run([executable,'--version'],capture_output=True,text=True,check=True,timeout=10).stdout.splitlines()[0]
        results = []
        with tempfile.TemporaryDirectory(prefix='markdown-differential-') as directory:
            root = Path(directory)/'example-skill'
            root.mkdir()
            for case in json.loads(CASES.read_text(encoding='utf-8')):
                body = case['markdown']
                rendered = subprocess.run([executable,'-f','commonmark','-t','json'],input=body,
                                          capture_output=True,text=True,check=True,timeout=10)
                live = list(destinations(json.loads(rendered.stdout)))
                (root/'SKILL.md').write_text('---\nname: example-skill\ndescription: Task\n---\n'+body,encoding='utf-8')
                report = validate_skill.validate_skill(root)
                false_pass = 'missing.md' in live and report['status'] == 'passed'
                excluded_control_failed = case['require_pass'] and report['status'] != 'passed'
                results.append({'case':case['id'],'parser_links':live,'validator_status':report['status'],
                                'false_pass':false_pass,'exclusion_control_failed':excluded_control_failed})
        failures = sum(result['false_pass'] or result['exclusion_control_failed'] for result in results)
        receipt = {
            'schema_version':'1.0','status':'failed' if failures else 'passed',
            'scope':'finite_adversarial_and_control_markdown_panel_not_full_conformance',
            'comparator':{'program':version,'reader':'commonmark','output':'json'},
            'validator_version':validate_skill.VERSION,
            'case_count':len(results),'failure_count':failures,
            'false_pass_count':sum(result['false_pass'] for result in results),
            'exclusion_control_failure_count':sum(result['exclusion_control_failed'] for result in results),
            'inputs':{str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in (ROOT/'validate_skill.py',Path(__file__).resolve(),CASES)},
            'results':results,
        }
        text = json.dumps(receipt,indent=2)+'\n'
        if args.output:
            args.output.write_text(text,encoding='utf-8')
        print(text,end='')
        return 1 if failures else 0
    except (OSError,subprocess.SubprocessError,json.JSONDecodeError) as exc:
        print(json.dumps({'status':'error','reason':'Differential comparator could not complete.',
                          'error_type':type(exc).__name__}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
