#!/usr/bin/env python3
"""Join profile selections to the one canonical rule catalog; never duplicate rules.

Writes JSON to stdout; the caller chooses any output file. No host or project edits.
"""
import argparse
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def select(profile,modifiers=(),overrides=None,root=ROOT):
    catalog=json.loads((root/'catalogs/requirements.json').read_text())['rules']
    policy=json.loads((root/'catalogs/application-profiles.json').read_text())
    if profile not in policy['profiles']: raise ValueError('Unknown profile: '+profile)
    adopted=set(policy['profiles'][profile]['adopted_rule_ids'])
    for modifier in modifiers:
        if modifier not in policy['modifiers']: raise ValueError('Unknown modifier: '+modifier)
        adopted.update(policy['modifiers'][modifier]['adopted_rule_ids'])
    unassessed=set(policy['unselected_review_rule_ids'])
    overrides=overrides or {}
    if set(overrides)-{r['id'] for r in catalog}: raise ValueError('Override refers to an unknown rule.')
    rows=[]
    for rule in catalog:
        rid=rule['id']
        decision='adopted' if rid in adopted else ('not_assessed' if rid in unassessed else 'not_applicable')
        reason=('Selected by profile or capability modifier.' if decision=='adopted' else ('Review whether this additional mechanism exists before deciding.' if decision=='not_assessed' else 'The selected profile and declared modifiers do not include this capability.'))
        overridden=False
        if rid in overrides:
            override=overrides[rid]
            if set(override)!={'decision','reason'} or override['decision'] not in {'adopted','not_applicable','not_assessed'} or not isinstance(override['reason'],str) or len(override['reason'].strip())<20:
                raise ValueError(rid+': override requires a decision and a reviewable reason of at least 20 characters.')
            decision=override['decision'];reason=override['reason'];overridden=True
        rows.append({'rule_id':rid,'statement':rule['statement'],'strength':rule['strength'],'basis':rule['basis'],'decision':decision,'reason':reason,'override':overridden,'verification':rule['verification'],'source_ids':rule['source_ids'],'handbook':rule['handbook']})
    return {'schema_version':'1.0','profile':profile,'modifiers':sorted(set(modifiers)),'canonical_rules':'catalogs/requirements.json','note':'A selection is not a passing assessment. Treat unreviewed decisions as unresolved work.','rules':rows}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile',required=True,choices=['instruction','resource_assisted','suite_runtime']);p.add_argument('--modifier',action='append',default=[])
    p.add_argument('--overrides',type=Path)
    a=p.parse_args(argv)
    try:
        overrides=json.loads(a.overrides.read_text()) if a.overrides else None
        print(json.dumps(select(a.profile,a.modifier,overrides),indent=2));return 0
    except (ValueError,OSError,TypeError) as exc:
        print(json.dumps({'outcome':'blocked','reason':str(exc)}));return 2
if __name__=='__main__':raise SystemExit(main())
