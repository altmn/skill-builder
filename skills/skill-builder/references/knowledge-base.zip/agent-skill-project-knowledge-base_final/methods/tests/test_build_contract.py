import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "methods"))
import build_bundle
import source_reference


class SourceReferenceContracts(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="kb-source-test-", dir=ROOT.parent)
        self.root = Path(self.temp.name)
        (self.root / "skill-project-knowledge-base.md").write_text(
            "<!-- BEGIN MAINTAINED INTRO -->\n# Test\n[Engine](https://github.com/example/engine) served as inspiration.\n<!-- END MAINTAINED INTRO -->\n"
        )
    def tearDown(self):
        self.temp.cleanup()
    def test_source_path_and_line_recovery(self):
        target = "reference:blob/" + "a" * 40 + "/bin/reference-project-team-init#L43-L59"
        self.assertEqual(source_reference.resolve(target, self.root),
                         "https://github.com/example/engine/blob/" + "a" * 40 + "/bin/engine-team-init#L43-L59")
    def test_encoded_traversal_is_rejected(self):
        for path in ("../private", "%2e%2e/private", "folder/%2E%2E/private"):
            with self.assertRaises(ValueError):
                source_reference.resolve("reference:blob/" + "a" * 40 + "/" + path, self.root)
    def test_spaces_and_shell_metacharacters_are_data(self):
        result = source_reference.resolve("reference:blob/" + "a" * 40 + "/a file/$(echo value).md", self.root)
        self.assertIn("a%20file/$(echo%20value).md", result)
    def test_project_link_is_unique(self):
        path = self.root / "skill-project-knowledge-base.md"
        path.write_text(path.read_text().replace("# Test", "# Test\n[Other](https://github.com/example/other)"))
        with self.assertRaises(ValueError):
            source_reference.project_url(self.root)


class BuildContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.expected = build_bundle.generate(ROOT)
    def test_repeated_clean_builds_are_identical(self):
        self.assertEqual(self.expected, build_bundle.generate(ROOT))
    def test_environment_and_cache_files_are_excluded(self):
        with tempfile.TemporaryDirectory(prefix="kb-exclusions-test-", dir=ROOT.parent) as directory:
            root = Path(directory)
            for name in ("README.md", ".venv/lib/module.py", "node_modules/pkg/a.js", "__pycache__/x.pyc", ".build/tmp.json"):
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("test\n")
            self.assertEqual([p.relative_to(root).as_posix() for p in build_bundle.file_list(root)], ["README.md"])
    def test_archive_identity_ignores_incidental_checkout_modes(self):
        with tempfile.TemporaryDirectory(prefix="kb-archive-test-", dir=ROOT.parent) as directory:
            root = Path(directory) / "knowledge-base"
            root.mkdir()
            source = root / "tool.py"
            source.write_text("print('fixture')\n")
            first, second = Path(directory) / "first.zip", Path(directory) / "second.zip"
            source.chmod(0o644)
            build_bundle.package_archive(root, first)
            source.chmod(0o755)
            build_bundle.package_archive(root, second)
            self.assertEqual(first.read_bytes(), second.read_bytes())
    def test_controlled_source_edit_changes_expected_views(self):
        with tempfile.TemporaryDirectory(prefix="kb-edit-test-", dir=ROOT.parent) as directory:
            root = Path(directory) / "knowledge-base"
            shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".venv", "node_modules"))
            chapter = root / "handbook/01-design-principles.md"
            chapter.write_text(chapter.read_text() + "\nBuild propagation control marker.\n")
            changed = build_bundle.generate(root)
            changed_paths = {name for name in changed if changed[name] != self.expected[name]}
            self.assertEqual(changed_paths, {"skill-project-knowledge-base.md", "skill-project-knowledge-base.html", "validation/build-inputs.json", "MANIFEST.json", "SHA256SUMS"})
            self.assertIn(b"Build propagation control marker.", changed["skill-project-knowledge-base.md"])
            self.assertIn(b"Build propagation control marker.", changed["skill-project-knowledge-base.html"])
    def test_stale_reader_fails_check_mode(self):
        with tempfile.TemporaryDirectory(prefix="kb-stale-test-", dir=ROOT.parent) as directory:
            root = Path(directory) / "knowledge-base"
            shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".venv", "node_modules"))
            (root / "skill-project-knowledge-base.html").write_text("stale reader\n")
            process = subprocess.run([sys.executable, "-B", str(ROOT / "methods/build_bundle.py"), "--root", str(root), "--check"], capture_output=True, text=True, timeout=90)
            self.assertEqual(process.returncode, 1, process.stdout + process.stderr)
            self.assertIn("skill-project-knowledge-base.html", json.loads(process.stdout)["stale_outputs"])


if __name__ == "__main__":
    unittest.main()
