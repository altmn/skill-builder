import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

METHODS=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('merge_review',METHODS/'merge_review.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def mechanical(path='src/check.py',content=b'one\ntwo\n',mode='100644'):
    return {'path':path,'role':'runtime source','git_mode':mode,'git_blob':hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest(),'bytes':len(content),'lines':len(content.splitlines()),'sha256':hashlib.sha256(content).hexdigest(),'binary':False,'source_url':'https://example.invalid/repository/blob/'+'a'*40+'/'+path,'coverage':'structurally_indexed','heading_count':0,'headings':[]}

def annotated(row=None):
    row=copy.deepcopy(row or mechanical())
    row.update(coverage='full_semantic',review_evidence=[{'track':'manual','depth':'full_semantic','ranges':[[1,row['lines']]],'observations':['Read complete file; review is static only.'],'report':'audits/example.md','executed':False}],observations=['Retained reviewer observation.'],reviewer='Reviewer A',executed=False)
    return row

class MergeContracts(unittest.TestCase):
    def test_unchanged_keeps_manual_but_fresh_mechanics(self):
        old=annotated();current=mechanical();current['role']='new mechanical role';current['source_url']='https://example.invalid/new-revision'
        result,report=m.merge_rows([current],[old])
        self.assertEqual('full_semantic',result[0]['coverage']);self.assertEqual(old['review_evidence'],result[0]['review_evidence'])
        self.assertEqual('Reviewer A',result[0]['reviewer']);self.assertEqual(current['source_url'],result[0]['source_url']);self.assertEqual('new mechanical role',result[0]['role'])
        self.assertEqual(1,report['summary']['preserved']);self.assertFalse(result[0]['executed'])
    def test_changed_bytes_require_review_and_keep_history(self):
        old=annotated();current=mechanical(content=b'different\n')
        result,_=m.merge_rows([current],[old]);row=result[0]
        self.assertEqual('structural_index',row['coverage']);self.assertEqual([],row['review_evidence']);self.assertTrue(row['merge']['needs_review'])
        self.assertEqual(old,row['review_history'][0]['annotation']);self.assertFalse(row['review_history'][0]['accepted_as_current_review'])
    def test_mode_change_does_not_inherit_semantics(self):
        result,_=m.merge_rows([mechanical(mode='100755')],[annotated()])
        self.assertEqual('changed_needs_review',result[0]['merge']['disposition'])
    def test_new_unannotated_file_is_structural(self):
        result,_=m.merge_rows([mechanical()],[])
        self.assertEqual('structural_index',result[0]['coverage']);self.assertEqual([],result[0]['review_evidence']);self.assertTrue(result[0]['merge']['needs_review'])
    def test_structural_history_does_not_become_reviewed(self):
        result,_=m.merge_rows([mechanical()],[])
        again,_=m.merge_rows([mechanical()],result)
        self.assertEqual('structural_index',again[0]['coverage']);self.assertTrue(again[0]['merge']['needs_review'])
    def test_missing_file_only_in_disposition_history(self):
        old=annotated();result,report=m.merge_rows([], [old])
        self.assertEqual([],result);self.assertEqual(old,report['absent_annotations'][0]['prior_annotation'])
    def test_current_mismatch_is_rejected(self):
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical(content=b'changed\n')],[annotated()],'current')
        old=annotated();old['annotation_state']='current'
        with self.assertRaises(m.MergeError):m.merge_rows([], [old])
    def test_duplicate_paths_rejected_in_either_input(self):
        for current,old in [([mechanical(),mechanical()],[]),([mechanical()],[annotated(),annotated()])]:
            with self.assertRaises(m.MergeError):m.merge_rows(current,old)
    def test_unknown_labels_rejected(self):
        old=annotated();old['coverage']='assumed_passed'
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical()],[old])
        old=annotated();old['review_evidence'][0]['depth']='sounds_reviewed'
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical()],[old])
    def test_mechanical_semantic_claim_is_rejected(self):
        with self.assertRaises(m.MergeError):m.merge_rows([annotated()],[])
    def test_equal_sha_with_inconsistent_blob_rejected(self):
        old=annotated();old['git_blob']='b'*40
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical()],[old])
    def duplicate(self):
        source=annotated(mechanical('src/source.md'));duplicate=mechanical('src/copy.md')
        duplicate.update(coverage='same_content_reviewed',same_content_as='src/source.md',review_evidence=[],observations=['Exact content duplicate.'],executed=False)
        return source,duplicate
    def test_verified_same_content_is_preserved(self):
        source,duplicate=self.duplicate();result,_=m.merge_rows([mechanical('src/source.md'),mechanical('src/copy.md')],[source,duplicate])
        self.assertEqual('same_content_reviewed',next(x for x in result if x['path']=='src/copy.md')['coverage'])
    def test_false_same_content_rejected(self):
        source,duplicate=self.duplicate();duplicate['sha256']='0'*64
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical('src/source.md'),mechanical('src/copy.md')],[source,duplicate])
        source,duplicate=self.duplicate();source['coverage']='targeted_semantic';source['review_evidence'][0]['depth']='targeted_semantic'
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical('src/source.md'),mechanical('src/copy.md')],[source,duplicate])
    def test_changed_duplicate_source_cannot_receive_current_credit(self):
        source,duplicate=self.duplicate();result,report=m.merge_rows([mechanical('src/source.md',b'changed\n'),mechanical('src/copy.md')],[source,duplicate])
        copied=next(x for x in result if x['path']=='src/copy.md')
        self.assertEqual('structural_index',copied['coverage']);self.assertEqual(duplicate,copied['review_history'][0]['annotation'])
        self.assertEqual(1,report['summary']['same_content_dependency_needs_review'])
    def test_exact_paths_no_implicit_namespace_rewrite(self):
        result,report=m.merge_rows([mechanical('bin/source-tool')],[annotated(mechanical('bin/display-tool'))])
        self.assertEqual('unannotated_needs_review',result[0]['merge']['disposition']);self.assertEqual(1,report['summary']['absent_from_inventory'])
    def test_execution_claims_are_separate_history(self):
        old=annotated();old['executed']=True;old['review_evidence'][0]['executed']=True;old['execution_receipts']=['older-run.json']
        result,_=m.merge_rows([mechanical()],[old]);row=result[0]
        self.assertFalse(row['executed']);self.assertFalse(row['review_evidence'][0]['executed']);self.assertNotIn('execution_receipts',row)
        self.assertEqual(3,len(row['prior_execution_evidence']));self.assertTrue(all(not x['accepted_as_current_execution'] for x in row['prior_execution_evidence']))
    def test_numeric_ranges_separate_from_selectors(self):
        old=annotated();old['review_evidence'][0]['ranges']=['all settings branches']
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical()],[old])
        old=annotated();old['coverage']='targeted_semantic';old['review_evidence'][0].update(depth='targeted_semantic',ranges=[],search_descriptions=['settings branch'])
        self.assertEqual('targeted_semantic',m.merge_rows([mechanical()],[old])[0][0]['coverage'])
    def test_full_review_cannot_have_uncovered_lines(self):
        old=annotated();old['review_evidence'][0]['ranges']=[[1,1]]
        with self.assertRaises(m.MergeError):m.merge_rows([mechanical()],[old])
    def test_cli_is_deterministic_and_never_overwrites_inputs(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);current=root/'inventory.json';old=root/'annotations.json'
            current.write_text(json.dumps([mechanical()]));old.write_text(json.dumps([annotated()]))
            before=(current.read_bytes(),old.read_bytes())
            def run(output,report):return subprocess.run([sys.executable,str(METHODS/'merge_review.py'),'--inventory',str(current),'--annotations',str(old),'--output',str(output),'--report',str(report)],capture_output=True,text=True,timeout=10)
            a=root/'a.json';ar=root/'a-report.json';b=root/'b.json';br=root/'b-report.json'
            self.assertEqual(0,run(a,ar).returncode);self.assertEqual(0,run(b,br).returncode)
            self.assertEqual(a.read_bytes(),b.read_bytes());self.assertEqual(ar.read_bytes(),br.read_bytes())
            saved=a.read_bytes();self.assertEqual(2,run(a,root/'unused-report.json').returncode);self.assertEqual(saved,a.read_bytes());self.assertFalse((root/'unused-report.json').exists())
            self.assertEqual(2,run(current,root/'other-report.json').returncode)
            self.assertEqual(before,(current.read_bytes(),old.read_bytes()))
    def test_duplicate_json_key_rejected(self):
        with self.assertRaises(m.MergeError):json.loads('{"coverage":"full_semantic","coverage":"structural_index"}',object_pairs_hook=m.unique_object)

if __name__=='__main__':unittest.main()
