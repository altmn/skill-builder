"""Hermetic provenance regressions using disposable local Git object stores."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'inventory_repository.py'
spec = importlib.util.spec_from_file_location('repository_inventory', SCRIPT)
assert spec is not None and spec.loader is not None
indexer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(indexer)


class ImmutableInventory(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='immutable-inventory-')
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.repo = self.base / 'repo'
        self.repo.mkdir()
        self.out = self.base / 'output'
        self.url = 'https://github.com/example/reference-project'
        self.env = dict(os.environ, GIT_AUTHOR_NAME='Fixture', GIT_AUTHOR_EMAIL='fixture@example.invalid',
                        GIT_COMMITTER_NAME='Fixture', GIT_COMMITTER_EMAIL='fixture@example.invalid',
                        GIT_AUTHOR_DATE='2026-11-22T12:00:00Z', GIT_COMMITTER_DATE='2026-11-22T12:00:00Z',
                        GIT_CONFIG_NOSYSTEM='1')
        self.git('init', '-q')
        self.git('config', 'commit.gpgsign', 'false')
        self.content = b'# Committed content\n\nRead the known input.\n'
        (self.repo / 'README.md').write_bytes(self.content)
        skill = self.repo / 'skills' / 'sample'
        skill.mkdir(parents=True)
        (skill/'SKILL.md').write_text('---\nname: sample\ndescription: Inspect input\n---\n# Task\n\nRead supplied inputs.\n')
        self.commit = self.commit_all('Initial fixture')

    def git(self, *args, input=None, expected=0):
        result = subprocess.run(['git', '-C', str(self.repo), *args], input=input,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=self.env, timeout=20)
        self.assertEqual(result.returncode, expected, result.stderr.decode(errors='replace'))
        return result.stdout

    def commit_all(self, message):
        self.git('add', '-A')
        self.git('commit', '-qm', message)
        return self.git('rev-parse', 'HEAD').decode().strip()

    def build(self, revision=None, **kwargs):
        stats = indexer.build_inventory(self.repo, revision or self.commit, self.url, self.out, **kwargs)
        rows = json.loads((self.out/'file-inventory.json').read_text())
        return stats, {row['path']: row for row in rows}

    def assert_committed_readme(self, rows):
        row = rows['README.md']
        self.assertEqual(row['sha256'], hashlib.sha256(self.content).hexdigest())
        self.assertEqual(row['bytes'], len(self.content))
        self.assertEqual(row['git_blob'], self.git('rev-parse', self.commit+':README.md').decode().strip())
        self.assertEqual(row['source_url'], self.url+'/blob/'+self.commit+'/README.md')

    def test_dirty_worktree_bytes_are_never_attributed_to_commit(self):
        (self.repo/'README.md').write_bytes(b'Uncommitted contradictory content\n')
        stats, rows = self.build()
        self.assert_committed_readme(rows)
        self.assertFalse(stats['worktree_and_index_content_read'])
        self.assertEqual(stats['provenance'], 'immutable_git_tree_and_blob_objects')

    def test_staged_edit_and_deleted_worktree_use_requested_older_tree(self):
        (self.repo/'README.md').write_bytes(b'Staged contradictory content\n')
        self.git('add', 'README.md')
        _, staged_rows = self.build()
        self.assert_committed_readme(staged_rows)
        self.git('commit', '-qm', 'Newer revision')
        (self.repo/'README.md').unlink()
        stats, rows = self.build()
        self.assert_committed_readme(rows)
        self.assertEqual(stats['commit'], self.commit)
        self.assertEqual(stats['tree'], self.git('rev-parse', self.commit+'^{tree}').decode().strip())

    def test_unmerged_index_conflict_does_not_change_tree_bytes(self):
        self.git('checkout', '-qb', 'conflicting')
        (self.repo/'README.md').write_text('branch one\n')
        self.commit_all('One')
        self.git('checkout', '-qb', 'other', self.commit)
        (self.repo/'README.md').write_text('branch two\n')
        self.commit_all('Two')
        self.git('merge', 'conflicting', expected=1)
        self.assertTrue(self.git('ls-files', '-u'))
        _, rows = self.build()
        self.assert_committed_readme(rows)

    def test_symlink_content_comes_from_blob_without_following_target(self):
        target = b'../../outside-unreadable-target'
        oid = self.git('hash-object', '-w', '--stdin', input=target).decode().strip()
        self.git('update-index', '--add', '--cacheinfo', '120000,'+oid+',linked.md')
        self.git('commit', '-qm', 'Tracked symlink without filesystem materialization')
        revision = self.git('rev-parse', 'HEAD').decode().strip()
        _, rows = self.build(revision)
        row = rows['linked.md']
        self.assertFalse((self.repo/'linked.md').exists())
        self.assertEqual(row['sha256'], hashlib.sha256(target).hexdigest())
        self.assertEqual(row['bytes'], len(target))
        self.assertEqual(row['git_mode'], '120000')
        self.assertEqual(row['content_scope'], 'tracked_symlink_target')

    def test_submodule_is_rejected_or_explicit_identity_only(self):
        self.git('update-index', '--add', '--cacheinfo', '160000,'+self.commit+',vendor')
        self.git('commit', '-qm', 'Submodule identity')
        revision = self.git('rev-parse', 'HEAD').decode().strip()
        with self.assertRaisesRegex(indexer.InventoryError, 'submodule'):
            self.build(revision)
        self.assertFalse(self.out.exists())
        stats, rows = self.build(revision, submodules='record')
        self.assertEqual(stats['gitlink_files'], 1)
        self.assertEqual(rows['vendor']['gitlink_commit'], self.commit)
        self.assertIsNone(rows['vendor']['bytes'])
        self.assertIsNone(rows['vendor']['sha256'])
        self.assertEqual(rows['vendor']['coverage'], 'submodule_metadata')

    def test_lfs_is_pointer_only_even_when_worktree_contains_payload(self):
        pointer = b'version https://git-lfs.github.com/spec/v1\noid sha256:'+b'a'*64+b'\nsize 12345\n'
        (self.repo/'asset.bin').write_bytes(pointer)
        revision = self.commit_all('LFS pointer')
        (self.repo/'asset.bin').write_bytes(b'Expanded worktree payload which must not be read')
        stats, rows = self.build(revision)
        row = rows['asset.bin']
        self.assertEqual(row['sha256'], hashlib.sha256(pointer).hexdigest())
        self.assertEqual(row['large_file']['declared_object_bytes'], 12345)
        self.assertFalse(row['large_file']['object_fetched'])
        self.assertEqual(stats['lfs_pointers'], 1)

    def test_git_replace_blob_cannot_override_pinned_identity(self):
        old = self.git('rev-parse', self.commit+':README.md').decode().strip()
        new = self.git('hash-object', '-w', '--stdin', input=b'Replacement object\n').decode().strip()
        self.git('replace', old, new)
        _, rows = self.build()
        self.assert_committed_readme(rows)

    def test_partial_repository_is_rejected_before_lazy_fetch(self):
        self.git('config', 'remote.fixture.promisor', 'true')
        self.git('config', 'remote.fixture.url', 'https://invalid.example/never-fetch')
        with self.assertRaisesRegex(indexer.InventoryError, 'Partial/promisor'):
            self.build()
        self.assertFalse(self.out.exists())

    def test_oversized_blob_does_not_publish_partial_files(self):
        with self.assertRaisesRegex(indexer.InventoryError, 'max-blob-bytes'):
            self.build(max_blob_bytes=5)
        self.assertFalse(self.out.exists())

    def test_repeated_builds_are_identical_and_indices_keep_stable_ids(self):
        self.build()
        first = {p.name: p.read_bytes() for p in self.out.iterdir()}
        self.build()
        second = {p.name: p.read_bytes() for p in self.out.iterdir()}
        self.assertEqual(first, second)
        units = [json.loads(line) for line in (self.out/'instruction-index.jsonl').read_text().splitlines()]
        self.assertEqual(units[0]['id'], 'GSI-00001')
        self.assertEqual(units[0]['review_status'], 'mechanically_indexed')

    def test_source_urls_percent_encode_paths(self):
        (self.repo/'space #.md').write_text('fixture\n')
        revision = self.commit_all('Unusual path')
        _, rows = self.build(revision)
        self.assertTrue(rows['space #.md']['source_url'].endswith('/space%20%23.md'))

    def test_cli_requires_explicit_identity_and_reports_unavailable_revision(self):
        empty = subprocess.run([sys.executable, '-B', str(SCRIPT)], capture_output=True, timeout=10)
        self.assertEqual(empty.returncode, 2)
        result = subprocess.run([sys.executable, '-B', str(SCRIPT), '--repo', str(self.repo),
                                 '--revision', 'no-such-revision', '--repository-url', self.url,
                                 '--output', str(self.out)], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertEqual(json.loads(result.stdout)['status'], 'error')
        self.assertFalse(self.out.exists())


if __name__ == '__main__':
    unittest.main()
