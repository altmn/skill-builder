#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
python3 -B methods/build_bundle.py --check
python3 -B methods/check_bundle.py --run-tests
