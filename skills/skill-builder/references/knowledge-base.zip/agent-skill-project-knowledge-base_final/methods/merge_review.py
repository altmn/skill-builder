#!/usr/bin/env python3
"""Join immutable mechanical rows to explicit manual reviews by exact source identity.

No repository code, host, test or review is executed. Inputs are never overwritten.
Outputs must be new files. Identical inputs/options produce identical JSON bytes.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import sys

VERSION='1.0.0'
MAX_INPUT_BYTES=256*1024*1024
COVERAGE={'full_semantic','targeted_semantic','same_content_reviewed','structural_index','structurally_indexed','binary_metadata_only','binary_metadata','symlink_metadata','submodule_metadata'}
DEPTH=COVERAGE-{'same_content_reviewed'}
MECHANICAL={'path','role','git_mode','git_blob','git_object','git_object_type','gitlink_commit','bytes','lines','sha256','binary','source_url','heading_count','test_labels','symbols','topics','headings','content_scope','large_file'}
EXECUTION={'executed','execution_receipts','execution_results','test_receipts','test_results'}

class MergeError(ValueError): pass

def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise MergeError('Duplicate JSON key: '+key)
        result[key]=value
    return result

def read_rows(path):
    with Path(path).open('rb') as stream: data=stream.read(MAX_INPUT_BYTES+1)
    if len(data)>MAX_INPUT_BYTES: raise MergeError('Input exceeds the 256 MiB bound.')
    value=json.loads(data.decode('utf-8'),object_pairs_hook=unique_object,parse_constant=lambda x: (_ for _ in ()).throw(MergeError('Nonfinite JSON number: '+x)))
    if not isinstance(value,list): raise MergeError('Input must be a JSON array of file records.')
    return value,hashlib.sha256(data).hexdigest()

def check_path(path):
    if not isinstance(path,str) or not path or path.startswith('/') or '\x00' in path or any(part in {'','.', '..'} for part in path.split('/')):
        raise MergeError('Records require a nonempty repository-relative exact path.')
    return path

def identity(row):
    return {key:copy.deepcopy(row.get(key)) for key in ('path','sha256','git_mode','git_blob','git_object','gitlink_commit','bytes','lines','source_url') if key in row}

def same_identity(left,right):
    # A null hash is not content identity. Gitlinks can preserve metadata only.
    if left['path']!=right['path'] or left['git_mode']!=right['git_mode']: return False
    if left['git_mode']=='160000':
        return bool(left.get('gitlink_commit')) and left.get('gitlink_commit')==right.get('gitlink_commit')
    if not left.get('sha256') or left.get('sha256')!=right.get('sha256'): return False
    for key in ('git_blob','bytes','lines'):
        if key in left and key in right and left[key]!=right[key]:
            raise MergeError(left['path']+': equal content hash contradicts '+key+'; do not relabel inconsistent source identity.')
    return True

def collect(rows,kind):
    result={}
    for row in rows:
        if not isinstance(row,dict): raise MergeError(kind+': each record must be an object.')
        path=check_path(row.get('path'))
        if path in result: raise MergeError(kind+': duplicate path: '+path)
        mode=row.get('git_mode')
        if mode not in {'100644','100755','120000','160000'}: raise MergeError(path+': unsupported or missing Git mode.')
        if mode=='160000':
            if row.get('sha256') is not None or not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',str(row.get('gitlink_commit',''))):
                raise MergeError(path+': gitlink metadata needs a commit identity and no content-hash claim.')
        elif not isinstance(row.get('sha256'),str) or re.fullmatch(r'[0-9a-f]{64}',row['sha256']) is None:
            raise MergeError(path+': a SHA-256 of original tracked bytes is required.')
        if row.get('git_blob') is not None and re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',str(row['git_blob'])) is None:
            raise MergeError(path+': invalid Git blob identity.')
        for key in ('bytes','lines'):
            if key in row and row[key] is not None and (type(row[key]) is not int or row[key]<0):
                raise MergeError(path+': '+key+' must be a nonnegative integer or null.')
        coverage=row.get('coverage')
        if coverage not in COVERAGE: raise MergeError(path+': unknown coverage label: '+str(coverage))
        if kind=='inventory':
            unexpected=set(row)-MECHANICAL-{'coverage'}
            if unexpected: raise MergeError(path+': unsupported mechanical fields: '+', '.join(sorted(unexpected)))
            if coverage in {'full_semantic','targeted_semantic','same_content_reviewed'} or row.get('review_evidence') or row.get('executed'):
                raise MergeError(path+': mechanical input must not contain semantic or execution claims.')
        else:
            validate_annotation(row)
        result[path]=copy.deepcopy(row)
    return result

def intervals(evidence,lines,path):
    values=evidence.get('ranges',[])
    if not isinstance(values,list): raise MergeError(path+': review ranges must be an array.')
    out=[]
    for value in values:
        if isinstance(value,list) and len(value)==2: start,end=value
        elif isinstance(value,dict) and set(value)=={'start','end'}: start,end=value['start'],value['end']
        else: raise MergeError(path+': numeric ranges and search descriptions must be separate.')
        if type(start) is not int or type(end) is not int or start<1 or end<start or (lines is not None and end>lines):
            raise MergeError(path+': invalid or out-of-bounds source range.')
        out.append((start,end))
    for key in ('search_descriptions','selectors'):
        if key in evidence and (not isinstance(evidence[key],list) or any(not isinstance(x,str) or not x.strip() for x in evidence[key])):
            raise MergeError(path+': '+key+' must contain nonempty strings.')
    return out

def validate_annotation(row):
    path=row['path'];coverage=row['coverage'];lines=row.get('lines')
    if 'executed' in row and type(row['executed']) is not bool: raise MergeError(path+': executed must be a boolean, not an outcome label.')
    for history_key in ('review_history','prior_execution_evidence'):
        if history_key in row and not isinstance(row[history_key],list): raise MergeError(path+': '+history_key+' must be an array.')
    if row.get('annotation_state','prior') not in {'prior','current'}: raise MergeError(path+': unknown annotation_state.')
    evidence=row.get('review_evidence',[])
    if not isinstance(evidence,list): raise MergeError(path+': review_evidence must be an array.')
    for item in evidence:
        if not isinstance(item,dict) or item.get('depth') not in DEPTH: raise MergeError(path+': unknown review depth.')
        intervals(item,lines,path)
        if 'executed' in item and type(item['executed']) is not bool: raise MergeError(path+': review executed must be a boolean.')
    if row['git_mode']=='160000' and coverage!='submodule_metadata': raise MergeError(path+': a gitlink cannot inherit a content-review verdict.')
    if coverage in {'full_semantic','targeted_semantic'}:
        if row['git_mode'] not in {'100644','100755'} or row.get('binary') is True: raise MergeError(path+': semantic text coverage requires a regular text blob.')
        matching=[e for e in evidence if e.get('depth')==coverage]
        if not matching or not all(isinstance(e.get('report'),str) and e['report'].strip() for e in matching):
            raise MergeError(path+': semantic coverage requires explicit matching review evidence and report references.')
        spans=[span for e in matching for span in intervals(e,lines,path)]
        selectors=[x for e in matching for k in ('search_descriptions','selectors') for x in e.get(k,[])]
        if coverage=='targeted_semantic' and not spans and not selectors:
            raise MergeError(path+': a targeted review needs numeric ranges or separate selectors.')
        if coverage=='full_semantic':
            if type(lines) is not int: raise MergeError(path+': a full text review needs a known line count.')
            next_line=1
            for start,end in sorted(spans):
                if start>next_line: break
                next_line=max(next_line,end+1)
            if next_line<=lines: raise MergeError(path+': full-semantic evidence does not cover the complete file.')
    if coverage=='same_content_reviewed': check_path(row.get('same_content_as'))
    if 'same_content_as' in row and coverage!='same_content_reviewed':
        raise MergeError(path+': same_content_as requires an explicit same_content_reviewed label.')

def validate_same_content(annotations):
    for path,row in annotations.items():
        if row['coverage']!='same_content_reviewed': continue
        target=annotations.get(row['same_content_as'])
        if target is None or target.get('coverage')!='full_semantic':
            raise MergeError(path+': same-content coverage needs its fully reviewed source in the annotation input.')
        if path==target['path'] or row.get('sha256')!=target.get('sha256') or row['git_mode']!=target['git_mode'] or not row.get('sha256'):
            raise MergeError(path+': false same-content claim (hash/mode/source mismatch).')
        for key in ('git_blob','bytes','lines'):
            if key in row and key in target and row[key]!=target[key]:
                raise MergeError(path+': same-content claim contradicts '+key+'.')

def split_execution(value,pointer=''):
    """Separate historical execution claims without accepting them as a new run."""
    history=[]
    if isinstance(value,dict):
        cleaned={}
        for key,item in value.items():
            location=pointer+'/'+key
            if key in EXECUTION:
                if item not in (False,None,[],{}): history.append({'pointer':location,'field':key,'value':copy.deepcopy(item),'accepted_as_current_execution':False})
                if key=='executed': cleaned[key]=False
            else:
                cleaned[key],nested=split_execution(item,location);history.extend(nested)
        return cleaned,history
    if isinstance(value,list):
        cleaned=[]
        for n,item in enumerate(value):
            result,nested=split_execution(item,pointer+'/'+str(n));cleaned.append(result);history.extend(nested)
        return cleaned,history
    return copy.deepcopy(value),history

def structural(row):
    out=copy.deepcopy(row)
    out['coverage']='submodule_metadata' if row['git_mode']=='160000' else 'symlink_metadata' if row['git_mode']=='120000' else 'binary_metadata_only' if row.get('binary') is True else 'structural_index'
    out['review_evidence']=[];out['executed']=False
    out['observations']=['Mechanical inventory only. No current semantic review or executed check is inferred.']
    return out

def merge_rows(inventory_rows,annotation_rows,annotation_scope='prior'):
    if annotation_scope not in {'prior','current'}: raise MergeError('Unknown annotation scope.')
    inventory=collect(inventory_rows,'inventory');annotations=collect(annotation_rows,'annotations')
    validate_same_content(annotations)
    # A declared-current annotation must match before any output is constructed.
    for path,prior in annotations.items():
        if annotation_scope=='current' or prior.get('annotation_state')=='current':
            if path not in inventory or not same_identity(prior,inventory[path]):
                raise MergeError(path+': annotation declared current does not match the exact inventory source identity.')
    merged={};dispositions=[]
    for path,current in sorted(inventory.items()):
        prior=annotations.get(path);out=structural(current)
        if prior is None:
            disposition='unannotated_needs_review';changed=[]
        elif same_identity(prior,current):
            manual={k:copy.deepcopy(v) for k,v in prior.items() if k not in MECHANICAL and k not in {'merge','annotation_state','review_history','prior_execution_evidence'}}
            manual,execution_history=split_execution(manual)
            out.update(manual);out['executed']=False
            if 'review_history' in prior:out['review_history']=copy.deepcopy(prior['review_history'])
            old_execution=copy.deepcopy(prior.get('prior_execution_evidence',[]))
            if execution_history or old_execution:out['prior_execution_evidence']=old_execution+execution_history
            disposition='preserved';changed=[]
        else:
            disposition='changed_needs_review'
            changed=[key for key in ('sha256','git_mode','git_blob','gitlink_commit') if prior.get(key)!=current.get(key)]
            out['review_history']=[{'disposition':'source_identity_changed','identity':identity(prior),'annotation':copy.deepcopy(prior),'accepted_as_current_review':False}]
        out['merge']={'disposition':disposition,'needs_review':disposition!='preserved' or out['coverage'] in {'structural_index','structurally_indexed'},'annotation_scope':'current' if annotation_scope=='current' or (prior and prior.get('annotation_state')=='current') else 'prior','review_identity':identity(prior) if prior else None,'execution_status':'not_run_by_merger'}
        merged[path]=out
        dispositions.append({'path':path,'disposition':disposition,'changed_identity_fields':changed,'prior_identity':identity(prior) if prior else None,'current_identity':identity(current)})
    # A historical duplicate relation may have been valid while its source changed
    # or disappeared. Keep the historical observation but do not mispoint a current
    # semantic claim at that different current file.
    for path,out in list(merged.items()):
        if out['coverage']!='same_content_reviewed':continue
        source=merged.get(out.get('same_content_as'))
        if source is None or source['coverage']!='full_semantic' or source.get('sha256')!=out.get('sha256') or source['git_mode']!=out['git_mode']:
            prior=annotations[path];fresh=structural(inventory[path])
            fresh['review_history']=[{'disposition':'same_content_source_not_current','identity':identity(prior),'annotation':copy.deepcopy(prior),'accepted_as_current_review':False}]
            fresh['merge']={**out['merge'],'disposition':'same_content_dependency_needs_review','needs_review':True}
            merged[path]=fresh
            next(x for x in dispositions if x['path']==path)['disposition']='same_content_dependency_needs_review'
    missing=[{'path':path,'disposition':'absent_from_inventory','prior_identity':identity(row),'prior_annotation':copy.deepcopy(row),'accepted_as_current_review':False} for path,row in sorted(annotations.items()) if path not in inventory]
    counts={name:sum(x['disposition']==name for x in dispositions) for name in ('preserved','changed_needs_review','unannotated_needs_review','same_content_dependency_needs_review')}
    counts['absent_from_inventory']=len(missing)
    report={'schema_version':'1.0','merger_version':VERSION,'annotation_scope':annotation_scope,'executed':False,'semantics':'Matching original tracked-byte identity carries an explicit prior text review only; it does not revalidate cross-file assumptions, current host behavior or historical execution receipts.','summary':counts,'files':dispositions,'absent_annotations':missing,'limits':['Path matching is exact; normalize both inputs with the same explicit alias policy before merging. No implicit renaming or namespace substitution occurs.','Input hashes and Git modes are checked for consistency, not independently reconstructed from source bytes here; the immutable object indexer owns that verification.','Review evidence is a supplied reviewer judgment, not a semantic verdict generated by this utility.']}
    return [merged[path] for path in sorted(merged)],report

def write_new_files(outputs,inputs):
    resolved_inputs={Path(x).resolve() for x in inputs};targets=[Path(p) for p,_ in outputs]
    resolved=[p.resolve() for p in targets]
    if len(set(resolved))!=len(resolved):raise MergeError('Output and report must be different new files.')
    for path,resolved_path in zip(targets,resolved):
        if resolved_path in resolved_inputs or path.exists() or path.is_symlink():raise MergeError('Refusing to overwrite an input, existing output, or symlink: '+str(path))
        if not path.parent.is_dir():raise MergeError('Output parent must already exist: '+str(path.parent))
    created=[]
    try:
        for path,value in outputs:
            # Exclusive creation prevents a race from replacing an existing file.
            with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
                created.append((Path(path),os.fstat(stream.fileno()).st_ino))
                stream.write(json.dumps(value,indent=2,ensure_ascii=False)+'\n');stream.flush();os.fsync(stream.fileno())
    except Exception:
        for path,inode in created:
            try:
                if not path.is_symlink() and path.stat().st_ino==inode:path.unlink()
            except OSError:pass
        raise

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory',required=True,type=Path)
    parser.add_argument('--annotations',required=True,type=Path)
    parser.add_argument('--annotation-scope',choices=['prior','current'],default='prior',help='Prior mismatches become history; declared-current mismatches are errors.')
    parser.add_argument('--output',required=True,type=Path,help='New merged file-review JSON path; parent must exist.')
    parser.add_argument('--report',required=True,type=Path,help='New change/disposition JSON path; parent must exist.')
    args=parser.parse_args(argv)
    try:
        inventory,inventory_hash=read_rows(args.inventory);annotations,annotation_hash=read_rows(args.annotations)
        merged,report=merge_rows(inventory,annotations,args.annotation_scope)
        report['inputs']={'inventory_sha256':inventory_hash,'annotations_sha256':annotation_hash}
        write_new_files([(args.output,merged),(args.report,report)],[args.inventory,args.annotations])
    except (MergeError,OSError,UnicodeError,json.JSONDecodeError,RecursionError) as exc:
        print(json.dumps({'status':'error','type':type(exc).__name__,'message':str(exc)}));return 2
    print(json.dumps({'status':'passed','meaning':'merge completed; no semantic verdict or executed receipt was created','files':len(merged),'summary':report['summary']},indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
