#!/usr/bin/env python3
"""Deterministically rebuild the complete readers, catalog views and manifest.

Canonical review records are inputs. This builder never creates semantic verdicts.
No network, upstream checkout, host installation, or external source execution is used.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import html
import io
import json
import os
import posixpath
import re
import subprocess
import sys
import zipfile
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
INTRO_BEGIN = "<!-- BEGIN MAINTAINED INTRO -->"
INTRO_END = "<!-- END MAINTAINED INTRO -->"
GENERATED = {
    "skill-project-knowledge-base.md", "skill-project-knowledge-base.html",
    "catalogs/file-review.csv", "catalogs/instruction-review.csv",
    "catalogs/skill-catalog.md", "catalogs/coverage-summary.json",
    "catalogs/catalog-browser.html", "sources/primary-sources.md",
    "validation/build-inputs.json", "MANIFEST.json", "SHA256SUMS",
    "examples/manifest-inspector/dist/manifest-inspector.zip",
    "examples/manifest-inspector/dist/package-identity.json",
}


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def read_json(root: Path, path: str):
    return json.loads((root / path).read_text(encoding="utf-8"))


def file_list(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob("*") if p.is_file() and not any(
        x in {"__pycache__", ".git", ".DS_Store", ".pytest_cache", ".build", ".venv", "venv", "node_modules", "__MACOSX"}
        or x.startswith("._") for x in p.relative_to(root).parts
    ) and p.suffix != ".pyc")


def maintained_intro(root: Path) -> str:
    text = (root / "skill-project-knowledge-base.md").read_text(encoding="utf-8")
    if text.count(INTRO_BEGIN) != 1 or text.count(INTRO_END) != 1:
        raise ValueError("The consolidated Markdown must retain exactly one maintained introduction")
    return text[text.index(INTRO_BEGIN):text.index(INTRO_END) + len(INTRO_END)] + "\n"


def slug(value: str) -> str:
    value = re.sub(r"<[^>]+>", "", value).lower()
    value = re.sub(r"[`*_]", "", value)
    value = re.sub(r"[^\w\s-]", "", value, flags=re.UNICODE)
    return re.sub(r"[\s-]+", "-", value).strip("-")


def document_id(path: str) -> str:
    return "doc-" + re.sub(r"[^a-z0-9]+", "-", path.lower()).strip("-")


def pandoc(source: str, source_format: str, target_format: str) -> str:
    result = subprocess.run(
        ["pandoc", "--from=" + source_format, "--to=" + target_format, "--wrap=none"],
        input=source, text=True, capture_output=True, check=False,
        env={**os.environ, "LC_ALL": "C.UTF-8"},
    )
    if result.returncode:
        raise RuntimeError("Pandoc failed: " + result.stderr.strip())
    return result.stdout


def inline_text(nodes) -> str:
    parts = []
    for n in nodes:
        if not isinstance(n, dict):
            continue
        kind, content = n.get("t"), n.get("c")
        if kind in {"Str", "Code"}:
            parts.append(content if isinstance(content, str) else content[-1])
        elif kind in {"Space", "SoftBreak", "LineBreak"}:
            parts.append(" ")
        elif kind in {"Emph", "Strong", "Strikeout", "SmallCaps", "Superscript", "Subscript"}:
            parts.append(inline_text(content))
        elif kind in {"Link", "Image", "Span"}:
            parts.append(inline_text(content[1]))
    return "".join(parts)


def source_link(locator: str, prefix: str = "") -> str:
    return prefix + "sources/source-reference.html?ref=" + quote(locator, safe="")


def rebase_link(url: str, origin: str, docs: set[str], anchors: dict) -> str:
    if url.startswith("reference:"):
        return source_link(url)
    parsed = urlsplit(url)
    if parsed.scheme or url.startswith("//"):
        return url
    path = unquote(parsed.path)
    target = posixpath.normpath(posixpath.join(posixpath.dirname(origin), path)) if path else origin
    if target in docs:
        if parsed.fragment:
            anchor = anchors.get(target, {}).get(parsed.fragment)
            if anchor:
                return "#" + anchor
            # Explicit anchors already authored in a canonical document retain their name.
            return "#" + parsed.fragment
        return "#" + document_id(target)
    result = target if path else ""
    if parsed.query:
        result += "?" + parsed.query
    if parsed.fragment:
        result += "#" + parsed.fragment
    return result


def walk_links(value, origin, docs, anchors):
    if isinstance(value, list):
        for item in value:
            walk_links(item, origin, docs, anchors)
    elif isinstance(value, dict):
        if value.get("t") in {"Link", "Image"}:
            target = value["c"][-1]
            target[0] = rebase_link(target[0], origin, docs, anchors)
        for item in value.values():
            walk_links(item, origin, docs, anchors)


def reader_outputs(root: Path, config: dict, overrides: dict[str, bytes]) -> dict[str, bytes]:
    docs = config["documents"]
    trees, anchors, titles = {}, {}, {}
    for path in docs:
        source = overrides.get(path)
        text = source.decode() if source is not None else (root / path).read_text(encoding="utf-8")
        tree = json.loads(pandoc(text, "gfm", "json"))
        used = collections.Counter()
        table = {}
        blocks = []
        for block in tree["blocks"]:
            if block["t"] == "Header":
                level, attrs, words = block["c"]
                title = inline_text(words)
                titles.setdefault(path, title)
                stem = slug(title) or "section"
                count = used[stem]
                used[stem] += 1
                plain = stem + ("-" + str(count) if count else "")
                full = document_id(path) + "--" + plain
                table[attrs[0] or plain] = full
                table[plain] = full
                attrs[0] = ""
                blocks.append({"t": "RawBlock", "c": ["html", '<a id="' + full + '"></a>']})
            blocks.append(block)
        tree["blocks"] = blocks
        anchors[path], trees[path] = table, tree
    docset = set(docs)
    md = [maintained_intro(root), "\n## Contents\n\n"]
    nav, sections = [], []
    for path in docs:
        did = document_id(path)
        title = titles.get(path, path)
        tree = trees[path]
        walk_links(tree, path, docset, anchors)
        encoded = json.dumps(tree, ensure_ascii=False)
        md.append(f"- [{title}](#{did})\n")
        nav.append(f'<a href="#{did}">{html.escape(title)}</a>')
        sections.append(
            f'<section class="document" id="{did}" data-title="{html.escape(title.lower(), quote=True)}">'
            f'<p class="source-label">{html.escape(path)}</p>' + re.sub(r'((?:id|href)=")#?(cb\d+(?:-\d+)?)(")',
                lambda match: match[1] + ("#" if match[1].startswith("href") else "") + did + "--" + match[2] + match[3],
                pandoc(encoded, "json", "html5"))
            + '<p class="back"><a href="#top">Back to contents</a></p></section>'
        )
    for path in docs:
        md.extend(["\n---\n\n", f'<a id="{document_id(path)}"></a>\n\n',
                   pandoc(json.dumps(trees[path], ensure_ascii=False), "json", "gfm")])
    css = (root / "methods/reader-style.css").read_text()
    page = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>Agent Skill Project Knowledge Base</title><style>''' + css + '''</style></head><body id="top"><header><div class="eyebrow">Research + reusable engineering playbook</div><h1>Build skills with clear contracts and verifiable results.</h1><p>A practical knowledge base for creating, testing, maintaining and auditing portable agent skills.</p><div><span class="pill">Full handbook and detailed audits</span><span class="pill">5,375 source files indexed</span><span class="pill">99 review rules</span><span class="pill">Working example and local checks</span></div><p class="meta">Research baseline: November 22, 2026 · historical source ccd80de8ebdd</p></header><div class="layout"><aside aria-label="Contents"><h2>Contents</h2><label for="nav-filter">Find a chapter</label><input id="nav-filter" type="search" placeholder="Try portability, security, release…"><nav>''' + "".join(nav) + '''</nav></aside><main><section class="intro" id="bundle-help"><h2>How to read this package</h2><p>The complete handbook, detailed audit narratives, checklists and source register remain embedded in this reader. The archive includes the full searchable catalogs, tools, schemas, editable templates and completed reference example.</p><p><a href="examples/README.md">Start with the completed example</a> · <a href="catalogs/catalog-browser.html">Search the complete evidence catalogs</a> · <a href="methods/BUILD.md">Build and verify the package</a></p><p class="notice"><strong>Evidence boundary:</strong> historical source inspection, reproduced local tests, documented host behavior, and unexecuted recipes are separate evidence classes. See the current validation receipts for checks actually performed. The project inspiration link is retained in the <a href="skill-project-knowledge-base.md">consolidated Markdown introduction</a>; <a href="sources/PROVENANCE.md">source provenance</a> explains neutral identifiers.</p><button onclick="window.print()">Print / save this reader as PDF</button></section>''' + "\n".join(sections) + '''</main></div><footer>Source observations, reproduced checks and engineering recommendations are distinguished throughout. This reader has no background network dependencies.</footer><script>document.querySelector('#nav-filter').addEventListener('input',e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('nav a').forEach(a=>a.hidden=!a.textContent.toLowerCase().includes(q));});</script></body></html>\n'''
    return {"skill-project-knowledge-base.md": "".join(md).encode(), "skill-project-knowledge-base.html": page.encode()}


def csv_bytes(rows: list[dict], fields: list[str]) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        values = dict(row)
        for key, val in values.items():
            if isinstance(val, list):
                separator = " | " if key == "observations" else ";"
                values[key] = separator.join(str(v) for v in val)
            elif isinstance(val, dict):
                values[key] = json.dumps(val, ensure_ascii=False, sort_keys=True)
        writer.writerow(values)
    return output.getvalue().encode()


def catalog_outputs(root: Path) -> dict[str, bytes]:
    files = read_json(root, "catalogs/file-review.json")
    instructions = [json.loads(s) for s in (root / "catalogs/instruction-review.jsonl").read_text().splitlines() if s.strip()]
    skills = read_json(root, "catalogs/skill-catalog.json")
    rules = read_json(root, "catalogs/requirements.json")["rules"]
    findings = read_json(root, "catalogs/benchmark-findings.json")["findings"]
    snapshot = read_json(root, "sources/reference-snapshot.json")
    policy = read_json(root, "methods/coverage-policy.json")
    coverage = {"generated_output_caveat": policy["generated_output_caveat"], "execution": policy["execution"], "file_depth_counts": dict(collections.Counter(r["coverage"] for r in files)),
                "instruction_context_counts": dict(collections.Counter(r["context_coverage"] for r in instructions)),
                "files_without_semantic_read": [r["path"] for r in files if r["coverage"] not in {"full_semantic", "targeted_semantic", "same_content_reviewed"}],
                "unique_instruction_block_hashes": len({r["sha256"] for r in instructions}),
                "canonical_skill_template_coverage": dict(collections.Counter(r["coverage"] for r in skills if r["path"].endswith("SKILL.md.tmpl")))}
    coverage["snapshot"] = {k: snapshot[k] for k in policy["snapshot_fields"] if k in snapshot}
    result = {
        "catalogs/file-review.csv": csv_bytes(files, ["path", "role", "git_mode", "bytes", "lines", "sha256", "coverage", "canonical_source", "same_content_as", "source_url", "observations"]),
        "catalogs/instruction-review.csv": csv_bytes(instructions, ["id", "path", "line_start", "line_end", "heading", "unit_type", "canonical", "file_coverage", "context_coverage", "individual_verdict", "topics", "relevant_rule_groups", "source_url"]),
        "catalogs/coverage-summary.json": json_bytes(coverage),
    }
    skill_md = ["# Skill entry-point catalog\n\nAll paths use neutral display identifiers for the pinned reference snapshot. Template and generated entries are separate artifacts. Size estimates are bytes divided by four, not measured tokenizer counts. Source hashes identify original source bytes; see [provenance](../sources/PROVENANCE.md).\n\n| Path | Lines | Bytes | Coverage | Source |\n|---|---:|---:|---|---|\n"]
    for row in skills:
        link = source_link(row["source_url"], "../") if row["source_url"].startswith("reference:") else row["source_url"]
        skill_md.append(f'| `{row["path"]}` | {row["lines"]:,} | {row["bytes"]:,} | {row["coverage"]} | [pinned]({link}) |\n')
    result["catalogs/skill-catalog.md"] = "".join(skill_md).encode()
    def url(value):
        return source_link(value, "../") if value.startswith("reference:") else value
    def prose(value):
        return " ".join(str(item) for item in value) if isinstance(value, list) else str(value)
    data = {
        "files": [{"id": r["path"], "path": r["path"], "kind": r["role"], "coverage": r["coverage"], "lines": r["lines"], "bytes": r["bytes"], "url": url(r["source_url"]), "detail": "\n".join(r.get("observations", [])), "sha256": r["sha256"]} for r in files],
        "instructions": [{"id": r["id"], "path": r["path"], "kind": r["unit_type"], "coverage": r["context_coverage"], "lines": f'{r["line_start"]}–{r["line_end"]}', "canonical": r["canonical"], "url": url(r["source_url"]), "detail": r["excerpt"] + "\nTopics: " + ", ".join(r.get("topics", [])) + "\n" + "\n".join(r.get("adoption_questions", [])), "heading": r["heading"], "verdict": r["individual_verdict"]} for r in instructions],
        "rules": [{"id": r["id"], "path": r["category"], "kind": r["strength"], "coverage": r["basis"], "lines": "", "url": "../" + r["handbook"], "detail": r["statement"] + "\nVerification: " + r["verification"] + "\nApplicability: " + r["applicability"]} for r in rules],
        "findings": [{"id": r["id"], "path": r["title"], "kind": r["category"], "coverage": r["evidence_type"], "lines": r["severity"], "url": url(r["affected"][0]["url"]), "detail": r["observation"] + "\nImpact: " + r["impact"] + "\nRecommendation: " + r["recommendation"] + "\nValidation: " + prose(r.get("suggested_validation", r.get("validation", "See finding record."))) + "\nReproduced: " + str(r["reproduced"]).lower()} for r in findings],
    }
    template = (root / "methods/catalog-template.html").read_text()
    packed = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    result["catalogs/catalog-browser.html"] = template.replace("@@CATALOG_DATA@@", packed).encode()
    sources = read_json(root, "sources/primary-sources.json")
    primary = ["# Primary sources\n\nResearch baseline: November 22, 2026 (America/Los_Angeles). Changing documentation was checked online during the dated research; repository findings use exact commits. Facts, static inferences, executed results and recommendations are labeled separately in the reports. These retained records are documentation evidence, not live-host tests. Conversation retrieval references remain supplementary metadata. [Documentation evidence captures](host-documentation-register.json) and [provenance](PROVENANCE.md) record revision and capture limitations.\n\n## Reference snapshot\n\n- Project identity: the inspiration link in the [consolidated Markdown introduction](../skill-project-knowledge-base.md).\n- Pinned source: `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`.\n- Package version: `1.102.2`; runtime `VERSION`: `1.102.2.0`.\n- Commit timestamp: November 22, 2026, 5:08:54 p.m. Pacific (November 23, 01:08:54 UTC).\n- All-file hashes and pinned source locators: [file-review.json](../catalogs/file-review.json).\n- OpenAI public creator commit: `49f948faa9258a0c61caceaf225e179651397431`.\n"]
    for row in sources["sources"]:
        primary.append(f'\n## {row["id"]}\n\n[{row["title"]}]({row["url"]})\n\n{row["key_claims"]}\n\nEvidence: {row["verification"]}. Accessed {row["access_date"]}.\n')
    result["sources/primary-sources.md"] = "".join(primary).encode()
    return result


def example_outputs(root: Path) -> dict[str, bytes]:
    """Match the example's standalone build contract without writing during --check."""
    payload = root / "examples/manifest-inspector/skills/manifest-inspector"
    names = ["SKILL.md", "references/contract.md", "scripts/check_manifest.py"]
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(names):
            info = zipfile.ZipInfo("manifest-inspector/" + name, (2026, 11, 22, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (payload / name).read_bytes())
    data = output.getvalue()
    identity = {"schema_version": "1.0", "archive": "dist/manifest-inspector.zip", "sha256": hashlib.sha256(data).hexdigest(), "files": [{"path": "manifest-inspector/" + name, "bytes": (payload / name).stat().st_size, "sha256": hashlib.sha256((payload / name).read_bytes()).hexdigest()} for name in names], "effects": "Creates only dist/manifest-inspector.zip and dist/package-identity.json; does not install."}
    return {"examples/manifest-inspector/dist/manifest-inspector.zip": data,
            "examples/manifest-inspector/dist/package-identity.json": json_bytes(identity)}


def generate(root: Path) -> dict[str, bytes]:
    config = read_json(root, "methods/build-config.json")
    version = subprocess.run(["pandoc", "--version"], text=True, capture_output=True, check=True).stdout.splitlines()[0]
    if version != "pandoc " + config["dependencies"]["pandoc"]:
        raise ValueError(f"Expected pandoc {config['dependencies']['pandoc']}; observed {version}. Update the pin deliberately before rebuilding.")
    output = catalog_outputs(root)
    output.update(example_outputs(root))
    output.update(reader_outputs(root, config, output))
    inputs = []
    for p in file_list(root):
        rel = p.relative_to(root).as_posix()
        if rel in GENERATED:
            continue
        data = p.read_bytes()
        inputs.append({"path": rel, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    inputs.append({"path": "skill-project-knowledge-base.md#maintained-intro", "bytes": len(maintained_intro(root).encode()), "sha256": hashlib.sha256(maintained_intro(root).encode()).hexdigest()})
    output["validation/build-inputs.json"] = json_bytes({"schema_version": "1.0", "dependencies": config["dependencies"], "note": "Complete canonical input identities; no wall-clock timestamp is generated. Receipts are inputs, not rerun by the builder.", "inputs": inputs})
    package = {p.relative_to(root).as_posix(): p.read_bytes() for p in file_list(root) if p.relative_to(root).as_posix() not in {"MANIFEST.json", "SHA256SUMS"}}
    package.update(output)
    records = [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in sorted(package.items())]
    output["MANIFEST.json"] = json_bytes({"schema_version": "2.0", "project": "Agent Skill Project Knowledge Base", "research_date": config["research_date"], "timezone": config["timezone"], "reference_commit": config["baseline_commit"], "note": "Hashes cover all package files except MANIFEST.json and SHA256SUMS, avoiding circular self-reference. Canonical review judgments are preserved inputs; generated views are reproducible.", "files": records})
    output["SHA256SUMS"] = ("".join(r["sha256"] + "  " + r["path"] + "\n" for r in records)).encode()
    return output


def package_archive(root: Path, destination: Path) -> None:
    if destination.resolve().is_relative_to(root.resolve()):
        raise ValueError("Write the release archive outside the package tree")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in file_list(root):
            info = zipfile.ZipInfo(root.name + "/" + path.relative_to(root).as_posix(), (2026, 11, 22, 0, 0, 0))
            info.create_system = 3
            # Every documented entrypoint is invoked through Python or sh.
            # Fixed permissions keep unrelated checkout umasks/modes out of ZIP identity.
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--check", action="store_true", help="Fail on stale or missing generated output; do not edit files")
    parser.add_argument("--archive", type=Path, help="After a successful build/check, create a deterministic ZIP outside the source tree")
    args = parser.parse_args()
    try:
        output = generate(args.root.resolve())
        stale = [name for name, value in output.items() if not (args.root / name).is_file() or (args.root / name).read_bytes() != value]
        if args.check and stale:
            print(json.dumps({"status": "failed", "stale_outputs": stale}, indent=2))
            return 1
        if not args.check:
            for name, value in output.items():
                target = args.root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(value)
        if args.archive:
            package_archive(args.root, args.archive)
        print(json.dumps({"status": "passed", "mode": "check" if args.check else "build", "generated_outputs": len(output), "changed_outputs": stale, "archive": str(args.archive) if args.archive else None}, indent=2))
        return 0
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
