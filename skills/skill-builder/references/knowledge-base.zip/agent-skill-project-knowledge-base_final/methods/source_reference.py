#!/usr/bin/env python3
"""Resolve a neutral, immutable research locator using the maintained intro.

This tool prints a URL. It makes no network request and executes no source code.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]


def project_url(root: Path = ROOT) -> str:
    text = (root / "skill-project-knowledge-base.md").read_text(encoding="utf-8")
    intro = text.split("<!-- END MAINTAINED INTRO -->", 1)[0]
    matches = re.findall(r"\]\((https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)/?\)", intro)
    if len(matches) != 1:
        raise ValueError("The maintained introduction must contain exactly one project inspiration link")
    return matches[0].rstrip("/")


def original_namespace(value: str, repository: str) -> str:
    name = urlsplit(repository).path.rstrip("/").rsplit("/", 1)[-1]
    # Display identifiers are aliases. Hashes always identify original source bytes.
    for alias, replacement in [
        ("REFERENCE_PROJECT", name.upper()),
        ("reference_project", name),
        ("ReferenceProject", name.capitalize()),
        ("referenceProject", name),
        ("Reference-project", name.capitalize()),
        ("reference-project", name),
    ]:
        value = value.replace(alias, replacement)
    return value


def resolve(locator: str, root: Path = ROOT) -> str:
    base = project_url(root)
    value = unquote(locator.removeprefix("reference:")).lstrip("/")
    if value in ("", "repository"):
        return base
    if value.startswith("repository/"):
        suffix = value[len("repository/"):]
        if not re.fullmatch(r"-[A-Za-z0-9_.-]+", suffix):
            raise ValueError("Unsupported related-repository selector")
        return base + original_namespace(suffix, base)
    if not re.match(r"(?:blob|tree|commit|compare)/", value):
        raise ValueError("Expected a blob, tree, commit, compare or repository locator")
    if any(p in (".", "..") for p in value.split("#", 1)[0].split("/")):
        raise ValueError("Source locator contains a path traversal")
    if any(ord(c) < 32 for c in value):
        raise ValueError("Source locator contains a control character")
    return base + "/" + quote(original_namespace(value, base), safe="/!$&'()*+,;=:@-._~#")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("locator", help="reference:blob/REVISION/path#Lstart-Lend")
    args = parser.parse_args()
    try:
        print(resolve(args.locator))
    except (ValueError, OSError) as exc:
        parser.exit(2, f"source reference: {exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
