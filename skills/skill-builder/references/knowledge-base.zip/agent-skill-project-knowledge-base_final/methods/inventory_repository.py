#!/usr/bin/env python3
"""Index one immutable Git tree without executing repository code or reading worktree files.

This is a structural index, not a semantic review. Git object replacements are
ignored; requested revisions are resolved once, then paths, modes, object IDs,
and bytes all come from that exact commit tree.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import quote, urlsplit

VERSION = '2.0.0'
MAX_BLOB_BYTES = 64 * 1024 * 1024


class InventoryError(ValueError):
    """The declared inventory could not be completed without changing its scope."""


def git_environment():
    environment = dict(os.environ)
    # A local replace ref must not silently substitute another object under a
    # pinned permalink. Disable optional index locks and interactive prompts.
    environment.update(GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0',
                       GIT_TERMINAL_PROMPT='0', GIT_NO_LAZY_FETCH='1', LC_ALL='C')
    return environment


def git(repo, *args, allow_missing=False):
    result = subprocess.run(['git', '--no-pager', '--no-optional-locks', '-C', str(repo),
                             *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=git_environment(), timeout=120, check=False)
    if result.returncode == 1 and allow_missing:
        return b''
    if result.returncode:
        # Do not echo arbitrary remote URLs, credentials, hooks, or file bytes.
        raise InventoryError('Git object query failed: ' + args[0] +
                             ' (exit ' + str(result.returncode) + ').')
    return result.stdout


class GitObjects:
    def __init__(self, repo):
        self.process = subprocess.Popen(
            ['git', '--no-pager', '--no-optional-locks', '-C', str(repo), 'cat-file', '--batch'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            env=git_environment())

    def __enter__(self):
        return self

    def read_blob(self, oid, limit):
        assert self.process.stdin is not None and self.process.stdout is not None
        self.process.stdin.write((oid + '\n').encode('ascii'))
        self.process.stdin.flush()
        header = self.process.stdout.readline(200).decode('ascii').strip().split()
        if len(header) != 3 or header[0] != oid or header[1] != 'blob':
            raise InventoryError('A tracked blob is unavailable or has an unexpected identity/type.')
        try:
            size = int(header[2])
        except ValueError as exc:
            raise InventoryError('Git returned an invalid blob length.') from exc
        if size < 0 or size > limit:
            raise InventoryError('Tracked blob exceeds --max-blob-bytes; no partial index was published.')
        data = self.process.stdout.read(size)
        if len(data) != size or self.process.stdout.read(1) != b'\n':
            raise InventoryError('Git returned a truncated blob.')
        algorithm = hashlib.sha1 if len(oid) == 40 else hashlib.sha256
        actual = algorithm(b'blob ' + str(size).encode('ascii') + b'\0' + data).hexdigest()
        if actual != oid:
            raise InventoryError('Tracked blob bytes do not match their Git object ID.')
        return data

    def __exit__(self, exc_type, exc_value, traceback):
        if self.process.stdin:
            self.process.stdin.close()
        if self.process.stdout:
            self.process.stdout.close()
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()


def role(path, text, path_set):
    name = Path(path).name
    if name == 'SKILL.md.tmpl': return 'canonical skill template'
    if name == 'SKILL.md': return 'generated skill' if path + '.tmpl' in path_set else 'standalone skill or fixture'
    if '/sections/' in path and path.endswith('.tmpl'): return 'conditional instruction template'
    if '/sections/' in path and path.endswith('.md'): return 'generated or shared instruction section'
    if path.startswith('model-overlays/'): return 'model behavior adapter'
    if path.startswith('hosts/'): return 'host adapter or host support data'
    if name in ('AGENTS.md','CLAUDE.md'): return 'agent contribution policy or template'
    if '/fixtures/' in path or '/golden/' in path or '/goldens/' in path: return 'test fixture or expected output'
    if '.test.' in name or '.spec.' in name: return 'test implementation'
    if path.startswith('.github/workflows/'): return 'CI workflow'
    if path.startswith('changelog.d/'): return 'release note fragment'
    if path.startswith('docs/'): return 'project documentation or documentation data'
    if name.endswith(('.png','.jpg','.gif','.icns','.ico','.webp','.pdf')): return 'binary visual asset'
    if name.endswith(('.json','.jsonl','.yaml','.yml','.toml','.lock')): return 'configuration, registry, or recorded data'
    if path.startswith('bin/') or name in ('setup','setup.ps1','connect-chrome'): return 'command entry point or installer'
    if path.startswith('scripts/'): return 'build, generation, validation, or maintenance tool'
    if path.endswith(('.md','.tmpl','.txt')): return 'instructions, reference, or explanatory document'
    if path.endswith(('.ts','.js','.mjs','.c','.h','.swift','.sh','.awk','.sql','.py','.ps1')): return 'runtime, helper, or executable source'
    return 'supporting repository file'

PATTERNS = {
 'permissions': r'\b(confirm|approval|authorize|permission|consent|ask before)\b',
 'security': r'\b(security|untrusted|injection|token|secret|credential|sandbox|symlink|allowlist)\b',
 'validation': r'\b(test|tests|verify|verification|validate|validation|evidence|receipt|gate|eval)\b',
 'performance': r'\b(cache|latency|budget|timeout|parallel|concurren\w*|poll|tokens|cost)\b',
 'portability': r'\b(host|Codex|Claude|Grok|Gemini|Windows|Linux|macOS|adapter)\b',
 'workflow': r'\b(step|phase|route|handoff|resume|retry|stop|done|complete)\b',
 'lifecycle': r'\b(install|upgrade|uninstall|release|version|migration|rollback)\b',
 'privacy': r'\b(telemetry|privacy|consent|redact|transcript|upload|external)\b',
 'context': r'\b(preamble|reference|context|read|load|prompt|description)\b',
}
RX = {k: re.compile(v,re.I) for k,v in PATTERNS.items()}
GUIDANCE = {
 'permissions':'Map the action to existing authorization and the host enforcement boundary; test both permitted and denied paths.',
 'security':'Keep untrusted data separate from authority and verify the relevant control in executable code.',
 'validation':'Bind evidence to inputs and revision; separate skipped, failed, and infrastructure outcomes.',
 'performance':'Measure the named resource or latency before adding budgets, concurrency, or cache complexity.',
 'portability':'Keep workflow intent portable and test host-specific syntax and semantics in an adapter.',
 'workflow':'Make inputs, branch conditions, outputs, failure behavior, and handoffs explicit.',
 'lifecycle':'Version the contract and provide ownership-aware install, update, removal, and recovery.',
 'privacy':'Minimize collection and disclosure; obtain authorization at the relevant data boundary.',
 'context':'Place details at the lowest loading level that supplies them before use.',
}

def build_inventory(repo, revision, repository_url, output, submodules='reject',
                    max_blob_bytes=MAX_BLOB_BYTES):
    repo, output = Path(repo), Path(output)
    parsed = urlsplit(repository_url)
    if (parsed.scheme not in {'https', 'http'} or not parsed.netloc or
            parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise InventoryError('--repository-url must be an explicit credential-free HTTP(S) browse root.')
    repository_url = repository_url.rstrip('/')
    if git(repo, 'config', '--get-regexp', r'^remote\..*\.promisor$|^extensions\.partialclone$',
           allow_missing=True):
        raise InventoryError('Partial/promisor repositories are unsupported; use a complete local object store to prevent lazy network retrieval.')
    SHA = git(repo, 'rev-parse', '--verify', '--end-of-options', revision + '^{commit}').decode('ascii').strip()
    if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', SHA):
        raise InventoryError('Revision did not resolve to one full immutable commit ID.')
    tree = git(repo, 'rev-parse', '--verify', SHA + '^{tree}').decode('ascii').strip()
    entries = git(repo, 'ls-tree', '-r', '-z', '--full-tree', SHA).split(b'\0')
    TRACKED = {}
    for raw in entries:
        if not raw:
            continue
        metadata, raw_path = raw.split(b'\t', 1)
        try:
            path = raw_path.decode('utf-8', errors='strict')
        except UnicodeDecodeError as exc:
            raise InventoryError('Non-UTF-8 tracked path is outside this index format.') from exc
        mode, kind, oid = metadata.decode('ascii').split()
        if mode == '160000' and kind == 'commit':
            if submodules == 'reject':
                raise InventoryError('Git submodule entry encountered; use --submodules record for identity-only coverage.')
        elif kind != 'blob' or mode not in {'100644', '100755', '120000'}:
            raise InventoryError('Unsupported tracked Git object type/mode.')
        TRACKED[path] = {'mode': mode, 'oid': oid}
    PATHS = sorted(TRACKED)
    PATH_SET = set(PATHS)
    BASE = repository_url + '/blob/' + SHA + '/'
    with GitObjects(repo) as objects:
        rows=[]; units=[]; skills=[]; duplicates=collections.defaultdict(list)
        for path in PATHS:
            entry=TRACKED[path]
            if entry['mode'] == '160000':
                rows.append({'path': path, 'role': 'tracked submodule reference',
                             'git_mode': entry['mode'], 'git_blob': None,
                             'git_object': entry['oid'], 'git_object_type': 'commit',
                             'gitlink_commit': entry['oid'], 'bytes': None, 'lines': None,
                             'sha256': None, 'binary': None, 'coverage': 'submodule_metadata',
                             'source_url': repository_url + '/tree/' + SHA + '/' + quote(path, safe='/'),
                             'heading_count': 0, 'test_labels': [], 'symbols': [],
                             'topics': [], 'headings': [], 'content_scope': 'gitlink_identity_only'})
                continue
            # The tracked blob is authoritative, including symlink target bytes and
            # LFS pointer bytes. No worktree path, filter, checkout, or smudge is read.
            data=objects.read_blob(entry['oid'], max_blob_bytes)
            digest=hashlib.sha256(data).hexdigest()
            duplicates[digest].append(path)
            try:
                text=data.decode('utf-8')
                if '\0' in text: raise ValueError('binary')
                binary=False
            except (UnicodeDecodeError,ValueError):
                text='';binary=True
            lines=text.splitlines()
            headings=[{'line':i,'title':m.group(2)} for i,l in enumerate(lines,1) if (m:=re.match(r'^(#{1,6})\s+(.+)',l))]
            tests=re.findall(r'\b(?:test|it|describe)(?:\.(?:skip|only|each|todo))?\s*\(\s*[\'"`]([^\n\'"`]{1,180})',text)
            exports=re.findall(r'^(?:export\s+)?(?:async\s+)?(?:function|class|interface|type|enum)\s+(\w+)',text,re.M)
            r=role(path,text,PATH_SET)
            rows.append({'path':path,'role':'tracked symbolic link' if entry['mode']=='120000' else r,'git_mode':entry['mode'],'git_blob':entry['oid'],'bytes':len(data),'lines':len(lines) if not binary else None,'sha256':digest,'binary':binary,'source_url':BASE+quote(path, safe='/'),'coverage':'structurally_indexed','heading_count':len(headings),'test_labels':tests,'symbols':exports,'topics':[k for k,rx in RX.items() if rx.search(text)],'headings':headings})
            rows[-1]['git_object_type'] = 'blob'
            rows[-1]['content_scope'] = 'tracked_symlink_target' if entry['mode']=='120000' else 'tracked_blob'
            if data.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
                lfs_oid = re.search(rb'^oid sha256:([0-9a-f]{64})$', data, re.M)
                lfs_size = re.search(rb'^size ([0-9]+)$', data, re.M)
                rows[-1]['large_file'] = {
                    'kind': 'git-lfs-pointer', 'content': 'pointer_only',
                    'pointer_syntax': 'recognized' if lfs_oid and lfs_size else 'unrecognized',
                    'oid': lfs_oid[1].decode('ascii') if lfs_oid else None,
                    'declared_object_bytes': int(lfs_size[1]) if lfs_size else None,
                    'object_fetched': False,
                }
            name=Path(path).name
            if name in ('SKILL.md','SKILL.md.tmpl'):
                fm=re.match(r'^---\n(.*?)\n---',text,re.S)
                f=fm.group(1) if fm else ''
                def field(n):
                    m=re.search(r'^'+re.escape(n)+r':\s*(.*?)(?=\n[a-zA-Z_][\w-]*:|\Z)',f,re.S|re.M)
                    return m.group(1).strip() if m else ''
                skills.append({'path':path,'name':field('name'),'description':field('description'),'frontmatter_fields':re.findall(r'^([\w-]+):',f,re.M),'lines':len(lines),'bytes':len(data),'words':len(text.split()),'estimated_tokens_bytes_div_4':round(len(data)/4),'template_tokens':sorted(set(re.findall(r'\{\{([^}]+)\}\}',text))),'headings':headings,'source_url':BASE+quote(path, safe='/')})
            instructional=(name in ('SKILL.md','SKILL.md.tmpl','AGENTS.md','CLAUDE.md','DRIVER.md','DRIVER.md.tmpl') or '/sections/' in path or path.startswith('model-overlays/') or path.startswith('review/specialists/') or path in ('review/checklist.md','review/gate-integrity.md','write-skill/references/diet.md'))
            if not instructional or binary or not path.endswith(('.md','.tmpl')):continue
            canonical=(path.endswith('.tmpl') or path+'.tmpl' not in PATH_SET)
            heading='';buffer=[];start=1;fence=None;frontmatter=False
            def emit(end):
                if not buffer:return
                block='\n'.join(buffer).strip()
                if not block:return
                tags=[k for k,rx in RX.items() if rx.search(block)]
                unit_type='code' if block.startswith(('```','~~~')) else 'table' if block.startswith('|') else 'list_item' if re.match(r'^(?:[-*+] |\d+\. )',block) else 'paragraph'
                units.append({'id':f'GSI-{len(units)+1:05d}','path':path,'line_start':start,'line_end':end,'heading':heading,'unit_type':unit_type,'canonical':canonical,'source_url':BASE+quote(path, safe='/')+f'#L{start}-L{end}','sha256':hashlib.sha256(block.encode()).hexdigest(),'excerpt':re.sub(r'\s+',' ',block)[:220],'topics':tags,'review_status':'mechanically_indexed','adoption_questions':[GUIDANCE[t] for t in tags[:3]]})
            for i,line in enumerate(lines,1):
                if i==1 and line=='---':frontmatter=True;continue
                if frontmatter:
                    if line=='---':frontmatter=False
                    continue
                if fence:
                    buffer.append(line)
                    if line.lstrip().startswith(fence):fence=None;emit(i);buffer=[]
                    continue
                if re.match(r'^\s*(```|~~~)',line):
                    emit(i-1);buffer=[];start=i;fence=line.lstrip()[:3];buffer=[line];continue
                h=re.match(r'^(#{1,6})\s+(.+)',line)
                if h:emit(i-1);buffer=[];heading=h.group(2);continue
                if not line.strip():emit(i-1);buffer=[];continue
                if re.match(r'^(?:[-*+] |\d+\. )',line) and buffer:emit(i-1);buffer=[]
                if not buffer:start=i
                buffer.append(line)
            emit(len(lines))

    stats = {
        'schema_version': '2.0', 'indexer_version': VERSION,
        'commit': SHA, 'tree': tree, 'requested_revision': revision,
        'repository_url': repository_url,
        'provenance': 'immutable_git_tree_and_blob_objects',
        'worktree_and_index_content_read': False, 'replace_objects_enabled': False,
        'submodule_policy': submodules, 'max_blob_bytes': max_blob_bytes,
        'tracked_files': len(rows),
        'tracked_bytes': sum(r['bytes'] or 0 for r in rows),
        'text_files': sum(r['binary'] is False for r in rows),
        'binary_files': sum(r['binary'] is True for r in rows),
        'gitlink_files': sum(r['git_mode'] == '160000' for r in rows),
        'lfs_pointers': sum('large_file' in r for r in rows),
        'text_lines': sum(r['lines'] or 0 for r in rows),
        'skill_files': len(skills),
        'skill_templates': sum(s['path'].endswith('.tmpl') for s in skills),
        'instruction_blocks': len(units),
        'canonical_instruction_blocks': sum(u['canonical'] for u in units),
        'instruction_files': len(set(u['path'] for u in units)),
        'top_level': dict(collections.Counter(r['path'].split('/')[0] if '/' in r['path'] else '(root files)' for r in rows)),
        'exact_duplicate_groups': {h: ps for h, ps in duplicates.items() if len(ps)>1},
    }
    # Complete all object reads before publishing any index. Each output file
    # is replaced atomically; the destination directory is not a transaction.
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.inventory-build-', dir=output) as stage:
        out = Path(stage)
        (out/'file-inventory.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
        with (out/'file-inventory.csv').open('w', newline='', encoding='utf-8') as stream:
            cols=['path','role','bytes','lines','sha256','binary','coverage','heading_count','source_url']
            writer=csv.DictWriter(stream, cols, extrasaction='ignore'); writer.writeheader(); writer.writerows(rows)
        with (out/'instruction-index.jsonl').open('w', encoding='utf-8') as stream:
            for unit in units:
                stream.write(json.dumps(unit, ensure_ascii=False)+'\n')
        with (out/'instruction-index.csv').open('w', newline='', encoding='utf-8') as stream:
            cols=['id','path','line_start','line_end','heading','unit_type','canonical','topics','review_status','source_url']
            writer=csv.DictWriter(stream, cols, extrasaction='ignore'); writer.writeheader()
            for unit in units:
                writer.writerow({**unit, 'topics': ';'.join(unit['topics'])})
        (out/'skill-catalog.json').write_text(json.dumps(skills, indent=2)+'\n', encoding='utf-8')
        (out/'snapshot-stats.json').write_text(json.dumps(stats, indent=2)+'\n', encoding='utf-8')
        for artifact in sorted(out.iterdir()):
            os.replace(artifact, output/artifact.name)
    return stats


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, help='Existing local Git repository; no retrieval is performed.')
    parser.add_argument('--revision', required=True, help='Commit/revision resolved once to its full immutable commit ID.')
    parser.add_argument('--repository-url', required=True, help='HTTP(S) browse root using /blob/<commit>/<path> URLs.')
    parser.add_argument('--output', required=True, help='Directory for the six structural output files.')
    parser.add_argument('--submodules', choices=('reject', 'record'), default='reject',
                        help='Reject gitlinks by default, or record identity only without entering submodules.')
    parser.add_argument('--max-blob-bytes', type=int, default=MAX_BLOB_BYTES,
                        help='Per-object in-memory limit; default 64 MiB.')
    args = parser.parse_args(argv)
    if args.max_blob_bytes < 1:
        parser.error('--max-blob-bytes must be positive')
    try:
        stats = build_inventory(args.repo, args.revision, args.repository_url, args.output,
                                args.submodules, args.max_blob_bytes)
    except (InventoryError, OSError, subprocess.SubprocessError, UnicodeError) as exc:
        print(json.dumps({'status': 'error', 'type': type(exc).__name__, 'message': str(exc)}))
        return 2
    print(json.dumps({'status': 'passed', **{k: v for k,v in stats.items()
                         if k not in ('top_level', 'exact_duplicate_groups')}}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
