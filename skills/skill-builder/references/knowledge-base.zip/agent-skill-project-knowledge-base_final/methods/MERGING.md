# Merge mechanical inventory with explicit review annotations

[merge_review.py](merge_review.py) joins the immutable indexer's `file-inventory.json` to a separate manual file-review ledger. It preserves supplied reviewer judgments only when the exact source identity matches. It does not perform a semantic review, run repository code, execute a host workflow, or accept an earlier execution receipt as a new passing run.

This is the explicit bridge between mechanical extraction and the curated catalogs. Run [the immutable repository indexer](inventory_repository.py) first. Write or update review annotations separately, then inspect the merge/disposition output before adopting it as the next canonical file-review ledger. Builders of readers and tables consume the accepted canonical ledger; they must not turn structural indexing into semantic coverage.

## Input contract

Both inputs are JSON arrays of file records, bounded to 256 MiB each. Duplicate paths, duplicate JSON keys, invalid source identities, unknown coverage/depth labels and malformed source ranges fail before any output is written. Paths are exact repository-relative strings. The original tracked-byte SHA-256 and Git mode are required; if supplied, Git blob identity, byte count and line count must agree when two records claim the same content hash.

The mechanical input is the output of the indexer. It must contain only structural coverage or metadata coverage, with no semantic or execution claims. The merger uses fresh mechanical fields—including source URLs, headings, symbols and file metadata—from that input.

The annotation input can be the distributed [file-review ledger](../catalogs/file-review.json). Each record declares its original path, SHA-256, mode and `coverage`. All supplied nonmechanical review metadata is preserved when identity matches, including observations, reviewer details, report references and prior review history. The merger understands these explicit labels:

| Coverage | Meaning |
| --- | --- |
| `full_semantic` | An explicit manual full-file review, with matching review evidence, report references and numeric ranges covering the complete known line count. |
| `targeted_semantic` | An explicit targeted review, with matching evidence and numeric ranges or separately recorded selectors/search descriptions. |
| `same_content_reviewed` | Exact-content coverage from another fully reviewed annotation, identified by `same_content_as`. |
| `structural_index`, `structurally_indexed` | Mechanical coverage only; neither label creates a semantic verdict. |
| `binary_metadata_only`, `binary_metadata` | Metadata coverage of a binary artifact. |
| `symlink_metadata` | The tracked link-target identity, not a recursive review of its destination. |
| `submodule_metadata` | A gitlink commit identity only, with no content-hash or semantic-review claim for the nested repository. |

Ranges can be numeric `[start, end]` pairs, as in the existing ledger, or `{ "start": 1, "end": 8 }` objects. Strings do not belong in `ranges`; use `search_descriptions` or `selectors` for them. A selector records what was searched or inspected without inventing numeric line coverage.

A `same_content_reviewed` record must include its canonical source in the annotation input. That source must be `full_semantic`, and path relationship, original hash and mode must be consistent; where present, blob identity, byte count and line count must also match. A target that is only structurally or partially reviewed cannot create full duplicate coverage. Self-references and unsupported duplicate chains fail.

## Exact paths and display aliases

There is deliberately no implicit namespace or filename rewrite. Both inputs must use the same exact path representation. For the neutral display paths in this knowledge base, apply the same explicit alias policy to the relevant path fields of both inputs before merging, following [the provenance convention](../sources/PROVENANCE.md). Keep original tracked-byte hashes and modes unchanged; do not hash display-normalized prose and call it the original blob identity.

A raw source path and a different display alias are different keys. If they are not normalized consistently, the command emits one unannotated current row and one annotation absent from the current inventory. It does not guess that they describe the same file. Record the normalization operation and inspect its collisions before supplying those inputs.

## Run the merge

Create a destination directory once, then use new output filenames. From the knowledge-base root:

```sh
mkdir -p work/merged
python methods/merge_review.py --inventory work/index/file-inventory.json --annotations catalogs/file-review.json --annotation-scope prior --output work/merged/file-review.json --report work/merged/review-dispositions.json
```

The command never overwrites either input or an existing output. The output and report must be different files in existing parent directories. Exclusive creation prevents replacing a file that appears after preflight. A caught write failure removes only newly created files whose identities still match the created files; an interrupted process can leave an incomplete new output, so inspect it and choose a new destination for a retry. No `--force` option is supplied.

Use `--annotation-scope current` when submitting annotations that explicitly claim to cover the requested inventory. Any changed or absent source identity then fails the merge. A single annotation can also declare `"annotation_state": "current"`; that assertion is enforced even if the command's general scope is `prior`. `prior` allows historical mismatches to become review history, never current semantic credit.

Exit 0 means the **merge completed**, not that review or tests passed. Exit 2 means input validation, identity checking, destination validation or writing failed. The successful JSON summary gives file/disposition counts. The disposition report includes SHA-256 values of both complete input files. No timestamps or machine-specific output paths are inserted, so identical inputs and options generate identical output bytes.

## Dispositions and preservation

| Situation | Current output | Preserved history |
| --- | --- | --- |
| Path, original content hash and mode match | Fresh mechanics plus explicit prior review metadata; no new review is invented. | Existing history is retained. |
| Bytes or mode changed | Structural/metadata coverage, empty current review evidence, `changed_needs_review`. | The complete old annotation and source identity remain under `review_history`. |
| Current row has no annotation | Structural/metadata coverage and `unannotated_needs_review`. | No history is invented; “unannotated” does not itself assert the file was newly added to the repository. |
| Annotation path is absent from the new inventory | No phantom current row. | Complete annotation and identity remain in the report's `absent_annotations`. |
| Former exact-copy source changed, disappeared or lacks current full review | The copy is downgraded to structural coverage with `same_content_dependency_needs_review`. | The complete valid historical relationship remains in `review_history`. |
| An annotation asserts an invalid same-content relationship | Merge fails. | Inputs remain unchanged. |

A preserved structural row still has `merge.needs_review: true`. A preserved full or targeted file reading means only that its text identity and explicit reviewer annotation match. Changes in callers, dependencies, policies, or external documentation can invalidate an earlier conclusion even when this file is unchanged. Reassess those contracts through the approach/change map; this content merge cannot establish their behavior.

## Keep execution evidence separate

Top-level and nested `executed` fields in current output are false because the merger executes no reviewed component. Existing positive execution claims and receipt fields are retained in `prior_execution_evidence`, with their original location/value and `accepted_as_current_execution: false`. Changed or absent annotations retain their complete earlier record as historical data. A prior test outcome may still be useful evidence, but it needs its own exact artifact/environment scope and cannot silently become a newly executed receipt.

The merger does not fetch or validate report URLs, inspect receipt contents, or verify the truth of supplied reviewer observations. It checks their declared structure and source-identity consistency. The immutable indexer owns the connection to Git object bytes; independent review and test processes own judgments and execution evidence.

## Regression checks

```sh
python -m unittest discover -s methods/tests -p test_merge_review.py -v
```

The twenty tests exercise unchanged versus changed bytes, mode-only changes, new/unannotated rows, absent files, current-identity mismatches, duplicate paths/keys, unknown labels, inconsistent blob identities, valid/false/invalidated same-content relationships, exact path matching, execution-evidence separation, range coverage and non-overwriting deterministic CLI output.

A compatibility check also accepted all 5,375 existing annotation records against an in-memory mechanical projection of the same catalog. That check establishes input-format compatibility only; it is not an independent source re-inventory or a new semantic review.
