'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const vm = require('vm');
const cp = require('child_process');
const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'sources/source-reference.html');
const pythonPath = path.join(root, 'methods/source_reference.py');
const html = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)];
if (scripts.length !== 1) throw new Error('Expected exactly one inline source-reference script');
const script = scripts[0][1];
const fixtureRepository = 'https://github.com/example/engine';
const commit = 'ccd80de8ebdd7ca3384cc54bc138b53cd311a732';
const cases = [
  {id:'neutral_path_and_lines', locator:`reference:blob/${commit}/bin/reference-project-team-init#L43-L59`},
  {id:'spaces', locator:`reference:blob/${commit}/docs/a file.md#L2-L4`},
  {id:'special_characters', locator:`reference:blob/${commit}/docs/quote'\"&?[];()+$ café.md#L1`},
  {id:'alias_forms', locator:`reference:blob/${commit}/REFERENCE_PROJECT/reference_project/ReferenceProject/referenceProject/Reference-project/reference-project.md#L1`},
  {id:'encoded_percent_and_unicode', locator:`reference:blob/${commit}/docs/percent%25-and-caf%C3%A9.md#L1`},
  {id:'related_repository', locator:'reference:repository/-artifacts-example'},
  {id:'encoded_parent_traversal', locator:`reference:blob/${commit}/%2e%2e/README.md`, reject:true},
  {id:'encoded_current_segment', locator:`reference:blob/${commit}/docs/%2e/README.md`, reject:true},
  {id:'encoded_control_character', locator:`reference:blob/${commit}/docs/%00bad.md`, reject:true},
];
function sandbox(locator) {
  const nodes = new Map();
  for (const match of html.matchAll(/\bid="([^"]+)"/g)) {
    const callbacks = Object.create(null);
    nodes.set(match[1], {textContent:'',value:'',href:'',hidden:false,callbacks,
      addEventListener(event, callback){callbacks[event]=callback;}});
  }
  nodes.get('result').hidden=true;
  nodes.get('resolved').hidden=true;
  const saved = new Map();
  const context = {location:{search:'?ref='+encodeURIComponent(locator)}, URL, URLSearchParams,
    encodeURI, decodeURIComponent, Error,
    document:{getElementById(id){if(!nodes.has(id))throw new Error('Unknown stub element '+id);return nodes.get(id);}},
    localStorage:{getItem(key){return saved.get(key)||null;},setItem(key,value){saved.set(key,String(value));},removeItem(key){saved.delete(key);}}};
  vm.runInNewContext(script,context,{timeout:1000,filename:'source-reference-inline.js'});
  return {nodes,saved};
}
const temp=fs.mkdtempSync(path.join(path.dirname(root),'source-reference-ui-'));
async function main(){
  const fixtureRoot=path.join(temp,'fixture');fs.mkdirSync(fixtureRoot);
  fs.writeFileSync(path.join(fixtureRoot,'skill-project-knowledge-base.md'),
    '<!-- BEGIN MAINTAINED INTRO -->\n[engine]('+fixtureRepository+') served as inspiration.\n<!-- END MAINTAINED INTRO -->\n');
  const pythonCode = [
    'import importlib.util,json,sys',
    'from pathlib import Path',
    's=importlib.util.spec_from_file_location("source_reference",sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)',
    'out=[]',
    'for case in json.load(sys.stdin):',
    ' try:out.append({"id":case["id"],"url":m.resolve(case["locator"],Path(sys.argv[2]))})',
    ' except ValueError as e:out.append({"id":case["id"],"error":True})',
    'print(json.dumps(out))',
  ].join('\n');
  const compare=cp.spawnSync('python3',['-B','-c',pythonCode,pythonPath,fixtureRoot],
    {input:JSON.stringify(cases),encoding:'utf8',timeout:10000,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}});
  if(compare.status!==0)throw new Error('Python fixture comparator failed: '+compare.stderr);
  const pythonResults=new Map(JSON.parse(compare.stdout).map(row=>[row.id,row]));
  const results=[];
  for(const item of cases){
    const view=sandbox(item.locator);
    view.nodes.get('repository').value=fixtureRepository;
    view.nodes.get('resolve').callbacks.click();
    const rejected=Boolean(view.nodes.get('error').textContent)&&view.nodes.get('result').hidden&&view.nodes.get('resolved').hidden;
    const py=pythonResults.get(item.id);
    const parity=item.reject?rejected&&Boolean(py.error):!rejected&&view.nodes.get('source-link').href===py.url;
    const expected=item.id==='neutral_path_and_lines'?view.nodes.get('source-link').href===`${fixtureRepository}/blob/${commit}/bin/engine-team-init#L43-L59`:true;
    results.push({id:item.id,status:parity&&expected?'passed':'failed',python_parity:parity,
      ...(item.reject?{rejection_observed:rejected}:{resolved_link_present:!view.nodes.get('result').hidden})});
  }
  const hostile=`reference:blob/${commit}/docs/single'quote;$(printf SUBSTITUTED)-\`printf BACKTICK\`-$HOME-\\.md#L1`;
  const shellView=sandbox(hostile);
  const command=shellView.nodes.get('command').textContent;
  const stub=path.join(temp,'python3');
  const interpreter=cp.spawnSync('python3',['-c','import sys;print(sys.executable)'],{encoding:'utf8',timeout:10000}).stdout.trim();
  fs.writeFileSync(stub,'#!'+interpreter+'\nimport json,sys\nprint(json.dumps(sys.argv[1:]))\n',{mode:0o755});
  const parsed=cp.spawnSync('/bin/sh',['-c',command],{encoding:'utf8',cwd:temp,timeout:10000,
    env:{...process.env,PATH:temp+path.delimiter+process.env.PATH}});
  let literal=false;try{literal=parsed.status===0&&JSON.stringify(JSON.parse(parsed.stdout))===JSON.stringify(['methods/source_reference.py',hostile]);}catch(_){}
  results.push({id:'copied_posix_command_preserves_metacharacters',status:literal?'passed':'failed',literal_argv_preserved:literal});
  const actual=fs.readFileSync(path.join(root,'skill-project-knowledge-base.md'),'utf8');
  const actualView=sandbox(`reference:blob/${commit}/README.md#L1`);
  await actualView.nodes.get('intro-file').callbacks.change({target:{files:[{size:Buffer.byteLength(actual),text:async()=>actual}]}});
  // Retain only booleans for this case. Do not include the real repository URL.
  const chosen=actualView.nodes.get('repository').value;
  const loaded=Boolean(chosen)&&!actualView.nodes.get('error').textContent&&
    !actualView.nodes.get('result').hidden&&
    actualView.nodes.get('source-link').href===chosen+`/blob/${commit}/README.md#L1`;
  results.push({id:'actual_intro_file_chooser_handler',status:loaded?'passed':'failed',loaded_and_resolved:loaded});
  const receipt={schema_version:'1.0',status:results.every(row=>row.status==='passed')?'passed':'failed',
    scope:'Node VM execution of the actual inline script with a stub DOM; script logic testing only.',
    rendered_interaction:false,browser_layout_verified:false,native_file_picker_verified:false,
    network_requests_made:false,node:process.version,
    fixture_repository:fixtureRepository,case_count:results.length,
    failed_case_count:results.filter(row=>row.status!=='passed').length,
    source_sha256:{'sources/source-reference.html':crypto.createHash('sha256').update(html).digest('hex'),
      'methods/source_reference.py':crypto.createHash('sha256').update(fs.readFileSync(pythonPath)).digest('hex'),
      'methods/check_source_reference.js':crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex')},
    results,limits:['Stub DOM does not establish browser rendering, navigation, storage behavior, or a native file chooser interaction.',
      'The actual Markdown file was supplied to the change handler as an in-memory File-like fixture; only its boolean outcome is retained.']};
  if(process.argv.length>2){if(process.argv.length!==4||process.argv[2]!=='--output')throw new Error('Usage: node methods/check_source_reference.js [--output receipt.json]');fs.writeFileSync(process.argv[3],JSON.stringify(receipt,null,2)+'\n');}
  console.log(JSON.stringify(receipt,null,2));
  process.exitCode=receipt.status==='passed'?0:1;
}
main().catch(error=>{console.error(error.message);process.exitCode=1;}).finally(()=>fs.rmSync(temp,{recursive:true,force:true}));
