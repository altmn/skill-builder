# Build, verify and maintain the knowledge base

This package keeps the original handbook, detailed audits, evidence catalogs and scaffolding. The build makes their derived readers and projections repeatable. It does not regenerate a reviewer's judgment, execute the historical reference source, install a skill, or manufacture host support evidence.

## Prerequisites and one working sequence

The recorded release environment is Python 3.12.14, Pandoc 3.1.11.1, Node.js 24.22.3, Git 2.56.1 and zlib 1.3.2 on Linux. The Python dependencies are locked in [build-requirements.txt](build-requirements.txt); the individual validator dependencies remain in [tools/requirements.txt](../tools/requirements.txt). The renderer checks its exact Pandoc pin. ZIP byte identity also depends on the compression implementation, so use the recorded environment when comparing release archives across machines.

Prepare an isolated environment using your ordinary dependency provisioning process. An in-package `.venv/`, `venv/`, `node_modules/`, `.build/` and interpreter caches are excluded from release inputs. No command in the build automatically retrieves or installs dependencies. From the extracted package root:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r methods/build-requirements.txt
python3 -B methods/build_bundle.py
python3 -B methods/check_bundle.py --run-tests
python3 -B methods/build_bundle.py --check
```

The dependency installation is an explicit preparation step and may need network access; the subsequent build and checks operate locally. A missing prerequisite is a failed or blocked check, not a pass. The sample's discrepancy fixture intentionally returns exit 1; its frozen test panel checks that expected outcome.

`methods/build_bundle.py` writes the complete derived Markdown/HTML readers, CSV catalog views, skill catalog, source register, coverage summary, offline catalog browser, sample package, input identities, manifest and checksum list. `--check` compares expected bytes without writing them. `methods/check_bundle.py` verifies schema records, links, numeric source ranges, source-to-record identity, local evidence hashes, the single linked inspiration statement, generated drift, manifest hashes and JavaScript syntax. `--run-tests` also runs the explicit local commands in [methods/check-commands.json](check-commands.json).

The actual command arguments are visible in `methods/check-commands.json`. Verification fingerprints the package before and after those commands so unexpected edits fail the gate. The sample build test may rebuild its own package to identical bytes. Caches are excluded. A schema pass establishes record shape; a source-range pass establishes bounds; neither certifies semantic truth or host enforcement.

## Canonical inputs and derived files

| Material | Ownership |
| --- | --- |
| `handbook/*.md`, detailed `audits/*.md`, checklists, task briefs, schemas and example source | Manually maintained canonical content. |
| `catalogs/file-review.json` and `catalogs/instruction-review.jsonl` | Canonical historical ledgers containing source identity and explicit review annotations. |
| `catalogs/requirements.json`, `skill-catalog.json`, `benchmark-findings.json`, application profiles and approach/command maps | Canonical rule, artifact, finding and retrieval records. Preserve stable IDs and evidence boundaries. |
| Per-track audit JSON | Preserved manual research inputs and observations. They overlap; do not sum their coverage. |
| `sources/reference-snapshot.json`, `primary-sources.json`, documentation evidence register | Source identities, dated claims and retained evidence. |
| `validation/history/` and dated local receipts | Historical evidence inputs. A rebuild does not rerun or relabel them. |
| Introduction between `MAINTAINED INTRO` markers in `skill-project-knowledge-base.md` | The only manually maintained portion of that reader; it owns the single linked inspiration statement. Preserve it when rebuilding from a clean checkout. |
| Remaining consolidated Markdown body, HTML reader, CSVs, catalog-browser embedded data, coverage summary and source-register Markdown | Generated from complete canonical inputs. Do not edit them as independent authorities. |
| `examples/manifest-inspector/dist/` | Deterministic projection of the three explicit payload files. New bytes require new evidence before old receipts can support a claim. |
| `validation/build-inputs.json`, `MANIFEST.json`, `SHA256SUMS` | Generated identities. The two final inventory files exclude themselves to avoid circular hashing. |

[build-config.json](build-config.json) declares the complete reader document order and dependency identities. All 31 original embedded documents remain, with new implementation material added. [coverage-policy.json](coverage-policy.json) owns coverage caveats independently of generated counts. The browser template and stylesheet remain explicit, editable inputs; no external network resource is needed to view the full reader or search the catalogs.

## Update and evidence workflow

1. Edit canonical content, record the reason, and preserve original finding IDs and source identities.
2. For a new source revision, use [inventory_repository.py](inventory_repository.py) to read the immutable Git tree. Combine it with explicit manual review decisions using [the merge workflow](MERGING.md). Changed files remain unreviewed until evidence is supplied. Source path aliases must be normalized explicitly before joining identities.
3. Re-run only the local acceptance suites relevant to the changed behavior, plus the required release gates. Save a new receipt with the tested artifact and environment. Keep prior receipts in history.
4. Rebuild. Run the checker. If writing a current validation receipt inside the package, rebuild again to bind that receipt into the manifest, then run `--check` and the checker once more without changing it.
5. Run the separately labeled browser check if rendering or catalog interaction changed. Preserve an unavailable browser as blocked; do not replace it with a JavaScript syntax pass.
6. Package only after all applicable local gates pass. Public open reuse remains a distinct owner license decision documented in [LICENSE.md](../LICENSE.md).

The source indexer and review merger do not recreate earlier semantic reading. Existing judgments are explicit inputs. Exact-byte identity can support carrying a dated observation as history; it cannot carry an executed host test to a changed package or platform.

## CI recipe and deterministic archive

In a CI worker provisioned with the pinned prerequisites, run [ci-check.sh](ci-check.sh), which invokes the same local build/check gates. The script is platform-neutral shell glue for Linux/macOS-style workers; a hosted CI service and its credential/action configuration have not been exercised here. Invoke the Python commands directly on other supported environments, and record the result rather than inferring support.

```sh
sh methods/ci-check.sh
python3 -B methods/build_bundle.py --check --archive ../agent-skill-project-knowledge-base-updated.zip
```

The archive is written outside the package tree, uses sorted paths and fixed ZIP metadata and permissions, and excludes development environments and caches. Identical canonical inputs under the pinned build environment produce identical nonvolatile artifacts. The build regression tests check unchanged rebuilds, stale readers, package exclusions and propagation of a controlled canonical edit. Checksums establish file identity; consistency comes from regeneration and relational checks.

## Reference-check scope

Actual Markdown links in the complete reader set and root navigation, HTML links/anchors, source selectors, and explicit textual package-reference contracts are checked. [reference-contracts.json](reference-contracts.json) includes the corrected primary-source-register reference from F12. Example upstream commands and paths are research data, not assumed local files. Moving-branch references and template placeholders are explicitly distinguished from immutable source evidence. External URLs are not fetched by this checker.

The current source ledger covers one baseline, so a later revision's retained reference can be syntactically valid while its contents remain unverified. Documentation excerpt hashes identify the captured short text, not a whole site. See [the provenance policy](../sources/PROVENANCE.md) and [review follow-ups](../audits/review-followups.md) for those boundaries.
