#!/usr/bin/env python3
"""Check package integrity, source identities, links, schemas and generated drift.

These checks do not establish live-host behavior, source-code safety or the truth
of manual review judgments. No external link is fetched.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import sys
import tempfile
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_bundle import file_list, generate, maintained_intro, pandoc
from source_reference import project_url

ROOT = Path(__file__).resolve().parents[1]


class HTMLReferences(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids, self.links, self.scripts = [], [], []
        self.script = None
    def handle_starttag(self, tag, attributes):
        values = dict(attributes)
        if "id" in values:
            self.ids.append(values["id"])
        for name in ("href", "src"):
            if name in values:
                self.links.append(values[name])
        if tag == "script":
            self.script = [] if values.get("type") != "application/json" and "src" not in values else None
    def handle_data(self, data):
        if self.script is not None:
            self.script.append(data)
    def handle_endtag(self, tag):
        if tag == "script" and self.script is not None:
            self.scripts.append("".join(self.script))
            self.script = None


def md_links(tree):
    if isinstance(tree, list):
        for value in tree:
            yield from md_links(value)
    elif isinstance(tree, dict):
        if tree.get("t") in {"Link", "Image"}:
            yield tree["c"][-1][0]
        for value in tree.values():
            yield from md_links(value)


def check(root: Path, run_tests: bool = False) -> dict:
    errors, checks = [], {}
    paths = file_list(root)
    files = json.loads((root / "catalogs/file-review.json").read_text())
    by_path = {r["path"]: r for r in files}
    instructions = [json.loads(s) for s in (root / "catalogs/instruction-review.jsonl").read_text().splitlines() if s.strip()]
    rules = json.loads((root / "catalogs/requirements.json").read_text())["rules"]
    snapshot = json.loads((root / "sources/reference-snapshot.json").read_text())
    baseline = snapshot["commit"]
    name = urlsplit(project_url(root)).path.rsplit("/", 1)[-1]
    term = re.compile(re.escape(name), re.IGNORECASE)
    allowed_intro = maintained_intro(root)
    mention_hits = []
    for path in paths:
        rel = path.relative_to(root).as_posix()
        if term.search(rel):
            mention_hits.append(rel + " (filename)")
        data = path.read_bytes()
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            # Binary fixtures/packages must not silently carry a prohibited name.
            if name.lower().encode() in data.lower():
                mention_hits.append(rel + " (binary content)")
            continue
        inspected = text.replace(allowed_intro, "", 1) if rel == "skill-project-knowledge-base.md" else text
        if term.search(inspected):
            mention_hits.append(rel)
    if mention_hits:
        errors.append({"gate": "name_policy", "files": mention_hits})
    inspiration_lines = [line for line in allowed_intro.splitlines() if term.search(line)]
    if len(inspiration_lines) != 1 or "served as inspiration" not in inspiration_lines[0]:
        errors.append({"gate": "name_policy", "reason": "The allowed mention must be one linked inspiration sentence in the introduction"})
    checks["name_policy"] = {"status": "passed" if not mention_hits and len(inspiration_lines) == 1 else "failed", "allowed_location": "skill-project-knowledge-base.md maintained introduction", "allowed_sentences": len(inspiration_lines)}

    expected_counts = {"file_records": 5375, "instruction_records": 25693, "rule_records": 99}
    actual_counts = {"file_records": len(files), "instruction_records": len(instructions), "rule_records": len(rules)}
    if actual_counts != expected_counts:
        errors.append({"gate": "baseline_cardinality", "expected": expected_counts, "actual": actual_counts})
    for key, data, field in [("files", files, "path"), ("instructions", instructions, "id"), ("rules", rules, "id")]:
        if len({r[field] for r in data}) != len(data):
            errors.append({"gate": "unique_ids", "catalog": key})
    if sum(r["bytes"] for r in files) != snapshot["tracked_bytes"]:
        errors.append({"gate": "source_sizes", "reason": "File bytes differ from original snapshot total"})
    for row in instructions:
        owner = by_path.get(row["path"])
        if not owner or not (1 <= row["line_start"] <= row["line_end"] <= owner["lines"]):
            errors.append({"gate": "instruction_range", "id": row["id"]})
    for row in files + instructions:
        loc = row.get("source_url", "")
        expected_path = "reference:blob/" + baseline + "/" + row["path"]
        if "line_start" in row:
            expected_path += f'#L{row["line_start"]}-L{row["line_end"]}'
        if unquote(loc) != expected_path:
            errors.append({"gate": "source_identity_binding", "record": row.get("id", row["path"]), "reason": "Source locator does not match the owning path and recorded interval"})
    checks["inventory"] = {**actual_counts, "unique_file_paths": len(by_path), "source_bytes": sum(r["bytes"] for r in files), "canonical_skill_templates": sum(r["path"].endswith("SKILL.md.tmpl") and r["coverage"] == "full_semantic" for r in files)}

    source_checked, future_sources, unpinned_sources = set(), set(), set()
    def check_source(value, origin):
        if not isinstance(value, str):
            return
        parsed = urlsplit(value)
        if parsed.path.endswith("source-reference.html"):
            loc = parse_qs(parsed.query).get("ref", [])
            if len(loc) == 1:
                value = loc[0]
        if not value.startswith("reference:blob/"):
            return
        m = re.fullmatch(r"reference:blob/([0-9a-f]{40})/(.+?)(?:#L(\d+)(?:-L(\d+))?)?", value)
        if not m:
            # Only these declared historical moving/template forms are exempt.
            if re.fullmatch(r"reference:blob/main/[^\s]+", value) or re.fullmatch(r"reference:blob/\{SHA\}/[^\s]*", value):
                unpinned_sources.add(value)
                return
            errors.append({"gate": "source_reference", "origin": origin, "locator": value, "reason": "Malformed pinned source locator"})
            return
        commit, path, lo, hi = m.groups()
        if commit != baseline:
            future_sources.add(value)
            return
        path = unquote(path)
        source_checked.add(value)
        row = by_path.get(path)
        if row is None:
            errors.append({"gate": "source_reference", "origin": origin, "locator": value, "reason": "Path absent from pinned ledger"})
        elif lo and (row["lines"] is None or not 1 <= int(lo) <= int(hi or lo) <= row["lines"]):
            errors.append({"gate": "source_range", "origin": origin, "locator": value})

    range_count = 0
    def inspect_json(value, origin, inherited_path=None):
        nonlocal range_count
        if isinstance(value, list):
            for item in value:
                inspect_json(item, origin, inherited_path)
        elif isinstance(value, dict):
            owner_path = value.get("path", inherited_path)
            bound = value.get("lines", value.get("line_count"))
            if isinstance(owner_path, str) and owner_path in by_path and value.get("commit", baseline) == baseline:
                canonical_bound = by_path[owner_path]["lines"]
                # Nested expansion/block records may use `lines` for their own
                # span length. Only a record owning an explicit source path
                # declares a file-level length; inherited paths bound intervals.
                is_span = all(type(value.get(key)) is int for key in ("start", "end"))
                if is_span:
                    range_count += 1
                    if not 1 <= value["start"] <= value["end"] <= canonical_bound:
                        errors.append({"gate": "source_span", "origin": origin, "path": owner_path, "start": value["start"], "end": value["end"], "canonical_bound": canonical_bound})
                    if isinstance(bound, int) and bound != value["end"] - value["start"] + 1:
                        errors.append({"gate": "source_span_length", "origin": origin, "path": owner_path})
                elif "path" in value and isinstance(bound, int) and bound != canonical_bound:
                    errors.append({"gate": "source_line_count", "origin": origin, "path": owner_path, "declared": bound, "canonical": canonical_bound})
                bound = canonical_bound
            for key, data in value.items():
                if key in {"ranges", "reviewed_ranges", "reviewed_line_ranges", "source_ranges"} and isinstance(data, list):
                    for item in data:
                        if isinstance(item, list) and len(item) == 2 and all(isinstance(x, int) and not isinstance(x, bool) for x in item):
                            range_count += 1
                            if not 1 <= item[0] <= item[1] or (isinstance(bound, int) and item[1] > bound):
                                errors.append({"gate": "numeric_source_range", "origin": origin, "path": owner_path, "range": item, "bound": bound})
                        elif isinstance(item, dict):
                            # Versioned schemas own object-form range validation.
                            pass
                        else:
                            errors.append({"gate": "range_representation", "origin": origin, "path": owner_path, "reason": "Keep textual search descriptions outside numeric range fields"})
                inspect_json(data, origin, owner_path)
        elif isinstance(value, str):
            check_source(value, origin)
    for path in paths:
        if path.suffix == ".json" or path.name.endswith(".json.template"):
            try:
                parsed = json.loads(path.read_text())
                inspect_json(parsed, path.relative_to(root).as_posix())
            except (ValueError, UnicodeDecodeError) as exc:
                errors.append({"gate": "json_parse", "path": str(path.relative_to(root)), "error": str(exc)})
    for row in instructions:
        check_source(row.get("source_url"), "catalogs/instruction-review.jsonl")
    checks["source_references"] = {"pinned_locators_checked": len(source_checked), "numeric_ranges_checked": range_count, "other_revision_locators": len(future_sources), "explicit_unpinned_locators": len(unpinned_sources), "other_revision_limit": "Source paths at other revisions are retained evidence references; no missing checkout is represented as independently verified. Declared moving-branch/template locators are not pinned evidence."}

    html_refs = {}
    for path in paths:
        if path.suffix == ".html" and path.name != "catalog-template.html":
            parser = HTMLReferences()
            parser.feed(path.read_text())
            rel = path.relative_to(root).as_posix()
            html_refs[rel] = parser
            duplicate = [key for key, count in Counter(parser.ids).items() if count > 1]
            if duplicate:
                errors.append({"gate": "html_ids", "file": rel, "duplicates": duplicate})
    local_links = set()
    def inspect_link(value, origin):
        check_source(value, origin)
        parsed = urlsplit(value)
        if parsed.scheme or value.startswith("//"):
            return
        target = (root / origin).parent / unquote(parsed.path) if parsed.path else root / origin
        target = target.resolve()
        if not target.is_relative_to(root.resolve()):
            errors.append({"gate": "local_reference", "origin": origin, "target": value, "reason": "Package path escape"})
            return
        if not target.exists():
            errors.append({"gate": "local_reference", "origin": origin, "target": value, "reason": "Missing package target"})
            return
        rel = target.relative_to(root.resolve()).as_posix()
        local_links.add((origin, value))
        if parsed.fragment and rel in html_refs and parsed.fragment not in html_refs[rel].ids:
            errors.append({"gate": "html_anchor", "origin": origin, "target": value})
    for origin, parser in html_refs.items():
        for link in parser.links:
            inspect_link(link, origin)
    config = json.loads((root / "methods/build-config.json").read_text())
    markdown_scope = set(config["documents"]) | {"README.md", "skill-project-knowledge-base.md", "sources/PROVENANCE.md", "methods/README.md", "validation/README.md"}
    for origin in sorted(markdown_scope):
        tree = json.loads(pandoc((root / origin).read_text(), "gfm", "json"))
        for link in md_links(tree):
            inspect_link(link, origin)
    # Textual references are a separate contract from Markdown hyperlink syntax.
    reference_contracts = json.loads((root / "methods/reference-contracts.json").read_text())
    for item in reference_contracts["contracts"]:
        text = (root / item["document"]).read_text()
        for target in item["package_paths"]:
            if target not in text or not (root / target).is_file():
                errors.append({"gate": "textual_package_reference", "document": item["document"], "target": target})
        for obsolete in item.get("obsolete_references", []):
            if obsolete in text:
                errors.append({"gate": "obsolete_textual_reference", "document": item["document"], "target": obsolete})
    checks["references"] = {"local_links_checked": len(local_links), "html_documents": len(html_refs), "markdown_documents": len(markdown_scope), "textual_reference_contracts": len(reference_contracts["contracts"]), "external_links_fetched": False}

    scripts = 0
    with tempfile.TemporaryDirectory(prefix="kb-js-", dir=root.parent) as temp:
        for origin, parser in html_refs.items():
            for script in parser.scripts:
                scripts += 1
                path = Path(temp) / f"script-{scripts}.js"
                path.write_text(script)
                checked = subprocess.run(["node", "--check", str(path)], text=True, capture_output=True)
                if checked.returncode:
                    errors.append({"gate": "javascript_syntax", "origin": origin, "error": checked.stderr})
    checks["javascript_syntax"] = {"scripts_checked": scripts, "executed_in_browser": False}

    evidence_count = 0
    sample_archive = root / "examples/manifest-inspector/dist/manifest-inspector.zip"
    sample_digest = hashlib.sha256(sample_archive.read_bytes()).hexdigest()
    def check_local_evidence(value, origin):
        nonlocal evidence_count
        if isinstance(value, list):
            for item in value:
                check_local_evidence(item, origin)
        elif isinstance(value, dict):
            if value.get("kind") == "artifact" and isinstance(value.get("ref"), str):
                target = (root / value["ref"]).resolve()
                evidence_count += 1
                if not target.is_relative_to(root.resolve()) or not target.is_file():
                    errors.append({"gate": "local_evidence", "record": origin, "ref": value["ref"], "reason": "Missing or out-of-package evidence"})
                elif value.get("sha256") and hashlib.sha256(target.read_bytes()).hexdigest() != value["sha256"]:
                    errors.append({"gate": "local_evidence", "record": origin, "ref": value["ref"], "reason": "Evidence hash mismatch"})
            if value.get("artifact_id") == "manifest-inspector-package-v1" and value.get("package_sha256") != sample_digest:
                errors.append({"gate": "sample_package_evidence", "record": origin, "reason": "Recorded package identity differs from distributed bytes"})
            if value.get("activated_source") and value.get("activated_sha256"):
                target = root / value["activated_source"]
                if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest() != value["activated_sha256"]:
                    errors.append({"gate": "activated_source_identity", "record": origin})
            for item in value.values():
                check_local_evidence(item, origin)
    for path in sorted((root / "examples/records").glob("*.json")):
        check_local_evidence(json.loads(path.read_text()), path.relative_to(root).as_posix())
    checks["filled_record_evidence"] = {"local_references_checked": evidence_count, "package_sha256": sample_digest}

    expected = generate(root)
    stale = [name for name, data in expected.items() if not (root / name).is_file() or (root / name).read_bytes() != data]
    if stale:
        errors.append({"gate": "generated_drift", "files": stale})
    manifest = json.loads((root / "MANIFEST.json").read_text())
    hash_errors = []
    for row in manifest["files"]:
        target = root / row["path"]
        if not target.is_file() or target.stat().st_size != row["bytes"] or hashlib.sha256(target.read_bytes()).hexdigest() != row["sha256"]:
            hash_errors.append(row["path"])
    if hash_errors:
        errors.append({"gate": "manifest", "files": hash_errors})
    checks["generated_outputs"] = {"files_compared": len(expected), "stale": stale, "manifest_entries": len(manifest["files"]), "hash_errors": hash_errors}

    # Actual acceptance commands are explicit inputs so example/tool contracts stay visible.
    recipe = json.loads((root / "methods/check-commands.json").read_text())
    commands = recipe["always"] + (recipe["tests"] if run_tests else [])
    executions = []
    before_commands = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in file_list(root)}
    for command in commands:
        argv = [sys.executable if x == "{python}" else x for x in command["argv"]]
        process = subprocess.run(argv, cwd=root, text=True, capture_output=True, timeout=command.get("timeout_seconds", 120), env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        executions.append({"id": command["id"], "command": command["argv"], "exit_code": process.returncode, "stdout": process.stdout, "stderr": process.stderr})
        if process.returncode:
            errors.append({"gate": "local_command", "id": command["id"], "exit_code": process.returncode})
    after_commands = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in file_list(root)}
    changed_by_commands = sorted(k for k in before_commands.keys() | after_commands.keys() if before_commands.get(k) != after_commands.get(k))
    if changed_by_commands:
        errors.append({"gate": "verification_side_effects", "changed_package_files": changed_by_commands})
    checks["local_commands"] = executions
    checks["tests_requested"] = run_tests
    return {"schema_version": "2.0", "status": "passed" if not errors else "failed", "checks": checks, "errors": errors, "scope": "Knowledge-base artifact, provenance and local tool/example checks. Historical source semantics, upstream operation, live hosts and browser layout are not certified by this result.", "browser_rendering": {"status": "not_run_by_this_checker", "historical_result": "validation/history/original-artifact-validation.json", "current_receipt": "validation/browser-validation.json"}}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--run-tests", action="store_true")
    parser.add_argument("--receipt", type=Path, help="Write the full result. Rebuild manifests after intentionally updating an in-package receipt.")
    args = parser.parse_args()
    try:
        result = check(args.root.resolve(), args.run_tests)
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        result = {"status": "failed", "error": str(exc)}
    if args.receipt:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "errors": result.get("errors", result.get("error", [])), "receipt": str(args.receipt) if args.receipt else None}, indent=2))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
