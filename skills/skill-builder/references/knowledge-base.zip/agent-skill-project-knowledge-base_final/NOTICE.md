# Attribution and reuse notes

The handbook, project rules, task briefs, scaffolding, original validator and presentation in this bundle were prepared for Alex's skill-project knowledge base. They are a new synthesis, not an official standard or an endorsement by a referenced vendor/project.

The historical reference implementation is [identified through its source locator](sources/source-reference.html?ref=reference%3Arepository), pinned to `ccd80de8ebdd7ca3384cc54bc138b53cd311a732`, copyright 2026 Garry Tan, distributed under MIT. Catalogs retain short source excerpts, headings, symbols and test labels. The original [license](sources/upstream-notices/reference-project-LICENSE.txt), [third-party notice](sources/upstream-notices/reference-project-NOTICE.md), and associated third-party license texts are preserved in `sources/upstream-notices/`. Source excerpts retain their upstream terms.

The OpenAI public skill-creator comparison uses commit `49f948faa9258a0c61caceaf225e179651397431`. Its applicable [license text](sources/upstream-notices/openai-skill-creator-LICENSE.txt) is retained. The delivered validator is an original implementation; the public helper was used for comparison and isolated probes.

Current official documentation is linked in the [primary source register](sources/primary-sources.md). The bundle summarizes those sources and distinguishes documentation facts from original recommendations. Do not remove source provenance when reusing research-derived statements, and do not claim that this bundle certifies runtime security or universal host compatibility.

The project scaffold intentionally leaves the license choice for a new project to its maintainer. Select and include the appropriate license before publishing that project.


## Original-material distribution status

[LICENSE.md](LICENSE.md) states the license status for the new synthesis, code and scaffolding. No public reuse license for those original components was selected in the supplied materials; that owner decision remains explicit. The reference implementation's MIT license and other upstream licenses do not automatically cover the original synthesis.

## Display normalization

Project identifiers in source excerpts, paths and the reference source's third-party notice are presented using a neutral namespace. These are adapted displays. All copyright attributions, licensing declarations and complete license texts are retained. The [provenance policy](sources/PROVENANCE.md) explains recovery of exact original source paths and why retained source hashes must not be computed from normalized excerpts.
